package com.example.instaclone;

public final class R {

    public static final class anim {
        public static final int abc_fade_in = 2130771968;
        public static final int abc_fade_out = 2130771969;
        public static final int abc_grow_fade_in_from_bottom = 2130771970;
        public static final int abc_popup_enter = 2130771971;
        public static final int abc_popup_exit = 2130771972;
        public static final int abc_shrink_fade_out_from_bottom = 2130771973;
        public static final int abc_slide_in_bottom = 2130771974;
        public static final int abc_slide_in_top = 2130771975;
        public static final int abc_slide_out_bottom = 2130771976;
        public static final int abc_slide_out_top = 2130771977;
        public static final int abc_tooltip_enter = 2130771978;
        public static final int abc_tooltip_exit = 2130771979;
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
        public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
        public static final int design_bottom_sheet_slide_in = 2130771992;
        public static final int design_bottom_sheet_slide_out = 2130771993;
        public static final int design_snackbar_in = 2130771994;
        public static final int design_snackbar_out = 2130771995;
        public static final int mtrl_bottom_sheet_slide_in = 2130771996;
        public static final int mtrl_bottom_sheet_slide_out = 2130771997;
        public static final int mtrl_card_lowers_interpolator = 2130771998;

        private anim() {
        }
    }

    public static final class animator {
        public static final int design_appbar_state_list_animator = 2130837504;
        public static final int design_fab_hide_motion_spec = 2130837505;
        public static final int design_fab_show_motion_spec = 2130837506;
        public static final int mtrl_btn_state_list_anim = 2130837507;
        public static final int mtrl_btn_unelevated_state_list_anim = 2130837508;
        public static final int mtrl_card_state_list_anim = 2130837509;
        public static final int mtrl_chip_state_list_anim = 2130837510;
        public static final int mtrl_extended_fab_change_size_motion_spec = 2130837511;
        public static final int mtrl_extended_fab_hide_motion_spec = 2130837512;
        public static final int mtrl_extended_fab_show_motion_spec = 2130837513;
        public static final int mtrl_extended_fab_state_list_animator = 2130837514;
        public static final int mtrl_fab_hide_motion_spec = 2130837515;
        public static final int mtrl_fab_show_motion_spec = 2130837516;
        public static final int mtrl_fab_transformation_sheet_collapse_spec = 2130837517;
        public static final int mtrl_fab_transformation_sheet_expand_spec = 2130837518;

        private animator() {
        }
    }

    public static final class attr {
        public static final int actionBarDivider = 2130903040;
        public static final int actionBarItemBackground = 2130903041;
        public static final int actionBarPopupTheme = 2130903042;
        public static final int actionBarSize = 2130903043;
        public static final int actionBarSplitStyle = 2130903044;
        public static final int actionBarStyle = 2130903045;
        public static final int actionBarTabBarStyle = 2130903046;
        public static final int actionBarTabStyle = 2130903047;
        public static final int actionBarTabTextStyle = 2130903048;
        public static final int actionBarTheme = 2130903049;
        public static final int actionBarWidgetTheme = 2130903050;
        public static final int actionButtonStyle = 2130903051;
        public static final int actionDropDownStyle = 2130903052;
        public static final int actionLayout = 2130903053;
        public static final int actionMenuTextAppearance = 2130903054;
        public static final int actionMenuTextColor = 2130903055;
        public static final int actionModeBackground = 2130903056;
        public static final int actionModeCloseButtonStyle = 2130903057;
        public static final int actionModeCloseDrawable = 2130903058;
        public static final int actionModeCopyDrawable = 2130903059;
        public static final int actionModeCutDrawable = 2130903060;
        public static final int actionModeFindDrawable = 2130903061;
        public static final int actionModePasteDrawable = 2130903062;
        public static final int actionModePopupWindowStyle = 2130903063;
        public static final int actionModeSelectAllDrawable = 2130903064;
        public static final int actionModeShareDrawable = 2130903065;
        public static final int actionModeSplitBackground = 2130903066;
        public static final int actionModeStyle = 2130903067;
        public static final int actionModeWebSearchDrawable = 2130903068;
        public static final int actionOverflowButtonStyle = 2130903069;
        public static final int actionOverflowMenuStyle = 2130903070;
        public static final int actionProviderClass = 2130903071;
        public static final int actionTextColorAlpha = 2130903072;
        public static final int actionViewClass = 2130903073;
        public static final int activityChooserViewStyle = 2130903074;
        public static final int alertDialogButtonGroupStyle = 2130903075;
        public static final int alertDialogCenterButtons = 2130903076;
        public static final int alertDialogStyle = 2130903077;
        public static final int alertDialogTheme = 2130903078;
        public static final int allowStacking = 2130903079;
        public static final int alpha = 2130903080;
        public static final int alphabeticModifiers = 2130903081;
        public static final int animationMode = 2130903082;
        public static final int appBarLayoutStyle = 2130903083;
        public static final int arrowHeadLength = 2130903084;
        public static final int arrowShaftLength = 2130903085;
        public static final int autoCompleteTextViewStyle = 2130903086;
        public static final int autoSizeMaxTextSize = 2130903087;
        public static final int autoSizeMinTextSize = 2130903088;
        public static final int autoSizePresetSizes = 2130903089;
        public static final int autoSizeStepGranularity = 2130903090;
        public static final int autoSizeTextType = 2130903091;
        public static final int background = 2130903092;
        public static final int backgroundColor = 2130903093;
        public static final int backgroundInsetBottom = 2130903094;
        public static final int backgroundInsetEnd = 2130903095;
        public static final int backgroundInsetStart = 2130903096;
        public static final int backgroundInsetTop = 2130903097;
        public static final int backgroundOverlayColorAlpha = 2130903098;
        public static final int backgroundSplit = 2130903099;
        public static final int backgroundStacked = 2130903100;
        public static final int backgroundTint = 2130903101;
        public static final int backgroundTintMode = 2130903102;
        public static final int badgeGravity = 2130903103;
        public static final int badgeStyle = 2130903104;
        public static final int badgeTextColor = 2130903105;
        public static final int barLength = 2130903106;
        public static final int barrierAllowsGoneWidgets = 2130903107;
        public static final int barrierDirection = 2130903108;
        public static final int behavior_autoHide = 2130903109;
        public static final int behavior_autoShrink = 2130903110;
        public static final int behavior_expandedOffset = 2130903111;
        public static final int behavior_fitToContents = 2130903112;
        public static final int behavior_halfExpandedRatio = 2130903113;
        public static final int behavior_hideable = 2130903114;
        public static final int behavior_overlapTop = 2130903115;
        public static final int behavior_peekHeight = 2130903116;
        public static final int behavior_saveFlags = 2130903117;
        public static final int behavior_skipCollapsed = 2130903118;
        public static final int borderWidth = 2130903119;
        public static final int borderlessButtonStyle = 2130903120;
        public static final int bottomAppBarStyle = 2130903121;
        public static final int bottomNavigationStyle = 2130903122;
        public static final int bottomSheetDialogTheme = 2130903123;
        public static final int bottomSheetStyle = 2130903124;
        public static final int boxBackgroundColor = 2130903125;
        public static final int boxBackgroundMode = 2130903126;
        public static final int boxCollapsedPaddingTop = 2130903127;
        public static final int boxCornerRadiusBottomEnd = 2130903128;
        public static final int boxCornerRadiusBottomStart = 2130903129;
        public static final int boxCornerRadiusTopEnd = 2130903130;
        public static final int boxCornerRadiusTopStart = 2130903131;
        public static final int boxStrokeColor = 2130903132;
        public static final int boxStrokeWidth = 2130903133;
        public static final int boxStrokeWidthFocused = 2130903134;
        public static final int buttonBarButtonStyle = 2130903135;
        public static final int buttonBarNegativeButtonStyle = 2130903136;
        public static final int buttonBarNeutralButtonStyle = 2130903137;
        public static final int buttonBarPositiveButtonStyle = 2130903138;
        public static final int buttonBarStyle = 2130903139;
        public static final int buttonCompat = 2130903140;
        public static final int buttonGravity = 2130903141;
        public static final int buttonIconDimen = 2130903142;
        public static final int buttonPanelSideLayout = 2130903143;
        public static final int buttonSize = 2130903144;
        public static final int buttonStyle = 2130903145;
        public static final int buttonStyleSmall = 2130903146;
        public static final int buttonTint = 2130903147;
        public static final int buttonTintMode = 2130903148;
        public static final int cardBackgroundColor = 2130903149;
        public static final int cardCornerRadius = 2130903150;
        public static final int cardElevation = 2130903151;
        public static final int cardForegroundColor = 2130903152;
        public static final int cardMaxElevation = 2130903153;
        public static final int cardPreventCornerOverlap = 2130903154;
        public static final int cardUseCompatPadding = 2130903155;
        public static final int cardViewStyle = 2130903156;
        public static final int chainUseRtl = 2130903157;
        public static final int checkboxStyle = 2130903158;
        public static final int checkedButton = 2130903159;
        public static final int checkedChip = 2130903160;
        public static final int checkedIcon = 2130903161;
        public static final int checkedIconEnabled = 2130903162;
        public static final int checkedIconTint = 2130903163;
        public static final int checkedIconVisible = 2130903164;
        public static final int checkedTextViewStyle = 2130903165;
        public static final int chipBackgroundColor = 2130903166;
        public static final int chipCornerRadius = 2130903167;
        public static final int chipEndPadding = 2130903168;
        public static final int chipGroupStyle = 2130903169;
        public static final int chipIcon = 2130903170;
        public static final int chipIconEnabled = 2130903171;
        public static final int chipIconSize = 2130903172;
        public static final int chipIconTint = 2130903173;
        public static final int chipIconVisible = 2130903174;
        public static final int chipMinHeight = 2130903175;
        public static final int chipMinTouchTargetSize = 2130903176;
        public static final int chipSpacing = 2130903177;
        public static final int chipSpacingHorizontal = 2130903178;
        public static final int chipSpacingVertical = 2130903179;
        public static final int chipStandaloneStyle = 2130903180;
        public static final int chipStartPadding = 2130903181;
        public static final int chipStrokeColor = 2130903182;
        public static final int chipStrokeWidth = 2130903183;
        public static final int chipStyle = 2130903184;
        public static final int chipSurfaceColor = 2130903185;
        public static final int circleCrop = 2130903186;
        public static final int civ_border_color = 2130903187;
        public static final int civ_border_overlay = 2130903188;
        public static final int civ_border_width = 2130903189;
        public static final int civ_circle_background_color = 2130903190;
        public static final int closeIcon = 2130903191;
        public static final int closeIconEnabled = 2130903192;
        public static final int closeIconEndPadding = 2130903193;
        public static final int closeIconSize = 2130903194;
        public static final int closeIconStartPadding = 2130903195;
        public static final int closeIconTint = 2130903196;
        public static final int closeIconVisible = 2130903197;
        public static final int closeItemLayout = 2130903198;
        public static final int collapseContentDescription = 2130903199;
        public static final int collapseIcon = 2130903200;
        public static final int collapsedTitleGravity = 2130903201;
        public static final int collapsedTitleTextAppearance = 2130903202;
        public static final int color = 2130903203;
        public static final int colorAccent = 2130903204;
        public static final int colorBackgroundFloating = 2130903205;
        public static final int colorButtonNormal = 2130903206;
        public static final int colorControlActivated = 2130903207;
        public static final int colorControlHighlight = 2130903208;
        public static final int colorControlNormal = 2130903209;
        public static final int colorError = 2130903210;
        public static final int colorOnBackground = 2130903211;
        public static final int colorOnError = 2130903212;
        public static final int colorOnPrimary = 2130903213;
        public static final int colorOnPrimarySurface = 2130903214;
        public static final int colorOnSecondary = 2130903215;
        public static final int colorOnSurface = 2130903216;
        public static final int colorPrimary = 2130903217;
        public static final int colorPrimaryDark = 2130903218;
        public static final int colorPrimarySurface = 2130903219;
        public static final int colorPrimaryVariant = 2130903220;
        public static final int colorScheme = 2130903221;
        public static final int colorSecondary = 2130903222;
        public static final int colorSecondaryVariant = 2130903223;
        public static final int colorSurface = 2130903224;
        public static final int colorSwitchThumbNormal = 2130903225;
        public static final int commitIcon = 2130903226;
        public static final int constraintSet = 2130903227;
        public static final int constraint_referenced_ids = 2130903228;
        public static final int content = 2130903229;
        public static final int contentDescription = 2130903230;
        public static final int contentInsetEnd = 2130903231;
        public static final int contentInsetEndWithActions = 2130903232;
        public static final int contentInsetLeft = 2130903233;
        public static final int contentInsetRight = 2130903234;
        public static final int contentInsetStart = 2130903235;
        public static final int contentInsetStartWithNavigation = 2130903236;
        public static final int contentPadding = 2130903237;
        public static final int contentPaddingBottom = 2130903238;
        public static final int contentPaddingLeft = 2130903239;
        public static final int contentPaddingRight = 2130903240;
        public static final int contentPaddingTop = 2130903241;
        public static final int contentScrim = 2130903242;
        public static final int controlBackground = 2130903243;
        public static final int coordinatorLayoutStyle = 2130903244;
        public static final int cornerFamily = 2130903245;
        public static final int cornerFamilyBottomLeft = 2130903246;
        public static final int cornerFamilyBottomRight = 2130903247;
        public static final int cornerFamilyTopLeft = 2130903248;
        public static final int cornerFamilyTopRight = 2130903249;
        public static final int cornerRadius = 2130903250;
        public static final int cornerSize = 2130903251;
        public static final int cornerSizeBottomLeft = 2130903252;
        public static final int cornerSizeBottomRight = 2130903253;
        public static final int cornerSizeTopLeft = 2130903254;
        public static final int cornerSizeTopRight = 2130903255;
        public static final int counterEnabled = 2130903256;
        public static final int counterMaxLength = 2130903257;
        public static final int counterOverflowTextAppearance = 2130903258;
        public static final int counterOverflowTextColor = 2130903259;
        public static final int counterTextAppearance = 2130903260;
        public static final int counterTextColor = 2130903261;
        public static final int customNavigationLayout = 2130903262;
        public static final int dayInvalidStyle = 2130903263;
        public static final int daySelectedStyle = 2130903264;
        public static final int dayStyle = 2130903265;
        public static final int dayTodayStyle = 2130903266;
        public static final int defaultQueryHint = 2130903267;
        public static final int dialogCornerRadius = 2130903268;
        public static final int dialogPreferredPadding = 2130903269;
        public static final int dialogTheme = 2130903270;
        public static final int displayOptions = 2130903271;
        public static final int divider = 2130903272;
        public static final int dividerHorizontal = 2130903273;
        public static final int dividerPadding = 2130903274;
        public static final int dividerVertical = 2130903275;
        public static final int drawableBottomCompat = 2130903276;
        public static final int drawableEndCompat = 2130903277;
        public static final int drawableLeftCompat = 2130903278;
        public static final int drawableRightCompat = 2130903279;
        public static final int drawableSize = 2130903280;
        public static final int drawableStartCompat = 2130903281;
        public static final int drawableTint = 2130903282;
        public static final int drawableTintMode = 2130903283;
        public static final int drawableTopCompat = 2130903284;
        public static final int drawerArrowStyle = 2130903285;
        public static final int dropDownListViewStyle = 2130903286;
        public static final int dropdownListPreferredItemHeight = 2130903287;
        public static final int editTextBackground = 2130903288;
        public static final int editTextColor = 2130903289;
        public static final int editTextStyle = 2130903290;
        public static final int elevation = 2130903291;
        public static final int elevationOverlayColor = 2130903292;
        public static final int elevationOverlayEnabled = 2130903293;
        public static final int emptyVisibility = 2130903294;
        public static final int endIconCheckable = 2130903295;
        public static final int endIconContentDescription = 2130903296;
        public static final int endIconDrawable = 2130903297;
        public static final int endIconMode = 2130903298;
        public static final int endIconTint = 2130903299;
        public static final int endIconTintMode = 2130903300;
        public static final int enforceMaterialTheme = 2130903301;
        public static final int enforceTextAppearance = 2130903302;
        public static final int ensureMinTouchTargetSize = 2130903303;
        public static final int errorEnabled = 2130903304;
        public static final int errorIconDrawable = 2130903305;
        public static final int errorIconTint = 2130903306;
        public static final int errorIconTintMode = 2130903307;
        public static final int errorTextAppearance = 2130903308;
        public static final int errorTextColor = 2130903309;
        public static final int expandActivityOverflowButtonDrawable = 2130903310;
        public static final int expanded = 2130903311;
        public static final int expandedTitleGravity = 2130903312;
        public static final int expandedTitleMargin = 2130903313;
        public static final int expandedTitleMarginBottom = 2130903314;
        public static final int expandedTitleMarginEnd = 2130903315;
        public static final int expandedTitleMarginStart = 2130903316;
        public static final int expandedTitleMarginTop = 2130903317;
        public static final int expandedTitleTextAppearance = 2130903318;
        public static final int extendMotionSpec = 2130903319;
        public static final int extendedFloatingActionButtonStyle = 2130903320;
        public static final int fabAlignmentMode = 2130903321;
        public static final int fabAnimationMode = 2130903322;
        public static final int fabCradleMargin = 2130903323;
        public static final int fabCradleRoundedCornerRadius = 2130903324;
        public static final int fabCradleVerticalOffset = 2130903325;
        public static final int fabCustomSize = 2130903326;
        public static final int fabSize = 2130903327;
        public static final int fastScrollEnabled = 2130903328;
        public static final int fastScrollHorizontalThumbDrawable = 2130903329;
        public static final int fastScrollHorizontalTrackDrawable = 2130903330;
        public static final int fastScrollVerticalThumbDrawable = 2130903331;
        public static final int fastScrollVerticalTrackDrawable = 2130903332;
        public static final int firstBaselineToTopHeight = 2130903333;
        public static final int floatingActionButtonStyle = 2130903334;
        public static final int font = 2130903335;
        public static final int fontFamily = 2130903336;
        public static final int fontProviderAuthority = 2130903337;
        public static final int fontProviderCerts = 2130903338;
        public static final int fontProviderFetchStrategy = 2130903339;
        public static final int fontProviderFetchTimeout = 2130903340;
        public static final int fontProviderPackage = 2130903341;
        public static final int fontProviderQuery = 2130903342;
        public static final int fontStyle = 2130903343;
        public static final int fontVariationSettings = 2130903344;
        public static final int fontWeight = 2130903345;
        public static final int foregroundInsidePadding = 2130903346;
        public static final int gapBetweenBars = 2130903347;
        public static final int goIcon = 2130903348;
        public static final int headerLayout = 2130903349;
        public static final int height = 2130903350;
        public static final int helperText = 2130903351;
        public static final int helperTextEnabled = 2130903352;
        public static final int helperTextTextAppearance = 2130903353;
        public static final int helperTextTextColor = 2130903354;
        public static final int hideMotionSpec = 2130903355;
        public static final int hideOnContentScroll = 2130903356;
        public static final int hideOnScroll = 2130903357;
        public static final int hintAnimationEnabled = 2130903358;
        public static final int hintEnabled = 2130903359;
        public static final int hintTextAppearance = 2130903360;
        public static final int hintTextColor = 2130903361;
        public static final int homeAsUpIndicator = 2130903362;
        public static final int homeLayout = 2130903363;
        public static final int hoveredFocusedTranslationZ = 2130903364;
        public static final int icon = 2130903365;
        public static final int iconEndPadding = 2130903366;
        public static final int iconGravity = 2130903367;
        public static final int iconPadding = 2130903368;
        public static final int iconSize = 2130903369;
        public static final int iconStartPadding = 2130903370;
        public static final int iconTint = 2130903371;
        public static final int iconTintMode = 2130903372;
        public static final int iconifiedByDefault = 2130903373;
        public static final int imageAspectRatio = 2130903374;
        public static final int imageAspectRatioAdjust = 2130903375;
        public static final int imageButtonStyle = 2130903376;
        public static final int indeterminateProgressStyle = 2130903377;
        public static final int initialActivityCount = 2130903378;
        public static final int insetForeground = 2130903379;
        public static final int isLightTheme = 2130903380;
        public static final int isMaterialTheme = 2130903381;
        public static final int itemBackground = 2130903382;
        public static final int itemFillColor = 2130903383;
        public static final int itemHorizontalPadding = 2130903384;
        public static final int itemHorizontalTranslationEnabled = 2130903385;
        public static final int itemIconPadding = 2130903386;
        public static final int itemIconSize = 2130903387;
        public static final int itemIconTint = 2130903388;
        public static final int itemMaxLines = 2130903389;
        public static final int itemPadding = 2130903390;
        public static final int itemRippleColor = 2130903391;
        public static final int itemShapeAppearance = 2130903392;
        public static final int itemShapeAppearanceOverlay = 2130903393;
        public static final int itemShapeFillColor = 2130903394;
        public static final int itemShapeInsetBottom = 2130903395;
        public static final int itemShapeInsetEnd = 2130903396;
        public static final int itemShapeInsetStart = 2130903397;
        public static final int itemShapeInsetTop = 2130903398;
        public static final int itemSpacing = 2130903399;
        public static final int itemStrokeColor = 2130903400;
        public static final int itemStrokeWidth = 2130903401;
        public static final int itemTextAppearance = 2130903402;
        public static final int itemTextAppearanceActive = 2130903403;
        public static final int itemTextAppearanceInactive = 2130903404;
        public static final int itemTextColor = 2130903405;
        public static final int keylines = 2130903406;
        public static final int labelVisibilityMode = 2130903407;
        public static final int lastBaselineToBottomHeight = 2130903408;
        public static final int layout = 2130903409;
        public static final int layoutManager = 2130903410;
        public static final int layout_anchor = 2130903411;
        public static final int layout_anchorGravity = 2130903412;
        public static final int layout_behavior = 2130903413;
        public static final int layout_collapseMode = 2130903414;
        public static final int layout_collapseParallaxMultiplier = 2130903415;
        public static final int layout_constrainedHeight = 2130903416;
        public static final int layout_constrainedWidth = 2130903417;
        public static final int layout_constraintBaseline_creator = 2130903418;
        public static final int layout_constraintBaseline_toBaselineOf = 2130903419;
        public static final int layout_constraintBottom_creator = 2130903420;
        public static final int layout_constraintBottom_toBottomOf = 2130903421;
        public static final int layout_constraintBottom_toTopOf = 2130903422;
        public static final int layout_constraintCircle = 2130903423;
        public static final int layout_constraintCircleAngle = 2130903424;
        public static final int layout_constraintCircleRadius = 2130903425;
        public static final int layout_constraintDimensionRatio = 2130903426;
        public static final int layout_constraintEnd_toEndOf = 2130903427;
        public static final int layout_constraintEnd_toStartOf = 2130903428;
        public static final int layout_constraintGuide_begin = 2130903429;
        public static final int layout_constraintGuide_end = 2130903430;
        public static final int layout_constraintGuide_percent = 2130903431;
        public static final int layout_constraintHeight_default = 2130903432;
        public static final int layout_constraintHeight_max = 2130903433;
        public static final int layout_constraintHeight_min = 2130903434;
        public static final int layout_constraintHeight_percent = 2130903435;
        public static final int layout_constraintHorizontal_bias = 2130903436;
        public static final int layout_constraintHorizontal_chainStyle = 2130903437;
        public static final int layout_constraintHorizontal_weight = 2130903438;
        public static final int layout_constraintLeft_creator = 2130903439;
        public static final int layout_constraintLeft_toLeftOf = 2130903440;
        public static final int layout_constraintLeft_toRightOf = 2130903441;
        public static final int layout_constraintRight_creator = 2130903442;
        public static final int layout_constraintRight_toLeftOf = 2130903443;
        public static final int layout_constraintRight_toRightOf = 2130903444;
        public static final int layout_constraintStart_toEndOf = 2130903445;
        public static final int layout_constraintStart_toStartOf = 2130903446;
        public static final int layout_constraintTop_creator = 2130903447;
        public static final int layout_constraintTop_toBottomOf = 2130903448;
        public static final int layout_constraintTop_toTopOf = 2130903449;
        public static final int layout_constraintVertical_bias = 2130903450;
        public static final int layout_constraintVertical_chainStyle = 2130903451;
        public static final int layout_constraintVertical_weight = 2130903452;
        public static final int layout_constraintWidth_default = 2130903453;
        public static final int layout_constraintWidth_max = 2130903454;
        public static final int layout_constraintWidth_min = 2130903455;
        public static final int layout_constraintWidth_percent = 2130903456;
        public static final int layout_dodgeInsetEdges = 2130903457;
        public static final int layout_editor_absoluteX = 2130903458;
        public static final int layout_editor_absoluteY = 2130903459;
        public static final int layout_goneMarginBottom = 2130903460;
        public static final int layout_goneMarginEnd = 2130903461;
        public static final int layout_goneMarginLeft = 2130903462;
        public static final int layout_goneMarginRight = 2130903463;
        public static final int layout_goneMarginStart = 2130903464;
        public static final int layout_goneMarginTop = 2130903465;
        public static final int layout_insetEdge = 2130903466;
        public static final int layout_keyline = 2130903467;
        public static final int layout_optimizationLevel = 2130903468;
        public static final int layout_scrollFlags = 2130903469;
        public static final int layout_scrollInterpolator = 2130903470;
        public static final int liftOnScroll = 2130903471;
        public static final int liftOnScrollTargetViewId = 2130903472;
        public static final int lineHeight = 2130903473;
        public static final int lineSpacing = 2130903474;
        public static final int listChoiceBackgroundIndicator = 2130903475;
        public static final int listChoiceIndicatorMultipleAnimated = 2130903476;
        public static final int listChoiceIndicatorSingleAnimated = 2130903477;
        public static final int listDividerAlertDialog = 2130903478;
        public static final int listItemLayout = 2130903479;
        public static final int listLayout = 2130903480;
        public static final int listMenuViewStyle = 2130903481;
        public static final int listPopupWindowStyle = 2130903482;
        public static final int listPreferredItemHeight = 2130903483;
        public static final int listPreferredItemHeightLarge = 2130903484;
        public static final int listPreferredItemHeightSmall = 2130903485;
        public static final int listPreferredItemPaddingEnd = 2130903486;
        public static final int listPreferredItemPaddingLeft = 2130903487;
        public static final int listPreferredItemPaddingRight = 2130903488;
        public static final int listPreferredItemPaddingStart = 2130903489;
        public static final int logo = 2130903490;
        public static final int logoDescription = 2130903491;
        public static final int materialAlertDialogBodyTextStyle = 2130903492;
        public static final int materialAlertDialogTheme = 2130903493;
        public static final int materialAlertDialogTitleIconStyle = 2130903494;
        public static final int materialAlertDialogTitlePanelStyle = 2130903495;
        public static final int materialAlertDialogTitleTextStyle = 2130903496;
        public static final int materialButtonOutlinedStyle = 2130903497;
        public static final int materialButtonStyle = 2130903498;
        public static final int materialButtonToggleGroupStyle = 2130903499;
        public static final int materialCalendarDay = 2130903500;
        public static final int materialCalendarFullscreenTheme = 2130903501;
        public static final int materialCalendarHeaderConfirmButton = 2130903502;
        public static final int materialCalendarHeaderDivider = 2130903503;
        public static final int materialCalendarHeaderLayout = 2130903504;
        public static final int materialCalendarHeaderSelection = 2130903505;
        public static final int materialCalendarHeaderTitle = 2130903506;
        public static final int materialCalendarHeaderToggleButton = 2130903507;
        public static final int materialCalendarStyle = 2130903508;
        public static final int materialCalendarTheme = 2130903509;
        public static final int materialCardViewStyle = 2130903510;
        public static final int materialThemeOverlay = 2130903511;
        public static final int maxActionInlineWidth = 2130903512;
        public static final int maxButtonHeight = 2130903513;
        public static final int maxCharacterCount = 2130903514;
        public static final int maxImageSize = 2130903515;
        public static final int measureWithLargestChild = 2130903516;
        public static final int menu = 2130903517;
        public static final int minTouchTargetSize = 2130903518;
        public static final int multiChoiceItemLayout = 2130903519;
        public static final int navigationContentDescription = 2130903520;
        public static final int navigationIcon = 2130903521;
        public static final int navigationMode = 2130903522;
        public static final int navigationViewStyle = 2130903523;
        public static final int number = 2130903524;
        public static final int numericModifiers = 2130903525;
        public static final int overlapAnchor = 2130903526;
        public static final int paddingBottomNoButtons = 2130903527;
        public static final int paddingEnd = 2130903528;
        public static final int paddingStart = 2130903529;
        public static final int paddingTopNoTitle = 2130903530;
        public static final int panelBackground = 2130903531;
        public static final int panelMenuListTheme = 2130903532;
        public static final int panelMenuListWidth = 2130903533;
        public static final int passwordToggleContentDescription = 2130903534;
        public static final int passwordToggleDrawable = 2130903535;
        public static final int passwordToggleEnabled = 2130903536;
        public static final int passwordToggleTint = 2130903537;
        public static final int passwordToggleTintMode = 2130903538;
        public static final int popupMenuBackground = 2130903539;
        public static final int popupMenuStyle = 2130903540;
        public static final int popupTheme = 2130903541;
        public static final int popupWindowStyle = 2130903542;
        public static final int preserveIconSpacing = 2130903543;
        public static final int pressedTranslationZ = 2130903544;
        public static final int progressBarPadding = 2130903545;
        public static final int progressBarStyle = 2130903546;
        public static final int queryBackground = 2130903547;
        public static final int queryHint = 2130903548;
        public static final int radioButtonStyle = 2130903549;
        public static final int rangeFillColor = 2130903550;
        public static final int ratingBarStyle = 2130903551;
        public static final int ratingBarStyleIndicator = 2130903552;
        public static final int ratingBarStyleSmall = 2130903553;
        public static final int recyclerViewStyle = 2130903554;
        public static final int reverseLayout = 2130903555;
        public static final int rippleColor = 2130903556;
        public static final int scopeUris = 2130903557;
        public static final int scrimAnimationDuration = 2130903558;
        public static final int scrimBackground = 2130903559;
        public static final int scrimVisibleHeightTrigger = 2130903560;
        public static final int searchHintIcon = 2130903561;
        public static final int searchIcon = 2130903562;
        public static final int searchViewStyle = 2130903563;
        public static final int seekBarStyle = 2130903564;
        public static final int selectableItemBackground = 2130903565;
        public static final int selectableItemBackgroundBorderless = 2130903566;
        public static final int shapeAppearance = 2130903567;
        public static final int shapeAppearanceLargeComponent = 2130903568;
        public static final int shapeAppearanceMediumComponent = 2130903569;
        public static final int shapeAppearanceOverlay = 2130903570;
        public static final int shapeAppearanceSmallComponent = 2130903571;
        public static final int showAsAction = 2130903572;
        public static final int showDividers = 2130903573;
        public static final int showMotionSpec = 2130903574;
        public static final int showText = 2130903575;
        public static final int showTitle = 2130903576;
        public static final int shrinkMotionSpec = 2130903577;
        public static final int singleChoiceItemLayout = 2130903578;
        public static final int singleLine = 2130903579;
        public static final int singleSelection = 2130903580;
        public static final int snackbarButtonStyle = 2130903581;
        public static final int snackbarStyle = 2130903582;
        public static final int spanCount = 2130903583;
        public static final int spinBars = 2130903584;
        public static final int spinnerDropDownItemStyle = 2130903585;
        public static final int spinnerStyle = 2130903586;
        public static final int splitTrack = 2130903587;
        public static final int srcCompat = 2130903588;
        public static final int stackFromEnd = 2130903589;
        public static final int startIconCheckable = 2130903590;
        public static final int startIconContentDescription = 2130903591;
        public static final int startIconDrawable = 2130903592;
        public static final int startIconTint = 2130903593;
        public static final int startIconTintMode = 2130903594;
        public static final int state_above_anchor = 2130903595;
        public static final int state_collapsed = 2130903596;
        public static final int state_collapsible = 2130903597;
        public static final int state_dragged = 2130903598;
        public static final int state_liftable = 2130903599;
        public static final int state_lifted = 2130903600;
        public static final int statusBarBackground = 2130903601;
        public static final int statusBarForeground = 2130903602;
        public static final int statusBarScrim = 2130903603;
        public static final int strokeColor = 2130903604;
        public static final int strokeWidth = 2130903605;
        public static final int subMenuArrow = 2130903606;
        public static final int submitBackground = 2130903607;
        public static final int subtitle = 2130903608;
        public static final int subtitleTextAppearance = 2130903609;
        public static final int subtitleTextColor = 2130903610;
        public static final int subtitleTextStyle = 2130903611;
        public static final int suggestionRowLayout = 2130903612;
        public static final int switchMinWidth = 2130903613;
        public static final int switchPadding = 2130903614;
        public static final int switchStyle = 2130903615;
        public static final int switchTextAppearance = 2130903616;
        public static final int tabBackground = 2130903617;
        public static final int tabContentStart = 2130903618;
        public static final int tabGravity = 2130903619;
        public static final int tabIconTint = 2130903620;
        public static final int tabIconTintMode = 2130903621;
        public static final int tabIndicator = 2130903622;
        public static final int tabIndicatorAnimationDuration = 2130903623;
        public static final int tabIndicatorColor = 2130903624;
        public static final int tabIndicatorFullWidth = 2130903625;
        public static final int tabIndicatorGravity = 2130903626;
        public static final int tabIndicatorHeight = 2130903627;
        public static final int tabInlineLabel = 2130903628;
        public static final int tabMaxWidth = 2130903629;
        public static final int tabMinWidth = 2130903630;
        public static final int tabMode = 2130903631;
        public static final int tabPadding = 2130903632;
        public static final int tabPaddingBottom = 2130903633;
        public static final int tabPaddingEnd = 2130903634;
        public static final int tabPaddingStart = 2130903635;
        public static final int tabPaddingTop = 2130903636;
        public static final int tabRippleColor = 2130903637;
        public static final int tabSelectedTextColor = 2130903638;
        public static final int tabStyle = 2130903639;
        public static final int tabTextAppearance = 2130903640;
        public static final int tabTextColor = 2130903641;
        public static final int tabUnboundedRipple = 2130903642;
        public static final int textAllCaps = 2130903643;
        public static final int textAppearanceBody1 = 2130903644;
        public static final int textAppearanceBody2 = 2130903645;
        public static final int textAppearanceButton = 2130903646;
        public static final int textAppearanceCaption = 2130903647;
        public static final int textAppearanceHeadline1 = 2130903648;
        public static final int textAppearanceHeadline2 = 2130903649;
        public static final int textAppearanceHeadline3 = 2130903650;
        public static final int textAppearanceHeadline4 = 2130903651;
        public static final int textAppearanceHeadline5 = 2130903652;
        public static final int textAppearanceHeadline6 = 2130903653;
        public static final int textAppearanceLargePopupMenu = 2130903654;
        public static final int textAppearanceLineHeightEnabled = 2130903655;
        public static final int textAppearanceListItem = 2130903656;
        public static final int textAppearanceListItemSecondary = 2130903657;
        public static final int textAppearanceListItemSmall = 2130903658;
        public static final int textAppearanceOverline = 2130903659;
        public static final int textAppearancePopupMenuHeader = 2130903660;
        public static final int textAppearanceSearchResultSubtitle = 2130903661;
        public static final int textAppearanceSearchResultTitle = 2130903662;
        public static final int textAppearanceSmallPopupMenu = 2130903663;
        public static final int textAppearanceSubtitle1 = 2130903664;
        public static final int textAppearanceSubtitle2 = 2130903665;
        public static final int textColorAlertDialogListItem = 2130903666;
        public static final int textColorSearchUrl = 2130903667;
        public static final int textEndPadding = 2130903668;
        public static final int textInputStyle = 2130903669;
        public static final int textLocale = 2130903670;
        public static final int textStartPadding = 2130903671;
        public static final int theme = 2130903672;
        public static final int themeLineHeight = 2130903673;
        public static final int thickness = 2130903674;
        public static final int thumbTextPadding = 2130903675;
        public static final int thumbTint = 2130903676;
        public static final int thumbTintMode = 2130903677;
        public static final int tickMark = 2130903678;
        public static final int tickMarkTint = 2130903679;
        public static final int tickMarkTintMode = 2130903680;
        public static final int tint = 2130903681;
        public static final int tintMode = 2130903682;
        public static final int title = 2130903683;
        public static final int titleEnabled = 2130903684;
        public static final int titleMargin = 2130903685;
        public static final int titleMarginBottom = 2130903686;
        public static final int titleMarginEnd = 2130903687;
        public static final int titleMarginStart = 2130903688;
        public static final int titleMarginTop = 2130903689;
        public static final int titleMargins = 2130903690;
        public static final int titleTextAppearance = 2130903691;
        public static final int titleTextColor = 2130903692;
        public static final int titleTextStyle = 2130903693;
        public static final int toolbarId = 2130903694;
        public static final int toolbarNavigationButtonStyle = 2130903695;
        public static final int toolbarStyle = 2130903696;
        public static final int tooltipForegroundColor = 2130903697;
        public static final int tooltipFrameBackground = 2130903698;
        public static final int tooltipText = 2130903699;
        public static final int track = 2130903700;
        public static final int trackTint = 2130903701;
        public static final int trackTintMode = 2130903702;
        public static final int ttcIndex = 2130903703;
        public static final int useCompatPadding = 2130903704;
        public static final int useMaterialThemeColors = 2130903705;
        public static final int viewInflaterClass = 2130903706;
        public static final int voiceIcon = 2130903707;
        public static final int windowActionBar = 2130903708;
        public static final int windowActionBarOverlay = 2130903709;
        public static final int windowActionModeOverlay = 2130903710;
        public static final int windowFixedHeightMajor = 2130903711;
        public static final int windowFixedHeightMinor = 2130903712;
        public static final int windowFixedWidthMajor = 2130903713;
        public static final int windowFixedWidthMinor = 2130903714;
        public static final int windowMinWidthMajor = 2130903715;
        public static final int windowMinWidthMinor = 2130903716;
        public static final int windowNoTitle = 2130903717;
        public static final int yearSelectedStyle = 2130903718;
        public static final int yearStyle = 2130903719;
        public static final int yearTodayStyle = 2130903720;

        private attr() {
        }
    }

    public static final class bool {
        public static final int abc_action_bar_embed_tabs = 2130968576;
        public static final int abc_allow_stacked_button_bar = 2130968577;
        public static final int abc_config_actionMenuItemAllCaps = 2130968578;
        public static final int mtrl_btn_textappearance_all_caps = 2130968579;

        private bool() {
        }
    }

    public static final class color {
        public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
        public static final int abc_background_cache_hint_selector_material_light = 2131034113;
        public static final int abc_btn_colored_borderless_text_material = 2131034114;
        public static final int abc_btn_colored_text_material = 2131034115;
        public static final int abc_color_highlight_material = 2131034116;
        public static final int abc_hint_foreground_material_dark = 2131034117;
        public static final int abc_hint_foreground_material_light = 2131034118;
        public static final int abc_input_method_navigation_guard = 2131034119;
        public static final int abc_primary_text_disable_only_material_dark = 2131034120;
        public static final int abc_primary_text_disable_only_material_light = 2131034121;
        public static final int abc_primary_text_material_dark = 2131034122;
        public static final int abc_primary_text_material_light = 2131034123;
        public static final int abc_search_url_text = 2131034124;
        public static final int abc_search_url_text_normal = 2131034125;
        public static final int abc_search_url_text_pressed = 2131034126;
        public static final int abc_search_url_text_selected = 2131034127;
        public static final int abc_secondary_text_material_dark = 2131034128;
        public static final int abc_secondary_text_material_light = 2131034129;
        public static final int abc_tint_btn_checkable = 2131034130;
        public static final int abc_tint_default = 2131034131;
        public static final int abc_tint_edittext = 2131034132;
        public static final int abc_tint_seek_thumb = 2131034133;
        public static final int abc_tint_spinner = 2131034134;
        public static final int abc_tint_switch_track = 2131034135;
        public static final int accent_material_dark = 2131034136;
        public static final int accent_material_light = 2131034137;
        public static final int background_floating_material_dark = 2131034138;
        public static final int background_floating_material_light = 2131034139;
        public static final int background_material_dark = 2131034140;
        public static final int background_material_light = 2131034141;
        public static final int black = 2131034142;
        public static final int blue = 2131034143;
        public static final int bright_foreground_disabled_material_dark = 2131034144;
        public static final int bright_foreground_disabled_material_light = 2131034145;
        public static final int bright_foreground_inverse_material_dark = 2131034146;
        public static final int bright_foreground_inverse_material_light = 2131034147;
        public static final int bright_foreground_material_dark = 2131034148;
        public static final int bright_foreground_material_light = 2131034149;
        public static final int button_material_dark = 2131034150;
        public static final int button_material_light = 2131034151;
        public static final int cardview_dark_background = 2131034152;
        public static final int cardview_light_background = 2131034153;
        public static final int cardview_shadow_end_color = 2131034154;
        public static final int cardview_shadow_start_color = 2131034155;
        public static final int checkbox_themeable_attribute_color = 2131034156;
        public static final int colorAccent = 2131034157;
        public static final int colorPrimary = 2131034158;
        public static final int colorPrimaryDark = 2131034159;
        public static final int common_google_signin_btn_text_dark = 2131034160;
        public static final int common_google_signin_btn_text_dark_default = 2131034161;
        public static final int common_google_signin_btn_text_dark_disabled = 2131034162;
        public static final int common_google_signin_btn_text_dark_focused = 2131034163;
        public static final int common_google_signin_btn_text_dark_pressed = 2131034164;
        public static final int common_google_signin_btn_text_light = 2131034165;
        public static final int common_google_signin_btn_text_light_default = 2131034166;
        public static final int common_google_signin_btn_text_light_disabled = 2131034167;
        public static final int common_google_signin_btn_text_light_focused = 2131034168;
        public static final int common_google_signin_btn_text_light_pressed = 2131034169;
        public static final int common_google_signin_btn_tint = 2131034170;
        public static final int design_bottom_navigation_shadow_color = 2131034171;
        public static final int design_box_stroke_color = 2131034172;
        public static final int design_dark_default_color_background = 2131034173;
        public static final int design_dark_default_color_error = 2131034174;
        public static final int design_dark_default_color_on_background = 2131034175;
        public static final int design_dark_default_color_on_error = 2131034176;
        public static final int design_dark_default_color_on_primary = 2131034177;
        public static final int design_dark_default_color_on_secondary = 2131034178;
        public static final int design_dark_default_color_on_surface = 2131034179;
        public static final int design_dark_default_color_primary = 2131034180;
        public static final int design_dark_default_color_primary_dark = 2131034181;
        public static final int design_dark_default_color_primary_variant = 2131034182;
        public static final int design_dark_default_color_secondary = 2131034183;
        public static final int design_dark_default_color_secondary_variant = 2131034184;
        public static final int design_dark_default_color_surface = 2131034185;
        public static final int design_default_color_background = 2131034186;
        public static final int design_default_color_error = 2131034187;
        public static final int design_default_color_on_background = 2131034188;
        public static final int design_default_color_on_error = 2131034189;
        public static final int design_default_color_on_primary = 2131034190;
        public static final int design_default_color_on_secondary = 2131034191;
        public static final int design_default_color_on_surface = 2131034192;
        public static final int design_default_color_primary = 2131034193;
        public static final int design_default_color_primary_dark = 2131034194;
        public static final int design_default_color_primary_variant = 2131034195;
        public static final int design_default_color_secondary = 2131034196;
        public static final int design_default_color_secondary_variant = 2131034197;
        public static final int design_default_color_surface = 2131034198;
        public static final int design_error = 2131034199;
        public static final int design_fab_shadow_end_color = 2131034200;
        public static final int design_fab_shadow_mid_color = 2131034201;
        public static final int design_fab_shadow_start_color = 2131034202;
        public static final int design_fab_stroke_end_inner_color = 2131034203;
        public static final int design_fab_stroke_end_outer_color = 2131034204;
        public static final int design_fab_stroke_top_inner_color = 2131034205;
        public static final int design_fab_stroke_top_outer_color = 2131034206;
        public static final int design_icon_tint = 2131034207;
        public static final int design_snackbar_background_color = 2131034208;
        public static final int dim_foreground_disabled_material_dark = 2131034209;
        public static final int dim_foreground_disabled_material_light = 2131034210;
        public static final int dim_foreground_material_dark = 2131034211;
        public static final int dim_foreground_material_light = 2131034212;
        public static final int error_color_material_dark = 2131034213;
        public static final int error_color_material_light = 2131034214;
        public static final int foreground_material_dark = 2131034215;
        public static final int foreground_material_light = 2131034216;
        public static final int grey = 2131034217;
        public static final int highlighted_text_material_dark = 2131034218;
        public static final int highlighted_text_material_light = 2131034219;
        public static final int material_blue_grey_800 = 2131034220;
        public static final int material_blue_grey_900 = 2131034221;
        public static final int material_blue_grey_950 = 2131034222;
        public static final int material_deep_teal_200 = 2131034223;
        public static final int material_deep_teal_500 = 2131034224;
        public static final int material_grey_100 = 2131034225;
        public static final int material_grey_300 = 2131034226;
        public static final int material_grey_50 = 2131034227;
        public static final int material_grey_600 = 2131034228;
        public static final int material_grey_800 = 2131034229;
        public static final int material_grey_850 = 2131034230;
        public static final int material_grey_900 = 2131034231;
        public static final int material_on_background_disabled = 2131034232;
        public static final int material_on_background_emphasis_high_type = 2131034233;
        public static final int material_on_background_emphasis_medium = 2131034234;
        public static final int material_on_primary_disabled = 2131034235;
        public static final int material_on_primary_emphasis_high_type = 2131034236;
        public static final int material_on_primary_emphasis_medium = 2131034237;
        public static final int material_on_surface_disabled = 2131034238;
        public static final int material_on_surface_emphasis_high_type = 2131034239;
        public static final int material_on_surface_emphasis_medium = 2131034240;
        public static final int mtrl_bottom_nav_colored_item_tint = 2131034241;
        public static final int mtrl_bottom_nav_colored_ripple_color = 2131034242;
        public static final int mtrl_bottom_nav_item_tint = 2131034243;
        public static final int mtrl_bottom_nav_ripple_color = 2131034244;
        public static final int mtrl_btn_bg_color_selector = 2131034245;
        public static final int mtrl_btn_ripple_color = 2131034246;
        public static final int mtrl_btn_stroke_color_selector = 2131034247;
        public static final int mtrl_btn_text_btn_bg_color_selector = 2131034248;
        public static final int mtrl_btn_text_btn_ripple_color = 2131034249;
        public static final int mtrl_btn_text_color_disabled = 2131034250;
        public static final int mtrl_btn_text_color_selector = 2131034251;
        public static final int mtrl_btn_transparent_bg_color = 2131034252;
        public static final int mtrl_calendar_item_stroke_color = 2131034253;
        public static final int mtrl_calendar_selected_range = 2131034254;
        public static final int mtrl_card_view_foreground = 2131034255;
        public static final int mtrl_card_view_ripple = 2131034256;
        public static final int mtrl_chip_background_color = 2131034257;
        public static final int mtrl_chip_close_icon_tint = 2131034258;
        public static final int mtrl_chip_ripple_color = 2131034259;
        public static final int mtrl_chip_surface_color = 2131034260;
        public static final int mtrl_chip_text_color = 2131034261;
        public static final int mtrl_choice_chip_background_color = 2131034262;
        public static final int mtrl_choice_chip_ripple_color = 2131034263;
        public static final int mtrl_choice_chip_text_color = 2131034264;
        public static final int mtrl_error = 2131034265;
        public static final int mtrl_extended_fab_bg_color_selector = 2131034266;
        public static final int mtrl_extended_fab_ripple_color = 2131034267;
        public static final int mtrl_extended_fab_text_color_selector = 2131034268;
        public static final int mtrl_fab_ripple_color = 2131034269;
        public static final int mtrl_filled_background_color = 2131034270;
        public static final int mtrl_filled_icon_tint = 2131034271;
        public static final int mtrl_filled_stroke_color = 2131034272;
        public static final int mtrl_indicator_text_color = 2131034273;
        public static final int mtrl_navigation_item_background_color = 2131034274;
        public static final int mtrl_navigation_item_icon_tint = 2131034275;
        public static final int mtrl_navigation_item_text_color = 2131034276;
        public static final int mtrl_on_primary_text_btn_text_color_selector = 2131034277;
        public static final int mtrl_outlined_icon_tint = 2131034278;
        public static final int mtrl_outlined_stroke_color = 2131034279;
        public static final int mtrl_popupmenu_overlay_color = 2131034280;
        public static final int mtrl_scrim_color = 2131034281;
        public static final int mtrl_tabs_colored_ripple_color = 2131034282;
        public static final int mtrl_tabs_icon_color_selector = 2131034283;
        public static final int mtrl_tabs_icon_color_selector_colored = 2131034284;
        public static final int mtrl_tabs_legacy_text_color_selector = 2131034285;
        public static final int mtrl_tabs_ripple_color = 2131034286;
        public static final int mtrl_text_btn_text_color_selector = 2131034287;
        public static final int mtrl_textinput_default_box_stroke_color = 2131034288;
        public static final int mtrl_textinput_disabled_color = 2131034289;
        public static final int mtrl_textinput_filled_box_default_background_color = 2131034290;
        public static final int mtrl_textinput_focused_box_stroke_color = 2131034291;
        public static final int mtrl_textinput_hovered_box_stroke_color = 2131034292;
        public static final int notification_action_color_filter = 2131034293;
        public static final int notification_icon_bg_color = 2131034294;
        public static final int notification_material_background_media_default_color = 2131034295;
        public static final int orange = 2131034296;
        public static final int pink = 2131034297;
        public static final int primary_dark_material_dark = 2131034298;
        public static final int primary_dark_material_light = 2131034299;
        public static final int primary_material_dark = 2131034300;
        public static final int primary_material_light = 2131034301;
        public static final int primary_text_default_material_dark = 2131034302;
        public static final int primary_text_default_material_light = 2131034303;
        public static final int primary_text_disabled_material_dark = 2131034304;
        public static final int primary_text_disabled_material_light = 2131034305;
        public static final int purple = 2131034306;
        public static final int red = 2131034307;
        public static final int ripple_material_dark = 2131034308;
        public static final int ripple_material_light = 2131034309;
        public static final int secondary_text_default_material_dark = 2131034310;
        public static final int secondary_text_default_material_light = 2131034311;
        public static final int secondary_text_disabled_material_dark = 2131034312;
        public static final int secondary_text_disabled_material_light = 2131034313;
        public static final int switch_thumb_disabled_material_dark = 2131034314;
        public static final int switch_thumb_disabled_material_light = 2131034315;
        public static final int switch_thumb_material_dark = 2131034316;
        public static final int switch_thumb_material_light = 2131034317;
        public static final int switch_thumb_normal_material_dark = 2131034318;
        public static final int switch_thumb_normal_material_light = 2131034319;
        public static final int test_mtrl_calendar_day = 2131034320;
        public static final int test_mtrl_calendar_day_selected = 2131034321;
        public static final int tooltip_background_dark = 2131034322;
        public static final int tooltip_background_light = 2131034323;
        public static final int white = 2131034324;

        private color() {
        }
    }

    public static final class dimen {
        public static final int abc_action_bar_content_inset_material = 2131099648;
        public static final int abc_action_bar_content_inset_with_nav = 2131099649;
        public static final int abc_action_bar_default_height_material = 2131099650;
        public static final int abc_action_bar_default_padding_end_material = 2131099651;
        public static final int abc_action_bar_default_padding_start_material = 2131099652;
        public static final int abc_action_bar_elevation_material = 2131099653;
        public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
        public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
        public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
        public static final int abc_action_bar_stacked_max_height = 2131099657;
        public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
        public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
        public static final int abc_action_button_min_height_material = 2131099661;
        public static final int abc_action_button_min_width_material = 2131099662;
        public static final int abc_action_button_min_width_overflow_material = 2131099663;
        public static final int abc_alert_dialog_button_bar_height = 2131099664;
        public static final int abc_alert_dialog_button_dimen = 2131099665;
        public static final int abc_button_inset_horizontal_material = 2131099666;
        public static final int abc_button_inset_vertical_material = 2131099667;
        public static final int abc_button_padding_horizontal_material = 2131099668;
        public static final int abc_button_padding_vertical_material = 2131099669;
        public static final int abc_cascading_menus_min_smallest_width = 2131099670;
        public static final int abc_config_prefDialogWidth = 2131099671;
        public static final int abc_control_corner_material = 2131099672;
        public static final int abc_control_inset_material = 2131099673;
        public static final int abc_control_padding_material = 2131099674;
        public static final int abc_dialog_corner_radius_material = 2131099675;
        public static final int abc_dialog_fixed_height_major = 2131099676;
        public static final int abc_dialog_fixed_height_minor = 2131099677;
        public static final int abc_dialog_fixed_width_major = 2131099678;
        public static final int abc_dialog_fixed_width_minor = 2131099679;
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
        public static final int abc_dialog_list_padding_top_no_title = 2131099681;
        public static final int abc_dialog_min_width_major = 2131099682;
        public static final int abc_dialog_min_width_minor = 2131099683;
        public static final int abc_dialog_padding_material = 2131099684;
        public static final int abc_dialog_padding_top_material = 2131099685;
        public static final int abc_dialog_title_divider_material = 2131099686;
        public static final int abc_disabled_alpha_material_dark = 2131099687;
        public static final int abc_disabled_alpha_material_light = 2131099688;
        public static final int abc_dropdownitem_icon_width = 2131099689;
        public static final int abc_dropdownitem_text_padding_left = 2131099690;
        public static final int abc_dropdownitem_text_padding_right = 2131099691;
        public static final int abc_edit_text_inset_bottom_material = 2131099692;
        public static final int abc_edit_text_inset_horizontal_material = 2131099693;
        public static final int abc_edit_text_inset_top_material = 2131099694;
        public static final int abc_floating_window_z = 2131099695;
        public static final int abc_list_item_height_large_material = 2131099696;
        public static final int abc_list_item_height_material = 2131099697;
        public static final int abc_list_item_height_small_material = 2131099698;
        public static final int abc_list_item_padding_horizontal_material = 2131099699;
        public static final int abc_panel_menu_list_width = 2131099700;
        public static final int abc_progress_bar_height_material = 2131099701;
        public static final int abc_search_view_preferred_height = 2131099702;
        public static final int abc_search_view_preferred_width = 2131099703;
        public static final int abc_seekbar_track_background_height_material = 2131099704;
        public static final int abc_seekbar_track_progress_height_material = 2131099705;
        public static final int abc_select_dialog_padding_start_material = 2131099706;
        public static final int abc_switch_padding = 2131099707;
        public static final int abc_text_size_body_1_material = 2131099708;
        public static final int abc_text_size_body_2_material = 2131099709;
        public static final int abc_text_size_button_material = 2131099710;
        public static final int abc_text_size_caption_material = 2131099711;
        public static final int abc_text_size_display_1_material = 2131099712;
        public static final int abc_text_size_display_2_material = 2131099713;
        public static final int abc_text_size_display_3_material = 2131099714;
        public static final int abc_text_size_display_4_material = 2131099715;
        public static final int abc_text_size_headline_material = 2131099716;
        public static final int abc_text_size_large_material = 2131099717;
        public static final int abc_text_size_medium_material = 2131099718;
        public static final int abc_text_size_menu_header_material = 2131099719;
        public static final int abc_text_size_menu_material = 2131099720;
        public static final int abc_text_size_small_material = 2131099721;
        public static final int abc_text_size_subhead_material = 2131099722;
        public static final int abc_text_size_subtitle_material_toolbar = 2131099723;
        public static final int abc_text_size_title_material = 2131099724;
        public static final int abc_text_size_title_material_toolbar = 2131099725;
        public static final int action_bar_size = 2131099726;
        public static final int appcompat_dialog_background_inset = 2131099727;
        public static final int cardview_compat_inset_shadow = 2131099728;
        public static final int cardview_default_elevation = 2131099729;
        public static final int cardview_default_radius = 2131099730;
        public static final int compat_button_inset_horizontal_material = 2131099731;
        public static final int compat_button_inset_vertical_material = 2131099732;
        public static final int compat_button_padding_horizontal_material = 2131099733;
        public static final int compat_button_padding_vertical_material = 2131099734;
        public static final int compat_control_corner_material = 2131099735;
        public static final int compat_notification_large_icon_max_height = 2131099736;
        public static final int compat_notification_large_icon_max_width = 2131099737;
        public static final int default_dimension = 2131099738;
        public static final int design_appbar_elevation = 2131099739;
        public static final int design_bottom_navigation_active_item_max_width = 2131099740;
        public static final int design_bottom_navigation_active_item_min_width = 2131099741;
        public static final int design_bottom_navigation_active_text_size = 2131099742;
        public static final int design_bottom_navigation_elevation = 2131099743;
        public static final int design_bottom_navigation_height = 2131099744;
        public static final int design_bottom_navigation_icon_size = 2131099745;
        public static final int design_bottom_navigation_item_max_width = 2131099746;
        public static final int design_bottom_navigation_item_min_width = 2131099747;
        public static final int design_bottom_navigation_margin = 2131099748;
        public static final int design_bottom_navigation_shadow_height = 2131099749;
        public static final int design_bottom_navigation_text_size = 2131099750;
        public static final int design_bottom_sheet_elevation = 2131099751;
        public static final int design_bottom_sheet_modal_elevation = 2131099752;
        public static final int design_bottom_sheet_peek_height_min = 2131099753;
        public static final int design_fab_border_width = 2131099754;
        public static final int design_fab_elevation = 2131099755;
        public static final int design_fab_image_size = 2131099756;
        public static final int design_fab_size_mini = 2131099757;
        public static final int design_fab_size_normal = 2131099758;
        public static final int design_fab_translation_z_hovered_focused = 2131099759;
        public static final int design_fab_translation_z_pressed = 2131099760;
        public static final int design_navigation_elevation = 2131099761;
        public static final int design_navigation_icon_padding = 2131099762;
        public static final int design_navigation_icon_size = 2131099763;
        public static final int design_navigation_item_horizontal_padding = 2131099764;
        public static final int design_navigation_item_icon_padding = 2131099765;
        public static final int design_navigation_max_width = 2131099766;
        public static final int design_navigation_padding_bottom = 2131099767;
        public static final int design_navigation_separator_vertical_padding = 2131099768;
        public static final int design_snackbar_action_inline_max_width = 2131099769;
        public static final int design_snackbar_action_text_color_alpha = 2131099770;
        public static final int design_snackbar_background_corner_radius = 2131099771;
        public static final int design_snackbar_elevation = 2131099772;
        public static final int design_snackbar_extra_spacing_horizontal = 2131099773;
        public static final int design_snackbar_max_width = 2131099774;
        public static final int design_snackbar_min_width = 2131099775;
        public static final int design_snackbar_padding_horizontal = 2131099776;
        public static final int design_snackbar_padding_vertical = 2131099777;
        public static final int design_snackbar_padding_vertical_2lines = 2131099778;
        public static final int design_snackbar_text_size = 2131099779;
        public static final int design_tab_max_width = 2131099780;
        public static final int design_tab_scrollable_min_width = 2131099781;
        public static final int design_tab_text_size = 2131099782;
        public static final int design_tab_text_size_2line = 2131099783;
        public static final int design_textinput_caption_translate_y = 2131099784;
        public static final int disabled_alpha_material_dark = 2131099785;
        public static final int disabled_alpha_material_light = 2131099786;
        public static final int fastscroll_default_thickness = 2131099787;
        public static final int fastscroll_margin = 2131099788;
        public static final int fastscroll_minimum_range = 2131099789;
        public static final int highlight_alpha_material_colored = 2131099790;
        public static final int highlight_alpha_material_dark = 2131099791;
        public static final int highlight_alpha_material_light = 2131099792;
        public static final int hint_alpha_material_dark = 2131099793;
        public static final int hint_alpha_material_light = 2131099794;
        public static final int hint_pressed_alpha_material_dark = 2131099795;
        public static final int hint_pressed_alpha_material_light = 2131099796;
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131099797;
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131099798;
        public static final int item_touch_helper_swipe_escape_velocity = 2131099799;
        public static final int material_emphasis_disabled = 2131099800;
        public static final int material_emphasis_high_type = 2131099801;
        public static final int material_emphasis_medium = 2131099802;
        public static final int material_text_view_test_line_height = 2131099803;
        public static final int material_text_view_test_line_height_override = 2131099804;
        public static final int mtrl_alert_dialog_background_inset_bottom = 2131099805;
        public static final int mtrl_alert_dialog_background_inset_end = 2131099806;
        public static final int mtrl_alert_dialog_background_inset_start = 2131099807;
        public static final int mtrl_alert_dialog_background_inset_top = 2131099808;
        public static final int mtrl_alert_dialog_picker_background_inset = 2131099809;
        public static final int mtrl_badge_horizontal_edge_offset = 2131099810;
        public static final int mtrl_badge_long_text_horizontal_padding = 2131099811;
        public static final int mtrl_badge_radius = 2131099812;
        public static final int mtrl_badge_text_horizontal_edge_offset = 2131099813;
        public static final int mtrl_badge_text_size = 2131099814;
        public static final int mtrl_badge_with_text_radius = 2131099815;
        public static final int mtrl_bottomappbar_fabOffsetEndMode = 2131099816;
        public static final int mtrl_bottomappbar_fab_bottom_margin = 2131099817;
        public static final int mtrl_bottomappbar_fab_cradle_margin = 2131099818;
        public static final int mtrl_bottomappbar_fab_cradle_rounded_corner_radius = 2131099819;
        public static final int mtrl_bottomappbar_fab_cradle_vertical_offset = 2131099820;
        public static final int mtrl_bottomappbar_height = 2131099821;
        public static final int mtrl_btn_corner_radius = 2131099822;
        public static final int mtrl_btn_dialog_btn_min_width = 2131099823;
        public static final int mtrl_btn_disabled_elevation = 2131099824;
        public static final int mtrl_btn_disabled_z = 2131099825;
        public static final int mtrl_btn_elevation = 2131099826;
        public static final int mtrl_btn_focused_z = 2131099827;
        public static final int mtrl_btn_hovered_z = 2131099828;
        public static final int mtrl_btn_icon_btn_padding_left = 2131099829;
        public static final int mtrl_btn_icon_padding = 2131099830;
        public static final int mtrl_btn_inset = 2131099831;
        public static final int mtrl_btn_letter_spacing = 2131099832;
        public static final int mtrl_btn_padding_bottom = 2131099833;
        public static final int mtrl_btn_padding_left = 2131099834;
        public static final int mtrl_btn_padding_right = 2131099835;
        public static final int mtrl_btn_padding_top = 2131099836;
        public static final int mtrl_btn_pressed_z = 2131099837;
        public static final int mtrl_btn_stroke_size = 2131099838;
        public static final int mtrl_btn_text_btn_icon_padding = 2131099839;
        public static final int mtrl_btn_text_btn_padding_left = 2131099840;
        public static final int mtrl_btn_text_btn_padding_right = 2131099841;
        public static final int mtrl_btn_text_size = 2131099842;
        public static final int mtrl_btn_z = 2131099843;
        public static final int mtrl_calendar_action_height = 2131099844;
        public static final int mtrl_calendar_action_padding = 2131099845;
        public static final int mtrl_calendar_bottom_padding = 2131099846;
        public static final int mtrl_calendar_content_padding = 2131099847;
        public static final int mtrl_calendar_day_corner = 2131099848;
        public static final int mtrl_calendar_day_height = 2131099849;
        public static final int mtrl_calendar_day_horizontal_padding = 2131099850;
        public static final int mtrl_calendar_day_today_stroke = 2131099851;
        public static final int mtrl_calendar_day_vertical_padding = 2131099852;
        public static final int mtrl_calendar_day_width = 2131099853;
        public static final int mtrl_calendar_days_of_week_height = 2131099854;
        public static final int mtrl_calendar_dialog_background_inset = 2131099855;
        public static final int mtrl_calendar_header_content_padding = 2131099856;
        public static final int mtrl_calendar_header_content_padding_fullscreen = 2131099857;
        public static final int mtrl_calendar_header_divider_thickness = 2131099858;
        public static final int mtrl_calendar_header_height = 2131099859;
        public static final int mtrl_calendar_header_height_fullscreen = 2131099860;
        public static final int mtrl_calendar_header_selection_line_height = 2131099861;
        public static final int mtrl_calendar_header_text_padding = 2131099862;
        public static final int mtrl_calendar_header_toggle_margin_bottom = 2131099863;
        public static final int mtrl_calendar_header_toggle_margin_top = 2131099864;
        public static final int mtrl_calendar_landscape_header_width = 2131099865;
        public static final int mtrl_calendar_maximum_default_fullscreen_minor_axis = 2131099866;
        public static final int mtrl_calendar_month_horizontal_padding = 2131099867;
        public static final int mtrl_calendar_month_vertical_padding = 2131099868;
        public static final int mtrl_calendar_navigation_bottom_padding = 2131099869;
        public static final int mtrl_calendar_navigation_height = 2131099870;
        public static final int mtrl_calendar_navigation_top_padding = 2131099871;
        public static final int mtrl_calendar_pre_l_text_clip_padding = 2131099872;
        public static final int mtrl_calendar_selection_baseline_to_top_fullscreen = 2131099873;
        public static final int mtrl_calendar_selection_text_baseline_to_bottom = 2131099874;
        public static final int mtrl_calendar_selection_text_baseline_to_bottom_fullscreen = 2131099875;
        public static final int mtrl_calendar_selection_text_baseline_to_top = 2131099876;
        public static final int mtrl_calendar_text_input_padding_top = 2131099877;
        public static final int mtrl_calendar_title_baseline_to_top = 2131099878;
        public static final int mtrl_calendar_title_baseline_to_top_fullscreen = 2131099879;
        public static final int mtrl_calendar_year_corner = 2131099880;
        public static final int mtrl_calendar_year_height = 2131099881;
        public static final int mtrl_calendar_year_horizontal_padding = 2131099882;
        public static final int mtrl_calendar_year_vertical_padding = 2131099883;
        public static final int mtrl_calendar_year_width = 2131099884;
        public static final int mtrl_card_checked_icon_margin = 2131099885;
        public static final int mtrl_card_checked_icon_size = 2131099886;
        public static final int mtrl_card_corner_radius = 2131099887;
        public static final int mtrl_card_dragged_z = 2131099888;
        public static final int mtrl_card_elevation = 2131099889;
        public static final int mtrl_card_spacing = 2131099890;
        public static final int mtrl_chip_pressed_translation_z = 2131099891;
        public static final int mtrl_chip_text_size = 2131099892;
        public static final int mtrl_exposed_dropdown_menu_popup_elevation = 2131099893;
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_offset = 2131099894;
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_padding = 2131099895;
        public static final int mtrl_extended_fab_bottom_padding = 2131099896;
        public static final int mtrl_extended_fab_corner_radius = 2131099897;
        public static final int mtrl_extended_fab_disabled_elevation = 2131099898;
        public static final int mtrl_extended_fab_disabled_translation_z = 2131099899;
        public static final int mtrl_extended_fab_elevation = 2131099900;
        public static final int mtrl_extended_fab_end_padding = 2131099901;
        public static final int mtrl_extended_fab_end_padding_icon = 2131099902;
        public static final int mtrl_extended_fab_icon_size = 2131099903;
        public static final int mtrl_extended_fab_icon_text_spacing = 2131099904;
        public static final int mtrl_extended_fab_min_height = 2131099905;
        public static final int mtrl_extended_fab_min_width = 2131099906;
        public static final int mtrl_extended_fab_start_padding = 2131099907;
        public static final int mtrl_extended_fab_start_padding_icon = 2131099908;
        public static final int mtrl_extended_fab_top_padding = 2131099909;
        public static final int mtrl_extended_fab_translation_z_base = 2131099910;
        public static final int mtrl_extended_fab_translation_z_hovered_focused = 2131099911;
        public static final int mtrl_extended_fab_translation_z_pressed = 2131099912;
        public static final int mtrl_fab_elevation = 2131099913;
        public static final int mtrl_fab_min_touch_target = 2131099914;
        public static final int mtrl_fab_translation_z_hovered_focused = 2131099915;
        public static final int mtrl_fab_translation_z_pressed = 2131099916;
        public static final int mtrl_high_ripple_default_alpha = 2131099917;
        public static final int mtrl_high_ripple_focused_alpha = 2131099918;
        public static final int mtrl_high_ripple_hovered_alpha = 2131099919;
        public static final int mtrl_high_ripple_pressed_alpha = 2131099920;
        public static final int mtrl_large_touch_target = 2131099921;
        public static final int mtrl_low_ripple_default_alpha = 2131099922;
        public static final int mtrl_low_ripple_focused_alpha = 2131099923;
        public static final int mtrl_low_ripple_hovered_alpha = 2131099924;
        public static final int mtrl_low_ripple_pressed_alpha = 2131099925;
        public static final int mtrl_min_touch_target_size = 2131099926;
        public static final int mtrl_navigation_elevation = 2131099927;
        public static final int mtrl_navigation_item_horizontal_padding = 2131099928;
        public static final int mtrl_navigation_item_icon_padding = 2131099929;
        public static final int mtrl_navigation_item_icon_size = 2131099930;
        public static final int mtrl_navigation_item_shape_horizontal_margin = 2131099931;
        public static final int mtrl_navigation_item_shape_vertical_margin = 2131099932;
        public static final int mtrl_shape_corner_size_large_component = 2131099933;
        public static final int mtrl_shape_corner_size_medium_component = 2131099934;
        public static final int mtrl_shape_corner_size_small_component = 2131099935;
        public static final int mtrl_snackbar_action_text_color_alpha = 2131099936;
        public static final int mtrl_snackbar_background_corner_radius = 2131099937;
        public static final int mtrl_snackbar_background_overlay_color_alpha = 2131099938;
        public static final int mtrl_snackbar_margin = 2131099939;
        public static final int mtrl_switch_thumb_elevation = 2131099940;
        public static final int mtrl_textinput_box_corner_radius_medium = 2131099941;
        public static final int mtrl_textinput_box_corner_radius_small = 2131099942;
        public static final int mtrl_textinput_box_label_cutout_padding = 2131099943;
        public static final int mtrl_textinput_box_stroke_width_default = 2131099944;
        public static final int mtrl_textinput_box_stroke_width_focused = 2131099945;
        public static final int mtrl_textinput_end_icon_margin_start = 2131099946;
        public static final int mtrl_textinput_outline_box_expanded_padding = 2131099947;
        public static final int mtrl_textinput_start_icon_margin_end = 2131099948;
        public static final int mtrl_toolbar_default_height = 2131099949;
        public static final int notification_action_icon_size = 2131099950;
        public static final int notification_action_text_size = 2131099951;
        public static final int notification_big_circle_margin = 2131099952;
        public static final int notification_content_margin_start = 2131099953;
        public static final int notification_large_icon_height = 2131099954;
        public static final int notification_large_icon_width = 2131099955;
        public static final int notification_main_column_padding_top = 2131099956;
        public static final int notification_media_narrow_margin = 2131099957;
        public static final int notification_right_icon_size = 2131099958;
        public static final int notification_right_side_padding_top = 2131099959;
        public static final int notification_small_icon_background_padding = 2131099960;
        public static final int notification_small_icon_size_as_large = 2131099961;
        public static final int notification_subtext_size = 2131099962;
        public static final int notification_top_pad = 2131099963;
        public static final int notification_top_pad_large_text = 2131099964;
        public static final int subtitle_corner_radius = 2131099965;
        public static final int subtitle_outline_width = 2131099966;
        public static final int subtitle_shadow_offset = 2131099967;
        public static final int subtitle_shadow_radius = 2131099968;
        public static final int test_mtrl_calendar_day_cornerSize = 2131099969;
        public static final int tooltip_corner_radius = 2131099970;
        public static final int tooltip_horizontal_padding = 2131099971;
        public static final int tooltip_margin = 2131099972;
        public static final int tooltip_precise_anchor_extra_offset = 2131099973;
        public static final int tooltip_precise_anchor_threshold = 2131099974;
        public static final int tooltip_vertical_padding = 2131099975;
        public static final int tooltip_y_offset_non_touch = 2131099976;
        public static final int tooltip_y_offset_touch = 2131099977;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int abc_ab_share_pack_mtrl_alpha = 2131165191;
        public static final int abc_action_bar_item_background_material = 2131165192;
        public static final int abc_btn_borderless_material = 2131165193;
        public static final int abc_btn_check_material = 2131165194;
        public static final int abc_btn_check_material_anim = 2131165195;
        public static final int abc_btn_check_to_on_mtrl_000 = 2131165196;
        public static final int abc_btn_check_to_on_mtrl_015 = 2131165197;
        public static final int abc_btn_colored_material = 2131165198;
        public static final int abc_btn_default_mtrl_shape = 2131165199;
        public static final int abc_btn_radio_material = 2131165200;
        public static final int abc_btn_radio_material_anim = 2131165201;
        public static final int abc_btn_radio_to_on_mtrl_000 = 2131165202;
        public static final int abc_btn_radio_to_on_mtrl_015 = 2131165203;
        public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165204;
        public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165205;
        public static final int abc_cab_background_internal_bg = 2131165206;
        public static final int abc_cab_background_top_material = 2131165207;
        public static final int abc_cab_background_top_mtrl_alpha = 2131165208;
        public static final int abc_control_background_material = 2131165209;
        public static final int abc_dialog_material_background = 2131165210;
        public static final int abc_edit_text_material = 2131165211;
        public static final int abc_ic_ab_back_material = 2131165212;
        public static final int abc_ic_arrow_drop_right_black_24dp = 2131165213;
        public static final int abc_ic_clear_material = 2131165214;
        public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165215;
        public static final int abc_ic_go_search_api_material = 2131165216;
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165217;
        public static final int abc_ic_menu_cut_mtrl_alpha = 2131165218;
        public static final int abc_ic_menu_overflow_material = 2131165219;
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165220;
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165221;
        public static final int abc_ic_menu_share_mtrl_alpha = 2131165222;
        public static final int abc_ic_search_api_material = 2131165223;
        public static final int abc_ic_star_black_16dp = 2131165224;
        public static final int abc_ic_star_black_36dp = 2131165225;
        public static final int abc_ic_star_black_48dp = 2131165226;
        public static final int abc_ic_star_half_black_16dp = 2131165227;
        public static final int abc_ic_star_half_black_36dp = 2131165228;
        public static final int abc_ic_star_half_black_48dp = 2131165229;
        public static final int abc_ic_voice_search_api_material = 2131165230;
        public static final int abc_item_background_holo_dark = 2131165231;
        public static final int abc_item_background_holo_light = 2131165232;
        public static final int abc_list_divider_material = 2131165233;
        public static final int abc_list_divider_mtrl_alpha = 2131165234;
        public static final int abc_list_focused_holo = 2131165235;
        public static final int abc_list_longpressed_holo = 2131165236;
        public static final int abc_list_pressed_holo_dark = 2131165237;
        public static final int abc_list_pressed_holo_light = 2131165238;
        public static final int abc_list_selector_background_transition_holo_dark = 2131165239;
        public static final int abc_list_selector_background_transition_holo_light = 2131165240;
        public static final int abc_list_selector_disabled_holo_dark = 2131165241;
        public static final int abc_list_selector_disabled_holo_light = 2131165242;
        public static final int abc_list_selector_holo_dark = 2131165243;
        public static final int abc_list_selector_holo_light = 2131165244;
        public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165245;
        public static final int abc_popup_background_mtrl_mult = 2131165246;
        public static final int abc_ratingbar_indicator_material = 2131165247;
        public static final int abc_ratingbar_material = 2131165248;
        public static final int abc_ratingbar_small_material = 2131165249;
        public static final int abc_scrubber_control_off_mtrl_alpha = 2131165250;
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165251;
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165252;
        public static final int abc_scrubber_primary_mtrl_alpha = 2131165253;
        public static final int abc_scrubber_track_mtrl_alpha = 2131165254;
        public static final int abc_seekbar_thumb_material = 2131165255;
        public static final int abc_seekbar_tick_mark_material = 2131165256;
        public static final int abc_seekbar_track_material = 2131165257;
        public static final int abc_spinner_mtrl_am_alpha = 2131165258;
        public static final int abc_spinner_textfield_background_material = 2131165259;
        public static final int abc_switch_thumb_material = 2131165260;
        public static final int abc_switch_track_mtrl_alpha = 2131165261;
        public static final int abc_tab_indicator_material = 2131165262;
        public static final int abc_tab_indicator_mtrl_alpha = 2131165263;
        public static final int abc_text_cursor_material = 2131165264;
        public static final int abc_text_select_handle_left_mtrl_dark = 2131165265;
        public static final int abc_text_select_handle_left_mtrl_light = 2131165266;
        public static final int abc_text_select_handle_middle_mtrl_dark = 2131165267;
        public static final int abc_text_select_handle_middle_mtrl_light = 2131165268;
        public static final int abc_text_select_handle_right_mtrl_dark = 2131165269;
        public static final int abc_text_select_handle_right_mtrl_light = 2131165270;
        public static final int abc_textfield_activated_mtrl_alpha = 2131165271;
        public static final int abc_textfield_default_mtrl_alpha = 2131165272;
        public static final int abc_textfield_search_activated_mtrl_alpha = 2131165273;
        public static final int abc_textfield_search_default_mtrl_alpha = 2131165274;
        public static final int abc_textfield_search_material = 2131165275;
        public static final int abc_vector_test = 2131165276;
        public static final int avd_hide_password = 2131165277;
        public static final int avd_show_password = 2131165278;
        public static final int blue_button = 2131165279;
        public static final int border_bottom = 2131165280;
        public static final int border_grey = 2131165281;
        public static final int border_top = 2131165282;
        public static final int btn_checkbox_checked_mtrl = 2131165283;
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165284;
        public static final int btn_checkbox_unchecked_mtrl = 2131165285;
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165286;
        public static final int btn_radio_off_mtrl = 2131165287;
        public static final int btn_radio_off_to_on_mtrl_animation = 2131165288;
        public static final int btn_radio_on_mtrl = 2131165289;
        public static final int btn_radio_on_to_off_mtrl_animation = 2131165290;
        public static final int common_full_open_on_phone = 2131165291;
        public static final int common_google_signin_btn_icon_dark = 2131165292;
        public static final int common_google_signin_btn_icon_dark_focused = 2131165293;
        public static final int common_google_signin_btn_icon_dark_normal = 2131165294;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131165295;
        public static final int common_google_signin_btn_icon_disabled = 2131165296;
        public static final int common_google_signin_btn_icon_light = 2131165297;
        public static final int common_google_signin_btn_icon_light_focused = 2131165298;
        public static final int common_google_signin_btn_icon_light_normal = 2131165299;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131165300;
        public static final int common_google_signin_btn_text_dark = 2131165301;
        public static final int common_google_signin_btn_text_dark_focused = 2131165302;
        public static final int common_google_signin_btn_text_dark_normal = 2131165303;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131165304;
        public static final int common_google_signin_btn_text_disabled = 2131165305;
        public static final int common_google_signin_btn_text_light = 2131165306;
        public static final int common_google_signin_btn_text_light_focused = 2131165307;
        public static final int common_google_signin_btn_text_light_normal = 2131165308;
        public static final int common_google_signin_btn_text_light_normal_background = 2131165309;
        public static final int design_bottom_navigation_item_background = 2131165310;
        public static final int design_fab_background = 2131165311;
        public static final int design_ic_visibility = 2131165312;
        public static final int design_ic_visibility_off = 2131165313;
        public static final int design_password_eye = 2131165314;
        public static final int design_snackbar_background = 2131165315;
        public static final int googleg_disabled_color_18 = 2131165316;
        public static final int googleg_standard_color_18 = 2131165317;
        public static final int ic_add = 2131165318;
        public static final int ic_alert = 2131165319;
        public static final int ic_android = 2131165320;
        public static final int ic_back_arrow = 2131165321;
        public static final int ic_calendar_black_24dp = 2131165322;
        public static final int ic_camera = 2131165323;
        public static final int ic_check = 2131165324;
        public static final int ic_clear_black_24dp = 2131165325;
        public static final int ic_comments = 2131165326;
        public static final int ic_cross = 2131165327;
        public static final int ic_description = 2131165328;
        public static final int ic_display_name = 2131165329;
        public static final int ic_edit_black_24dp = 2131165330;
        public static final int ic_email = 2131165331;
        public static final int ic_heart = 2131165332;
        public static final int ic_home = 2131165333;
        public static final int ic_keyboard_arrow_left_black_24dp = 2131165334;
        public static final int ic_keyboard_arrow_right_black_24dp = 2131165335;
        public static final int ic_launcher_background = 2131165336;
        public static final int ic_launcher_foreground = 2131165337;
        public static final int ic_menu = 2131165338;
        public static final int ic_menu_arrow_down_black_24dp = 2131165339;
        public static final int ic_menu_arrow_up_black_24dp = 2131165340;
        public static final int ic_messages = 2131165341;
        public static final int ic_mtrl_checked_circle = 2131165342;
        public static final int ic_mtrl_chip_checked_black = 2131165343;
        public static final int ic_mtrl_chip_checked_circle = 2131165344;
        public static final int ic_mtrl_chip_close_circle = 2131165345;
        public static final int ic_phone = 2131165346;
        public static final int ic_red_heart = 2131165347;
        public static final int ic_search = 2131165348;
        public static final int ic_username = 2131165349;
        public static final int img = 2131165350;
        public static final int insta2 = 2131165351;
        public static final int insta_splash = 2131165352;
        public static final int instagram = 2131165353;
        public static final int login_screen_logo = 2131165354;
        public static final int mtrl_dialog_background = 2131165355;
        public static final int mtrl_dropdown_arrow = 2131165356;
        public static final int mtrl_ic_arrow_drop_down = 2131165357;
        public static final int mtrl_ic_arrow_drop_up = 2131165358;
        public static final int mtrl_ic_cancel = 2131165359;
        public static final int mtrl_ic_error = 2131165360;
        public static final int mtrl_popupmenu_background = 2131165361;
        public static final int mtrl_popupmenu_background_dark = 2131165362;
        public static final int mtrl_tabs_default_indicator = 2131165363;
        public static final int navigation_empty_icon = 2131165364;
        public static final int notification_action_background = 2131165365;
        public static final int notification_bg = 2131165366;
        public static final int notification_bg_low = 2131165367;
        public static final int notification_bg_low_normal = 2131165368;
        public static final int notification_bg_low_pressed = 2131165369;
        public static final int notification_bg_normal = 2131165370;
        public static final int notification_bg_normal_pressed = 2131165371;
        public static final int notification_icon_background = 2131165372;
        public static final int notification_template_icon_bg = 2131165373;
        public static final int notification_template_icon_low_bg = 2131165374;
        public static final int notification_tile_bg = 2131165375;
        public static final int notify_panel_notification_icon_bg = 2131165376;
        public static final int red_button = 2131165377;
        public static final int test_custom_background = 2131165378;
        public static final int tooltip_frame_dark = 2131165379;
        public static final int tooltip_frame_light = 2131165380;
        public static final int white_rounded_button = 2131165381;
        /* added by JADX */
        public static final int $avd_hide_password__0 = 2131165184;
        /* added by JADX */
        public static final int $avd_hide_password__1 = 2131165185;
        /* added by JADX */
        public static final int $avd_hide_password__2 = 2131165186;
        /* added by JADX */
        public static final int $avd_show_password__0 = 2131165187;
        /* added by JADX */
        public static final int $avd_show_password__1 = 2131165188;
        /* added by JADX */
        public static final int $avd_show_password__2 = 2131165189;
        /* added by JADX */
        public static final int $ic_launcher_foreground__0 = 2131165190;

        private drawable() {
        }
    }

    public static final class id {
        public static final int ALT = 2131230720;
        public static final int BOTTOM_END = 2131230721;
        public static final int BOTTOM_START = 2131230722;
        public static final int CTRL = 2131230723;
        public static final int FUNCTION = 2131230724;
        public static final int META = 2131230725;
        public static final int SHIFT = 2131230726;
        public static final int SYM = 2131230727;
        public static final int TOP_END = 2131230728;
        public static final int TOP_START = 2131230729;
        public static final int accessibility_action_clickable_span = 2131230730;
        public static final int accessibility_custom_action_0 = 2131230731;
        public static final int accessibility_custom_action_1 = 2131230732;
        public static final int accessibility_custom_action_10 = 2131230733;
        public static final int accessibility_custom_action_11 = 2131230734;
        public static final int accessibility_custom_action_12 = 2131230735;
        public static final int accessibility_custom_action_13 = 2131230736;
        public static final int accessibility_custom_action_14 = 2131230737;
        public static final int accessibility_custom_action_15 = 2131230738;
        public static final int accessibility_custom_action_16 = 2131230739;
        public static final int accessibility_custom_action_17 = 2131230740;
        public static final int accessibility_custom_action_18 = 2131230741;
        public static final int accessibility_custom_action_19 = 2131230742;
        public static final int accessibility_custom_action_2 = 2131230743;
        public static final int accessibility_custom_action_20 = 2131230744;
        public static final int accessibility_custom_action_21 = 2131230745;
        public static final int accessibility_custom_action_22 = 2131230746;
        public static final int accessibility_custom_action_23 = 2131230747;
        public static final int accessibility_custom_action_24 = 2131230748;
        public static final int accessibility_custom_action_25 = 2131230749;
        public static final int accessibility_custom_action_26 = 2131230750;
        public static final int accessibility_custom_action_27 = 2131230751;
        public static final int accessibility_custom_action_28 = 2131230752;
        public static final int accessibility_custom_action_29 = 2131230753;
        public static final int accessibility_custom_action_3 = 2131230754;
        public static final int accessibility_custom_action_30 = 2131230755;
        public static final int accessibility_custom_action_31 = 2131230756;
        public static final int accessibility_custom_action_4 = 2131230757;
        public static final int accessibility_custom_action_5 = 2131230758;
        public static final int accessibility_custom_action_6 = 2131230759;
        public static final int accessibility_custom_action_7 = 2131230760;
        public static final int accessibility_custom_action_8 = 2131230761;
        public static final int accessibility_custom_action_9 = 2131230762;
        public static final int action0 = 2131230763;
        public static final int action_bar = 2131230764;
        public static final int action_bar_activity_content = 2131230765;
        public static final int action_bar_container = 2131230766;
        public static final int action_bar_root = 2131230767;
        public static final int action_bar_spinner = 2131230768;
        public static final int action_bar_subtitle = 2131230769;
        public static final int action_bar_title = 2131230770;
        public static final int action_container = 2131230771;
        public static final int action_context_bar = 2131230772;
        public static final int action_divider = 2131230773;
        public static final int action_image = 2131230774;
        public static final int action_menu_divider = 2131230775;
        public static final int action_menu_presenter = 2131230776;
        public static final int action_mode_bar = 2131230777;
        public static final int action_mode_bar_stub = 2131230778;
        public static final int action_mode_close_button = 2131230779;
        public static final int action_text = 2131230780;
        public static final int actions = 2131230781;
        public static final int activity_chooser_view_content = 2131230782;
        public static final int add = 2131230783;
        public static final int addComment = 2131230784;
        public static final int adjust_height = 2131230785;
        public static final int adjust_width = 2131230786;
        public static final int alertTitle = 2131230787;
        public static final int all = 2131230788;
        public static final int always = 2131230789;
        public static final int android = 2131230790;
        public static final int async = 2131230791;
        public static final int auto = 2131230792;
        public static final int back = 2131230793;
        public static final int barrier = 2131230794;
        public static final int beginning = 2131230795;
        public static final int blocking = 2131230796;
        public static final int bottom = 2131230797;
        public static final int bottom_navigation = 2131230798;
        public static final int buttonPanel = 2131230799;
        public static final int cancel = 2131230800;
        public static final int cancel_action = 2131230801;
        public static final int cancel_button = 2131230802;
        public static final int center = 2131230803;
        public static final int center_horizontal = 2131230804;
        public static final int center_vertical = 2131230805;
        public static final int chains = 2131230806;
        public static final int changeDescription = 2131230807;
        public static final int changeDisplayName = 2131230808;
        public static final int changeEmail = 2131230809;
        public static final int changeImage = 2131230810;
        public static final int changePhone = 2131230811;
        public static final int changeUsername = 2131230812;
        public static final int check = 2131230813;
        public static final int checkbox = 2131230814;
        public static final int checked = 2131230815;
        public static final int chip = 2131230816;
        public static final int chip_group = 2131230817;
        public static final int chronometer = 2131230818;
        public static final int clear_text = 2131230819;
        public static final int clip_horizontal = 2131230820;
        public static final int clip_vertical = 2131230821;
        public static final int collapseActionView = 2131230822;
        public static final int comment = 2131230823;
        public static final int commentUsername = 2131230824;
        public static final int commentsImage = 2131230825;
        public static final int confirm = 2131230826;
        public static final int confirm_button = 2131230827;
        public static final int container = 2131230828;
        public static final int content = 2131230829;
        public static final int contentPanel = 2131230830;
        public static final int coordinator = 2131230831;
        public static final int custom = 2131230832;
        public static final int customPanel = 2131230833;
        public static final int cut = 2131230834;
        public static final int dark = 2131230835;
        public static final int date_picker_actions = 2131230836;
        public static final int decor_content_parent = 2131230837;
        public static final int default_activity_button = 2131230838;
        public static final int description = 2131230839;
        public static final int descriptionImage = 2131230840;
        public static final int descriptionPhoto = 2131230841;
        public static final int design_bottom_sheet = 2131230842;
        public static final int design_menu_item_action_area = 2131230843;
        public static final int design_menu_item_action_area_stub = 2131230844;
        public static final int design_menu_item_text = 2131230845;
        public static final int design_navigation_view = 2131230846;
        public static final int dialog_button = 2131230847;
        public static final int dimensions = 2131230848;
        public static final int direct = 2131230849;
        public static final int directorySpinner = 2131230850;
        public static final int disableHome = 2131230851;
        public static final int display_name = 2131230852;
        public static final int dropdown_menu = 2131230853;
        public static final int editProfile = 2131230854;
        public static final int editProfileProgressBar = 2131230855;
        public static final int edit_query = 2131230856;
        public static final int end = 2131230857;
        public static final int end_padder = 2131230858;
        public static final int enterAlways = 2131230859;
        public static final int enterAlwaysCollapsed = 2131230860;
        public static final int exitUntilCollapsed = 2131230861;
        public static final int expand_activities_button = 2131230862;
        public static final int expanded_menu = 2131230863;
        public static final int fade = 2131230864;
        public static final int fill = 2131230865;
        public static final int fill_horizontal = 2131230866;
        public static final int fill_vertical = 2131230867;
        public static final int filled = 2131230868;
        public static final int filter_chip = 2131230869;
        public static final int fitToContents = 2131230870;
        public static final int fixed = 2131230871;
        public static final int followButton = 2131230872;
        public static final int followers = 2131230873;
        public static final int following = 2131230874;
        public static final int forever = 2131230875;
        public static final int galleryImage = 2131230876;
        public static final int galleryProgressBar = 2131230877;
        public static final int ghost_view = 2131230878;
        public static final int ghost_view_holder = 2131230879;
        public static final int glide_custom_view_target_tag = 2131230880;
        public static final int gone = 2131230881;
        public static final int gridImageView = 2131230882;
        public static final int gridView = 2131230883;
        public static final int gridViewGallery = 2131230884;
        public static final int group_divider = 2131230885;
        public static final int groups = 2131230886;
        public static final int hideable = 2131230887;
        public static final int home = 2131230888;
        public static final int homeAsUp = 2131230889;
        public static final int icon = 2131230890;
        public static final int icon_group = 2131230891;
        public static final int icon_only = 2131230892;
        public static final int ifRoom = 2131230893;
        public static final int image = 2131230894;
        public static final int info = 2131230895;
        public static final int input_email = 2131230896;
        public static final int input_password = 2131230897;
        public static final int input_username = 2131230898;
        public static final int invisible = 2131230899;
        public static final int italic = 2131230900;
        public static final int item_touch_helper_previous_elevation = 2131230901;
        public static final int labeled = 2131230902;
        public static final int largeLabel = 2131230903;
        public static final int launchCamera = 2131230904;
        public static final int layout1 = 2131230905;
        public static final int layout2 = 2131230906;
        public static final int layout3 = 2131230907;
        public static final int layout4 = 2131230908;
        public static final int layout5 = 2131230909;
        public static final int left = 2131230910;
        public static final int light = 2131230911;
        public static final int likes = 2131230912;
        public static final int linLayout = 2131230913;
        public static final int line1 = 2131230914;
        public static final int line3 = 2131230915;
        public static final int link_signUp = 2131230916;
        public static final int listAccountSettings = 2131230917;
        public static final int listMode = 2131230918;
        public static final int list_item = 2131230919;
        public static final int loginProgressBar = 2131230920;
        public static final int login_button = 2131230921;
        public static final int mainLayout = 2131230922;
        public static final int masked = 2131230923;
        public static final int media_actions = 2131230924;
        public static final int menu_image = 2131230925;
        public static final int message = 2131230926;
        public static final int middle = 2131230927;
        public static final int mini = 2131230928;
        public static final int month_grid = 2131230929;
        public static final int month_navigation_bar = 2131230930;
        public static final int month_navigation_fragment_toggle = 2131230931;
        public static final int month_navigation_next = 2131230932;
        public static final int month_navigation_previous = 2131230933;
        public static final int month_title = 2131230934;
        public static final int mtrl_calendar_day_selector_frame = 2131230935;
        public static final int mtrl_calendar_days_of_week = 2131230936;
        public static final int mtrl_calendar_frame = 2131230937;
        public static final int mtrl_calendar_main_pane = 2131230938;
        public static final int mtrl_calendar_months = 2131230939;
        public static final int mtrl_calendar_selection_frame = 2131230940;
        public static final int mtrl_calendar_text_input_frame = 2131230941;
        public static final int mtrl_calendar_year_selector_frame = 2131230942;
        public static final int mtrl_card_checked_layer_id = 2131230943;
        public static final int mtrl_child_content_container = 2131230944;
        public static final int mtrl_internal_children_alpha_tag = 2131230945;
        public static final int mtrl_picker_fullscreen = 2131230946;
        public static final int mtrl_picker_header = 2131230947;
        public static final int mtrl_picker_header_selection_text = 2131230948;
        public static final int mtrl_picker_header_title_and_selection = 2131230949;
        public static final int mtrl_picker_header_toggle = 2131230950;
        public static final int mtrl_picker_text_input_date = 2131230951;
        public static final int mtrl_picker_text_input_range_end = 2131230952;
        public static final int mtrl_picker_text_input_range_start = 2131230953;
        public static final int mtrl_picker_title_text = 2131230954;
        public static final int multiply = 2131230955;
        public static final int name = 2131230956;
        public static final int navigation_header_container = 2131230957;
        public static final int never = 2131230958;
        public static final int next = 2131230959;
        public static final int noPosts = 2131230960;
        public static final int noScroll = 2131230961;
        public static final int none = 2131230962;
        public static final int normal = 2131230963;
        public static final int notification_background = 2131230964;
        public static final int notification_main_column = 2131230965;
        public static final int notification_main_column_container = 2131230966;
        public static final int off = 2131230967;
        public static final int on = 2131230968;
        public static final int outline = 2131230969;
        public static final int outlineHeart = 2131230970;
        public static final int packed = 2131230971;
        public static final int parallax = 2131230972;
        public static final int parent = 2131230973;
        public static final int parentPanel = 2131230974;
        public static final int parent_matrix = 2131230975;
        public static final int password_toggle = 2131230976;
        public static final int peekHeight = 2131230977;
        public static final int percent = 2131230978;
        public static final int pin = 2131230979;
        public static final int postImage = 2131230980;
        public static final int posts = 2131230981;
        public static final int privateInfo = 2131230982;
        public static final int profileMenu = 2131230983;
        public static final int profilePhoto = 2131230984;
        public static final int profileProgressBar = 2131230985;
        public static final int profileToolbar = 2131230986;
        public static final int profile_image = 2131230987;
        public static final int progressBar = 2131230988;
        public static final int progress_circular = 2131230989;
        public static final int progress_horizontal = 2131230990;
        public static final int radio = 2131230991;
        public static final int recyclerView = 2131230992;
        public static final int redHeart = 2131230993;
        public static final int registerProgressBar = 2131230994;
        public static final int register_button = 2131230995;
        public static final int relLayout = 2131230996;
        public static final int relLayout1 = 2131230997;
        public static final int relLayout10 = 2131230998;
        public static final int relLayout2 = 2131230999;
        public static final int relLayout3 = 2131231000;
        public static final int relLayout4 = 2131231001;
        public static final int relLayoutTop = 2131231002;
        public static final int right = 2131231003;
        public static final int right_icon = 2131231004;
        public static final int right_side = 2131231005;
        public static final int rounded = 2131231006;
        public static final int save_non_transition_alpha = 2131231007;
        public static final int save_overlay_view = 2131231008;
        public static final int scale = 2131231009;
        public static final int screen = 2131231010;
        public static final int scroll = 2131231011;
        public static final int scrollIndicatorDown = 2131231012;
        public static final int scrollIndicatorUp = 2131231013;
        public static final int scrollView = 2131231014;
        public static final int scrollable = 2131231015;
        public static final int search = 2131231016;
        public static final int searchImage = 2131231017;
        public static final int searchText = 2131231018;
        public static final int search_badge = 2131231019;
        public static final int search_bar = 2131231020;
        public static final int search_button = 2131231021;
        public static final int search_close_btn = 2131231022;
        public static final int search_edit_frame = 2131231023;
        public static final int search_go_btn = 2131231024;
        public static final int search_mag_icon = 2131231025;
        public static final int search_plate = 2131231026;
        public static final int search_src_text = 2131231027;
        public static final int search_voice_btn = 2131231028;
        public static final int select_dialog_listview = 2131231029;
        public static final int selected = 2131231030;
        public static final int share = 2131231031;
        public static final int shareImage = 2131231032;
        public static final int shortcut = 2131231033;
        public static final int showCustom = 2131231034;
        public static final int showHome = 2131231035;
        public static final int showTitle = 2131231036;
        public static final int signOutButton = 2131231037;
        public static final int signOutProgressBar = 2131231038;
        public static final int skipCollapsed = 2131231039;
        public static final int slide = 2131231040;
        public static final int smallLabel = 2131231041;
        public static final int snackbar_action = 2131231042;
        public static final int snackbar_text = 2131231043;
        public static final int snap = 2131231044;
        public static final int snapMargins = 2131231045;
        public static final int spacer = 2131231046;
        public static final int split_action_bar = 2131231047;
        public static final int spread = 2131231048;
        public static final int spread_inside = 2131231049;
        public static final int src_atop = 2131231050;
        public static final int src_in = 2131231051;
        public static final int src_over = 2131231052;
        public static final int standard = 2131231053;
        public static final int start = 2131231054;
        public static final int status_bar_latest_event_content = 2131231055;
        public static final int stretch = 2131231056;
        public static final int submenuarrow = 2131231057;
        public static final int submit_area = 2131231058;
        public static final int tabMode = 2131231059;
        public static final int tabs = 2131231060;
        public static final int tabsShare = 2131231061;
        public static final int tag_accessibility_actions = 2131231062;
        public static final int tag_accessibility_clickable_spans = 2131231063;
        public static final int tag_accessibility_heading = 2131231064;
        public static final int tag_accessibility_pane_title = 2131231065;
        public static final int tag_screen_reader_focusable = 2131231066;
        public static final int tag_transition_group = 2131231067;
        public static final int tag_unhandled_key_event_manager = 2131231068;
        public static final int tag_unhandled_key_listeners = 2131231069;
        public static final int test_checkbox_android_button_tint = 2131231070;
        public static final int test_checkbox_app_button_tint = 2131231071;
        public static final int text = 2131231072;
        public static final int text2 = 2131231073;
        public static final int textChangeImage = 2131231074;
        public static final int textEnd = 2131231075;
        public static final int textPassword = 2131231076;
        public static final int textSpacerNoButtons = 2131231077;
        public static final int textSpacerNoTitle = 2131231078;
        public static final int textStart = 2131231079;
        public static final int textTabCamera = 2131231080;
        public static final int textTabMessages = 2131231081;
        public static final int textView4 = 2131231082;
        public static final int textView5 = 2131231083;
        public static final int textView6 = 2131231084;
        public static final int text_input_end_icon = 2131231085;
        public static final int text_input_start_icon = 2131231086;
        public static final int textinput_counter = 2131231087;
        public static final int textinput_error = 2131231088;
        public static final int textinput_helper_text = 2131231089;
        public static final int time = 2131231090;
        public static final int timeStamp = 2131231091;
        public static final int title = 2131231092;
        public static final int titleDividerNoCustom = 2131231093;
        public static final int title_template = 2131231094;
        public static final int top = 2131231095;
        public static final int topPanel = 2131231096;
        public static final int touch_outside = 2131231097;
        public static final int transition_current_scene = 2131231098;
        public static final int transition_layout_save = 2131231099;
        public static final int transition_position = 2131231100;
        public static final int transition_scene_layoutid_cache = 2131231101;
        public static final int transition_transform = 2131231102;
        public static final int txtSignOut = 2131231103;
        public static final int unFollowButton = 2131231104;
        public static final int unchecked = 2131231105;
        public static final int uniform = 2131231106;
        public static final int unlabeled = 2131231107;
        public static final int up = 2131231108;
        public static final int useLogo = 2131231109;
        public static final int username = 2131231110;
        public static final int viewComments = 2131231111;
        public static final int viewPager = 2131231112;
        public static final int view_offset_helper = 2131231113;
        public static final int visible = 2131231114;
        public static final int wait = 2131231115;
        public static final int wide = 2131231116;
        public static final int withText = 2131231117;
        public static final int wrap = 2131231118;
        public static final int wrap_content = 2131231119;

        private id() {
        }
    }

    public static final class integer {
        public static final int abc_config_activityDefaultDur = 2131296256;
        public static final int abc_config_activityShortDur = 2131296257;
        public static final int app_bar_elevation_anim_duration = 2131296258;
        public static final int bottom_sheet_slide_duration = 2131296259;
        public static final int cancel_button_image_alpha = 2131296260;
        public static final int config_tooltipAnimTime = 2131296261;
        public static final int design_snackbar_text_max_lines = 2131296262;
        public static final int design_tab_indicator_anim_duration_ms = 2131296263;
        public static final int google_play_services_version = 2131296264;
        public static final int hide_password_duration = 2131296265;
        public static final int mtrl_badge_max_character_count = 2131296266;
        public static final int mtrl_btn_anim_delay_ms = 2131296267;
        public static final int mtrl_btn_anim_duration_ms = 2131296268;
        public static final int mtrl_calendar_header_orientation = 2131296269;
        public static final int mtrl_calendar_selection_text_lines = 2131296270;
        public static final int mtrl_calendar_year_selector_span = 2131296271;
        public static final int mtrl_card_anim_delay_ms = 2131296272;
        public static final int mtrl_card_anim_duration_ms = 2131296273;
        public static final int mtrl_chip_anim_duration = 2131296274;
        public static final int mtrl_tab_indicator_anim_duration_ms = 2131296275;
        public static final int show_password_duration = 2131296276;
        public static final int status_bar_notification_info_maxnum = 2131296277;

        private integer() {
        }
    }

    public static final class interpolator {
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131361792;
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131361793;
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131361794;
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131361795;
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131361796;
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131361797;
        public static final int fast_out_slow_in = 2131361798;
        public static final int mtrl_fast_out_linear_in = 2131361799;
        public static final int mtrl_fast_out_slow_in = 2131361800;
        public static final int mtrl_linear = 2131361801;
        public static final int mtrl_linear_out_slow_in = 2131361802;

        private interpolator() {
        }
    }

    public static final class layout {
        public static final int abc_action_bar_title_item = 2131427328;
        public static final int abc_action_bar_up_container = 2131427329;
        public static final int abc_action_menu_item_layout = 2131427330;
        public static final int abc_action_menu_layout = 2131427331;
        public static final int abc_action_mode_bar = 2131427332;
        public static final int abc_action_mode_close_item_material = 2131427333;
        public static final int abc_activity_chooser_view = 2131427334;
        public static final int abc_activity_chooser_view_list_item = 2131427335;
        public static final int abc_alert_dialog_button_bar_material = 2131427336;
        public static final int abc_alert_dialog_material = 2131427337;
        public static final int abc_alert_dialog_title_material = 2131427338;
        public static final int abc_cascading_menu_item_layout = 2131427339;
        public static final int abc_dialog_title_material = 2131427340;
        public static final int abc_expanded_menu_layout = 2131427341;
        public static final int abc_list_menu_item_checkbox = 2131427342;
        public static final int abc_list_menu_item_icon = 2131427343;
        public static final int abc_list_menu_item_layout = 2131427344;
        public static final int abc_list_menu_item_radio = 2131427345;
        public static final int abc_popup_menu_header_item_layout = 2131427346;
        public static final int abc_popup_menu_item_layout = 2131427347;
        public static final int abc_screen_content_include = 2131427348;
        public static final int abc_screen_simple = 2131427349;
        public static final int abc_screen_simple_overlay_action_mode = 2131427350;
        public static final int abc_screen_toolbar = 2131427351;
        public static final int abc_search_dropdown_item_icons_2line = 2131427352;
        public static final int abc_search_view = 2131427353;
        public static final int abc_select_dialog_material = 2131427354;
        public static final int abc_tooltip = 2131427355;
        public static final int activity_account_settings = 2131427356;
        public static final int activity_like = 2131427357;
        public static final int activity_login = 2131427358;
        public static final int activity_main = 2131427359;
        public static final int activity_next = 2131427360;
        public static final int activity_profile = 2131427361;
        public static final int activity_profile_toolbar = 2131427362;
        public static final int activity_register = 2131427363;
        public static final int activity_search = 2131427364;
        public static final int activity_settings_toolbar = 2131427365;
        public static final int activity_share = 2131427366;
        public static final int activity_splash = 2131427367;
        public static final int activity_view_profile_toolbar = 2131427368;
        public static final int custom_dialog = 2131427369;
        public static final int design_bottom_navigation_item = 2131427370;
        public static final int design_bottom_sheet_dialog = 2131427371;
        public static final int design_layout_snackbar = 2131427372;
        public static final int design_layout_snackbar_include = 2131427373;
        public static final int design_layout_tab_icon = 2131427374;
        public static final int design_layout_tab_text = 2131427375;
        public static final int design_menu_item_action_area = 2131427376;
        public static final int design_navigation_item = 2131427377;
        public static final int design_navigation_item_header = 2131427378;
        public static final int design_navigation_item_separator = 2131427379;
        public static final int design_navigation_item_subheader = 2131427380;
        public static final int design_navigation_menu = 2131427381;
        public static final int design_navigation_menu_item = 2131427382;
        public static final int design_text_input_end_icon = 2131427383;
        public static final int design_text_input_start_icon = 2131427384;
        public static final int dialog_confirm_password = 2131427385;
        public static final int edit_profile_toolbar = 2131427386;
        public static final int fragment_camera = 2131427387;
        public static final int fragment_edit_profile = 2131427388;
        public static final int fragment_gallery = 2131427389;
        public static final int fragment_home = 2131427390;
        public static final int fragment_messages = 2131427391;
        public static final int fragment_photo = 2131427392;
        public static final int fragment_profile = 2131427393;
        public static final int fragment_sign_out = 2131427394;
        public static final int fragment_view_comments = 2131427395;
        public static final int fragment_view_post = 2131427396;
        public static final int fragment_view_profile = 2131427397;
        public static final int layout_comment = 2131427398;
        public static final int layout_grid_imageview = 2131427399;
        public static final int layout_view_main_feed_post = 2131427400;
        public static final int layout_viewpager = 2131427401;
        public static final int mtrl_alert_dialog = 2131427402;
        public static final int mtrl_alert_dialog_actions = 2131427403;
        public static final int mtrl_alert_dialog_title = 2131427404;
        public static final int mtrl_alert_select_dialog_item = 2131427405;
        public static final int mtrl_alert_select_dialog_multichoice = 2131427406;
        public static final int mtrl_alert_select_dialog_singlechoice = 2131427407;
        public static final int mtrl_calendar_day = 2131427408;
        public static final int mtrl_calendar_day_of_week = 2131427409;
        public static final int mtrl_calendar_days_of_week = 2131427410;
        public static final int mtrl_calendar_horizontal = 2131427411;
        public static final int mtrl_calendar_month = 2131427412;
        public static final int mtrl_calendar_month_labeled = 2131427413;
        public static final int mtrl_calendar_month_navigation = 2131427414;
        public static final int mtrl_calendar_months = 2131427415;
        public static final int mtrl_calendar_vertical = 2131427416;
        public static final int mtrl_calendar_year = 2131427417;
        public static final int mtrl_layout_snackbar = 2131427418;
        public static final int mtrl_layout_snackbar_include = 2131427419;
        public static final int mtrl_picker_actions = 2131427420;
        public static final int mtrl_picker_dialog = 2131427421;
        public static final int mtrl_picker_fullscreen = 2131427422;
        public static final int mtrl_picker_header_dialog = 2131427423;
        public static final int mtrl_picker_header_fullscreen = 2131427424;
        public static final int mtrl_picker_header_selection_text = 2131427425;
        public static final int mtrl_picker_header_title_text = 2131427426;
        public static final int mtrl_picker_header_toggle = 2131427427;
        public static final int mtrl_picker_text_input_date = 2131427428;
        public static final int mtrl_picker_text_input_date_range = 2131427429;
        public static final int notification_action = 2131427430;
        public static final int notification_action_tombstone = 2131427431;
        public static final int notification_media_action = 2131427432;
        public static final int notification_media_cancel_action = 2131427433;
        public static final int notification_template_big_media = 2131427434;
        public static final int notification_template_big_media_custom = 2131427435;
        public static final int notification_template_big_media_narrow = 2131427436;
        public static final int notification_template_big_media_narrow_custom = 2131427437;
        public static final int notification_template_custom_big = 2131427438;
        public static final int notification_template_icon_group = 2131427439;
        public static final int notification_template_lines_media = 2131427440;
        public static final int notification_template_media = 2131427441;
        public static final int notification_template_media_custom = 2131427442;
        public static final int notification_template_part_chronometer = 2131427443;
        public static final int notification_template_part_time = 2131427444;
        public static final int select_dialog_item_material = 2131427445;
        public static final int select_dialog_multichoice_material = 2131427446;
        public static final int select_dialog_singlechoice_material = 2131427447;
        public static final int snippet_toolbar_gallery = 2131427448;
        public static final int snippet_toolbar_next = 2131427449;
        public static final int snippet_toolbar_view_comments = 2131427450;
        public static final int snippet_top_profile = 2131427451;
        public static final int snippet_top_view_profile = 2131427452;
        public static final int support_simple_spinner_dropdown_item = 2131427453;
        public static final int tab_layout = 2131427454;
        public static final int test_action_chip = 2131427455;
        public static final int test_design_checkbox = 2131427456;
        public static final int test_reflow_chipgroup = 2131427457;
        public static final int test_toolbar = 2131427458;
        public static final int test_toolbar_custom_background = 2131427459;
        public static final int test_toolbar_elevation = 2131427460;
        public static final int test_toolbar_surface = 2131427461;
        public static final int text_view_with_line_height_from_appearance = 2131427462;
        public static final int text_view_with_line_height_from_layout = 2131427463;
        public static final int text_view_with_line_height_from_style = 2131427464;
        public static final int text_view_with_theme_line_height = 2131427465;
        public static final int text_view_without_line_height = 2131427466;
        public static final int toolbar_view_post = 2131427467;

        private layout() {
        }
    }

    public static final class menu {
        public static final int bottom_navigation_menu = 2131492864;
        public static final int profile_menu = 2131492865;

        private menu() {
        }
    }

    public static final class mipmap {
        public static final int ic_launcher = 2131558400;
        public static final int ic_launcher_round = 2131558401;

        private mipmap() {
        }
    }

    public static final class plurals {
        public static final int mtrl_badge_content_description = 2131623936;

        private plurals() {
        }
    }

    public static final class string {
        public static final int abc_action_bar_home_description = 2131689472;
        public static final int abc_action_bar_up_description = 2131689473;
        public static final int abc_action_menu_overflow_description = 2131689474;
        public static final int abc_action_mode_done = 2131689475;
        public static final int abc_activity_chooser_view_see_all = 2131689476;
        public static final int abc_activitychooserview_choose_application = 2131689477;
        public static final int abc_capital_off = 2131689478;
        public static final int abc_capital_on = 2131689479;
        public static final int abc_menu_alt_shortcut_label = 2131689480;
        public static final int abc_menu_ctrl_shortcut_label = 2131689481;
        public static final int abc_menu_delete_shortcut_label = 2131689482;
        public static final int abc_menu_enter_shortcut_label = 2131689483;
        public static final int abc_menu_function_shortcut_label = 2131689484;
        public static final int abc_menu_meta_shortcut_label = 2131689485;
        public static final int abc_menu_shift_shortcut_label = 2131689486;
        public static final int abc_menu_space_shortcut_label = 2131689487;
        public static final int abc_menu_sym_shortcut_label = 2131689488;
        public static final int abc_prepend_shortcut_label = 2131689489;
        public static final int abc_search_hint = 2131689490;
        public static final int abc_searchview_description_clear = 2131689491;
        public static final int abc_searchview_description_query = 2131689492;
        public static final int abc_searchview_description_search = 2131689493;
        public static final int abc_searchview_description_submit = 2131689494;
        public static final int abc_searchview_description_voice = 2131689495;
        public static final int abc_shareactionprovider_share_with = 2131689496;
        public static final int abc_shareactionprovider_share_with_application = 2131689497;
        public static final int abc_toolbar_collapse_description = 2131689498;
        public static final int app_name = 2131689499;
        public static final int appbar_scrolling_view_behavior = 2131689500;
        public static final int bottom_sheet_behavior = 2131689501;
        public static final int character_counter_content_description = 2131689502;
        public static final int character_counter_overflowed_content_description = 2131689503;
        public static final int character_counter_pattern = 2131689504;
        public static final int chip_text = 2131689505;
        public static final int clear_text_end_icon_content_description = 2131689506;
        public static final int common_google_play_services_enable_button = 2131689507;
        public static final int common_google_play_services_enable_text = 2131689508;
        public static final int common_google_play_services_enable_title = 2131689509;
        public static final int common_google_play_services_install_button = 2131689510;
        public static final int common_google_play_services_install_text = 2131689511;
        public static final int common_google_play_services_install_title = 2131689512;
        public static final int common_google_play_services_notification_channel_name = 2131689513;
        public static final int common_google_play_services_notification_ticker = 2131689514;
        public static final int common_google_play_services_unknown_issue = 2131689515;
        public static final int common_google_play_services_unsupported_text = 2131689516;
        public static final int common_google_play_services_update_button = 2131689517;
        public static final int common_google_play_services_update_text = 2131689518;
        public static final int common_google_play_services_update_title = 2131689519;
        public static final int common_google_play_services_updating_text = 2131689520;
        public static final int common_google_play_services_wear_update_text = 2131689521;
        public static final int common_open_on_phone = 2131689522;
        public static final int common_signin_button_text = 2131689523;
        public static final int common_signin_button_text_long = 2131689524;
        public static final int default_web_client_id = 2131689525;
        public static final int error_icon_content_description = 2131689526;
        public static final int exposed_dropdown_menu_content_description = 2131689527;
        public static final int fab_transformation_scrim_behavior = 2131689528;
        public static final int fab_transformation_sheet_behavior = 2131689529;
        public static final int firebase_database_url = 2131689530;
        public static final int gcm_defaultSenderId = 2131689531;
        public static final int google_api_key = 2131689532;
        public static final int google_app_id = 2131689533;
        public static final int google_crash_reporting_api_key = 2131689534;
        public static final int google_storage_bucket = 2131689535;
        public static final int hello_blank_fragment = 2131689536;
        public static final int hide_bottom_view_on_scroll_behavior = 2131689537;
        public static final int icon_content_description = 2131689538;
        public static final int mtrl_badge_numberless_content_description = 2131689539;
        public static final int mtrl_chip_close_icon_content_description = 2131689540;
        public static final int mtrl_exceed_max_badge_number_suffix = 2131689541;
        public static final int mtrl_picker_a11y_next_month = 2131689542;
        public static final int mtrl_picker_a11y_prev_month = 2131689543;
        public static final int mtrl_picker_announce_current_selection = 2131689544;
        public static final int mtrl_picker_cancel = 2131689545;
        public static final int mtrl_picker_confirm = 2131689546;
        public static final int mtrl_picker_date_header_selected = 2131689547;
        public static final int mtrl_picker_date_header_title = 2131689548;
        public static final int mtrl_picker_date_header_unselected = 2131689549;
        public static final int mtrl_picker_day_of_week_column_header = 2131689550;
        public static final int mtrl_picker_invalid_format = 2131689551;
        public static final int mtrl_picker_invalid_format_example = 2131689552;
        public static final int mtrl_picker_invalid_format_use = 2131689553;
        public static final int mtrl_picker_invalid_range = 2131689554;
        public static final int mtrl_picker_navigate_to_year_description = 2131689555;
        public static final int mtrl_picker_out_of_range = 2131689556;
        public static final int mtrl_picker_range_header_only_end_selected = 2131689557;
        public static final int mtrl_picker_range_header_only_start_selected = 2131689558;
        public static final int mtrl_picker_range_header_selected = 2131689559;
        public static final int mtrl_picker_range_header_title = 2131689560;
        public static final int mtrl_picker_range_header_unselected = 2131689561;
        public static final int mtrl_picker_save = 2131689562;
        public static final int mtrl_picker_text_input_date_hint = 2131689563;
        public static final int mtrl_picker_text_input_date_range_end_hint = 2131689564;
        public static final int mtrl_picker_text_input_date_range_start_hint = 2131689565;
        public static final int mtrl_picker_text_input_day_abbr = 2131689566;
        public static final int mtrl_picker_text_input_month_abbr = 2131689567;
        public static final int mtrl_picker_text_input_year_abbr = 2131689568;
        public static final int mtrl_picker_toggle_to_calendar_input_mode = 2131689569;
        public static final int mtrl_picker_toggle_to_day_selection = 2131689570;
        public static final int mtrl_picker_toggle_to_text_input_mode = 2131689571;
        public static final int mtrl_picker_toggle_to_year_selection = 2131689572;
        public static final int password_toggle_content_description = 2131689573;
        public static final int path_password_eye = 2131689574;
        public static final int path_password_eye_mask_strike_through = 2131689575;
        public static final int path_password_eye_mask_visible = 2131689576;
        public static final int path_password_strike_through = 2131689577;
        public static final int project_id = 2131689578;
        public static final int search_menu_title = 2131689579;
        public static final int status_bar_notification_info_overflow = 2131689580;

        private string() {
        }
    }

    public static final class style {
        public static final int AlertDialog_AppCompat = 2131755008;
        public static final int AlertDialog_AppCompat_Light = 2131755009;
        public static final int Animation_AppCompat_Dialog = 2131755010;
        public static final int Animation_AppCompat_DropDownUp = 2131755011;
        public static final int Animation_AppCompat_Tooltip = 2131755012;
        public static final int Animation_Design_BottomSheetDialog = 2131755013;
        public static final int Animation_MaterialComponents_BottomSheetDialog = 2131755014;
        public static final int AppTheme = 2131755015;
        public static final int Base_AlertDialog_AppCompat = 2131755016;
        public static final int Base_AlertDialog_AppCompat_Light = 2131755017;
        public static final int Base_Animation_AppCompat_Dialog = 2131755018;
        public static final int Base_Animation_AppCompat_DropDownUp = 2131755019;
        public static final int Base_Animation_AppCompat_Tooltip = 2131755020;
        public static final int Base_CardView = 2131755021;
        public static final int Base_DialogWindowTitleBackground_AppCompat = 2131755023;
        public static final int Base_DialogWindowTitle_AppCompat = 2131755022;
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Icon = 2131755024;
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Panel = 2131755025;
        public static final int Base_MaterialAlertDialog_MaterialComponents_Title_Text = 2131755026;
        public static final int Base_TextAppearance_AppCompat = 2131755027;
        public static final int Base_TextAppearance_AppCompat_Body1 = 2131755028;
        public static final int Base_TextAppearance_AppCompat_Body2 = 2131755029;
        public static final int Base_TextAppearance_AppCompat_Button = 2131755030;
        public static final int Base_TextAppearance_AppCompat_Caption = 2131755031;
        public static final int Base_TextAppearance_AppCompat_Display1 = 2131755032;
        public static final int Base_TextAppearance_AppCompat_Display2 = 2131755033;
        public static final int Base_TextAppearance_AppCompat_Display3 = 2131755034;
        public static final int Base_TextAppearance_AppCompat_Display4 = 2131755035;
        public static final int Base_TextAppearance_AppCompat_Headline = 2131755036;
        public static final int Base_TextAppearance_AppCompat_Inverse = 2131755037;
        public static final int Base_TextAppearance_AppCompat_Large = 2131755038;
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131755039;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131755040;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131755041;
        public static final int Base_TextAppearance_AppCompat_Medium = 2131755042;
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131755043;
        public static final int Base_TextAppearance_AppCompat_Menu = 2131755044;
        public static final int Base_TextAppearance_AppCompat_SearchResult = 2131755045;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131755046;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131755047;
        public static final int Base_TextAppearance_AppCompat_Small = 2131755048;
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131755049;
        public static final int Base_TextAppearance_AppCompat_Subhead = 2131755050;
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131755051;
        public static final int Base_TextAppearance_AppCompat_Title = 2131755052;
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131755053;
        public static final int Base_TextAppearance_AppCompat_Tooltip = 2131755054;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131755055;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131755056;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131755057;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131755058;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131755059;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131755060;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131755061;
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131755062;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131755063;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131755064;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131755065;
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131755066;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131755067;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131755068;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131755069;
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131755070;
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131755071;
        public static final int Base_TextAppearance_MaterialComponents_Badge = 2131755072;
        public static final int Base_TextAppearance_MaterialComponents_Button = 2131755073;
        public static final int Base_TextAppearance_MaterialComponents_Headline6 = 2131755074;
        public static final int Base_TextAppearance_MaterialComponents_Subtitle2 = 2131755075;
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131755076;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131755077;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131755078;
        public static final int Base_ThemeOverlay_AppCompat = 2131755112;
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131755113;
        public static final int Base_ThemeOverlay_AppCompat_Dark = 2131755114;
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131755115;
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131755116;
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131755117;
        public static final int Base_ThemeOverlay_AppCompat_Light = 2131755118;
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog = 2131755119;
        public static final int Base_ThemeOverlay_MaterialComponents_Dialog_Alert = 2131755120;
        public static final int Base_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 2131755121;
        public static final int Base_Theme_AppCompat = 2131755079;
        public static final int Base_Theme_AppCompat_CompactMenu = 2131755080;
        public static final int Base_Theme_AppCompat_Dialog = 2131755081;
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131755085;
        public static final int Base_Theme_AppCompat_Dialog_Alert = 2131755082;
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131755083;
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131755084;
        public static final int Base_Theme_AppCompat_Light = 2131755086;
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131755087;
        public static final int Base_Theme_AppCompat_Light_Dialog = 2131755088;
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131755092;
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131755089;
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131755090;
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131755091;
        public static final int Base_Theme_MaterialComponents = 2131755093;
        public static final int Base_Theme_MaterialComponents_Bridge = 2131755094;
        public static final int Base_Theme_MaterialComponents_CompactMenu = 2131755095;
        public static final int Base_Theme_MaterialComponents_Dialog = 2131755096;
        public static final int Base_Theme_MaterialComponents_DialogWhenLarge = 2131755101;
        public static final int Base_Theme_MaterialComponents_Dialog_Alert = 2131755097;
        public static final int Base_Theme_MaterialComponents_Dialog_Bridge = 2131755098;
        public static final int Base_Theme_MaterialComponents_Dialog_FixedSize = 2131755099;
        public static final int Base_Theme_MaterialComponents_Dialog_MinWidth = 2131755100;
        public static final int Base_Theme_MaterialComponents_Light = 2131755102;
        public static final int Base_Theme_MaterialComponents_Light_Bridge = 2131755103;
        public static final int Base_Theme_MaterialComponents_Light_DarkActionBar = 2131755104;
        public static final int Base_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 2131755105;
        public static final int Base_Theme_MaterialComponents_Light_Dialog = 2131755106;
        public static final int Base_Theme_MaterialComponents_Light_DialogWhenLarge = 2131755111;
        public static final int Base_Theme_MaterialComponents_Light_Dialog_Alert = 2131755107;
        public static final int Base_Theme_MaterialComponents_Light_Dialog_Bridge = 2131755108;
        public static final int Base_Theme_MaterialComponents_Light_Dialog_FixedSize = 2131755109;
        public static final int Base_Theme_MaterialComponents_Light_Dialog_MinWidth = 2131755110;
        public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog = 2131755131;
        public static final int Base_V14_ThemeOverlay_MaterialComponents_Dialog_Alert = 2131755132;
        public static final int Base_V14_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 2131755133;
        public static final int Base_V14_Theme_MaterialComponents = 2131755122;
        public static final int Base_V14_Theme_MaterialComponents_Bridge = 2131755123;
        public static final int Base_V14_Theme_MaterialComponents_Dialog = 2131755124;
        public static final int Base_V14_Theme_MaterialComponents_Dialog_Bridge = 2131755125;
        public static final int Base_V14_Theme_MaterialComponents_Light = 2131755126;
        public static final int Base_V14_Theme_MaterialComponents_Light_Bridge = 2131755127;
        public static final int Base_V14_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 2131755128;
        public static final int Base_V14_Theme_MaterialComponents_Light_Dialog = 2131755129;
        public static final int Base_V14_Theme_MaterialComponents_Light_Dialog_Bridge = 2131755130;
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131755138;
        public static final int Base_V21_Theme_AppCompat = 2131755134;
        public static final int Base_V21_Theme_AppCompat_Dialog = 2131755135;
        public static final int Base_V21_Theme_AppCompat_Light = 2131755136;
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131755137;
        public static final int Base_V22_Theme_AppCompat = 2131755139;
        public static final int Base_V22_Theme_AppCompat_Light = 2131755140;
        public static final int Base_V23_Theme_AppCompat = 2131755141;
        public static final int Base_V23_Theme_AppCompat_Light = 2131755142;
        public static final int Base_V26_Theme_AppCompat = 2131755143;
        public static final int Base_V26_Theme_AppCompat_Light = 2131755144;
        public static final int Base_V26_Widget_AppCompat_Toolbar = 2131755145;
        public static final int Base_V28_Theme_AppCompat = 2131755146;
        public static final int Base_V28_Theme_AppCompat_Light = 2131755147;
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131755152;
        public static final int Base_V7_Theme_AppCompat = 2131755148;
        public static final int Base_V7_Theme_AppCompat_Dialog = 2131755149;
        public static final int Base_V7_Theme_AppCompat_Light = 2131755150;
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131755151;
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131755153;
        public static final int Base_V7_Widget_AppCompat_EditText = 2131755154;
        public static final int Base_V7_Widget_AppCompat_Toolbar = 2131755155;
        public static final int Base_Widget_AppCompat_ActionBar = 2131755156;
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131755157;
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131755158;
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131755159;
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131755160;
        public static final int Base_Widget_AppCompat_ActionButton = 2131755161;
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131755162;
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131755163;
        public static final int Base_Widget_AppCompat_ActionMode = 2131755164;
        public static final int Base_Widget_AppCompat_ActivityChooserView = 2131755165;
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131755166;
        public static final int Base_Widget_AppCompat_Button = 2131755167;
        public static final int Base_Widget_AppCompat_ButtonBar = 2131755173;
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131755174;
        public static final int Base_Widget_AppCompat_Button_Borderless = 2131755168;
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131755169;
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131755170;
        public static final int Base_Widget_AppCompat_Button_Colored = 2131755171;
        public static final int Base_Widget_AppCompat_Button_Small = 2131755172;
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131755175;
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131755176;
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131755177;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131755178;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131755179;
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131755180;
        public static final int Base_Widget_AppCompat_EditText = 2131755181;
        public static final int Base_Widget_AppCompat_ImageButton = 2131755182;
        public static final int Base_Widget_AppCompat_Light_ActionBar = 2131755183;
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131755184;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131755185;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131755186;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131755187;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131755188;
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131755189;
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131755190;
        public static final int Base_Widget_AppCompat_ListMenuView = 2131755191;
        public static final int Base_Widget_AppCompat_ListPopupWindow = 2131755192;
        public static final int Base_Widget_AppCompat_ListView = 2131755193;
        public static final int Base_Widget_AppCompat_ListView_DropDown = 2131755194;
        public static final int Base_Widget_AppCompat_ListView_Menu = 2131755195;
        public static final int Base_Widget_AppCompat_PopupMenu = 2131755196;
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131755197;
        public static final int Base_Widget_AppCompat_PopupWindow = 2131755198;
        public static final int Base_Widget_AppCompat_ProgressBar = 2131755199;
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131755200;
        public static final int Base_Widget_AppCompat_RatingBar = 2131755201;
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131755202;
        public static final int Base_Widget_AppCompat_RatingBar_Small = 2131755203;
        public static final int Base_Widget_AppCompat_SearchView = 2131755204;
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131755205;
        public static final int Base_Widget_AppCompat_SeekBar = 2131755206;
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131755207;
        public static final int Base_Widget_AppCompat_Spinner = 2131755208;
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131755209;
        public static final int Base_Widget_AppCompat_TextView = 2131755210;
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131755211;
        public static final int Base_Widget_AppCompat_Toolbar = 2131755212;
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131755213;
        public static final int Base_Widget_Design_TabLayout = 2131755214;
        public static final int Base_Widget_MaterialComponents_AutoCompleteTextView = 2131755215;
        public static final int Base_Widget_MaterialComponents_CheckedTextView = 2131755216;
        public static final int Base_Widget_MaterialComponents_Chip = 2131755217;
        public static final int Base_Widget_MaterialComponents_PopupMenu = 2131755218;
        public static final int Base_Widget_MaterialComponents_PopupMenu_ContextMenu = 2131755219;
        public static final int Base_Widget_MaterialComponents_PopupMenu_ListPopupWindow = 2131755220;
        public static final int Base_Widget_MaterialComponents_PopupMenu_Overflow = 2131755221;
        public static final int Base_Widget_MaterialComponents_TextInputEditText = 2131755222;
        public static final int Base_Widget_MaterialComponents_TextInputLayout = 2131755223;
        public static final int Base_Widget_MaterialComponents_TextView = 2131755224;
        public static final int CardView = 2131755225;
        public static final int CardView_Dark = 2131755226;
        public static final int CardView_Light = 2131755227;
        public static final int EmptyTheme = 2131755228;
        public static final int MaterialAlertDialog_MaterialComponents = 2131755229;
        public static final int MaterialAlertDialog_MaterialComponents_Body_Text = 2131755230;
        public static final int MaterialAlertDialog_MaterialComponents_Picker_Date_Calendar = 2131755231;
        public static final int MaterialAlertDialog_MaterialComponents_Picker_Date_Spinner = 2131755232;
        public static final int MaterialAlertDialog_MaterialComponents_Title_Icon = 2131755233;
        public static final int MaterialAlertDialog_MaterialComponents_Title_Icon_CenterStacked = 2131755234;
        public static final int MaterialAlertDialog_MaterialComponents_Title_Panel = 2131755235;
        public static final int MaterialAlertDialog_MaterialComponents_Title_Panel_CenterStacked = 2131755236;
        public static final int MaterialAlertDialog_MaterialComponents_Title_Text = 2131755237;
        public static final int MaterialAlertDialog_MaterialComponents_Title_Text_CenterStacked = 2131755238;
        public static final int Platform_AppCompat = 2131755239;
        public static final int Platform_AppCompat_Light = 2131755240;
        public static final int Platform_MaterialComponents = 2131755241;
        public static final int Platform_MaterialComponents_Dialog = 2131755242;
        public static final int Platform_MaterialComponents_Light = 2131755243;
        public static final int Platform_MaterialComponents_Light_Dialog = 2131755244;
        public static final int Platform_ThemeOverlay_AppCompat = 2131755245;
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131755246;
        public static final int Platform_ThemeOverlay_AppCompat_Light = 2131755247;
        public static final int Platform_V21_AppCompat = 2131755248;
        public static final int Platform_V21_AppCompat_Light = 2131755249;
        public static final int Platform_V25_AppCompat = 2131755250;
        public static final int Platform_V25_AppCompat_Light = 2131755251;
        public static final int Platform_Widget_AppCompat_Spinner = 2131755252;
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131755253;
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131755254;
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131755255;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131755256;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131755257;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131755258;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131755259;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131755260;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131755261;
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131755267;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131755262;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131755263;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131755264;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131755265;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131755266;
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131755268;
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131755269;
        public static final int ShapeAppearanceOverlay = 2131755275;
        public static final int ShapeAppearanceOverlay_BottomLeftDifferentCornerSize = 2131755276;
        public static final int ShapeAppearanceOverlay_BottomRightCut = 2131755277;
        public static final int ShapeAppearanceOverlay_Cut = 2131755278;
        public static final int ShapeAppearanceOverlay_DifferentCornerSize = 2131755279;
        public static final int ShapeAppearanceOverlay_MaterialComponents_BottomSheet = 2131755280;
        public static final int ShapeAppearanceOverlay_MaterialComponents_Chip = 2131755281;
        public static final int ShapeAppearanceOverlay_MaterialComponents_ExtendedFloatingActionButton = 2131755282;
        public static final int ShapeAppearanceOverlay_MaterialComponents_FloatingActionButton = 2131755283;
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day = 2131755284;
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Window_Fullscreen = 2131755285;
        public static final int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Year = 2131755286;
        public static final int ShapeAppearanceOverlay_MaterialComponents_TextInputLayout_FilledBox = 2131755287;
        public static final int ShapeAppearanceOverlay_TopLeftCut = 2131755288;
        public static final int ShapeAppearanceOverlay_TopRightDifferentCornerSize = 2131755289;
        public static final int ShapeAppearance_MaterialComponents = 2131755270;
        public static final int ShapeAppearance_MaterialComponents_LargeComponent = 2131755271;
        public static final int ShapeAppearance_MaterialComponents_MediumComponent = 2131755272;
        public static final int ShapeAppearance_MaterialComponents_SmallComponent = 2131755273;
        public static final int ShapeAppearance_MaterialComponents_Test = 2131755274;
        public static final int TestStyleWithLineHeight = 2131755295;
        public static final int TestStyleWithLineHeightAppearance = 2131755296;
        public static final int TestStyleWithThemeLineHeightAttribute = 2131755297;
        public static final int TestStyleWithoutLineHeight = 2131755298;
        public static final int TestThemeWithLineHeight = 2131755299;
        public static final int TestThemeWithLineHeightDisabled = 2131755300;
        public static final int Test_ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day = 2131755290;
        public static final int Test_Theme_MaterialComponents_MaterialCalendar = 2131755291;
        public static final int Test_Widget_MaterialComponents_MaterialCalendar = 2131755292;
        public static final int Test_Widget_MaterialComponents_MaterialCalendar_Day = 2131755293;
        public static final int Test_Widget_MaterialComponents_MaterialCalendar_Day_Selected = 2131755294;
        public static final int TextAppearance_AppCompat = 2131755301;
        public static final int TextAppearance_AppCompat_Body1 = 2131755302;
        public static final int TextAppearance_AppCompat_Body2 = 2131755303;
        public static final int TextAppearance_AppCompat_Button = 2131755304;
        public static final int TextAppearance_AppCompat_Caption = 2131755305;
        public static final int TextAppearance_AppCompat_Display1 = 2131755306;
        public static final int TextAppearance_AppCompat_Display2 = 2131755307;
        public static final int TextAppearance_AppCompat_Display3 = 2131755308;
        public static final int TextAppearance_AppCompat_Display4 = 2131755309;
        public static final int TextAppearance_AppCompat_Headline = 2131755310;
        public static final int TextAppearance_AppCompat_Inverse = 2131755311;
        public static final int TextAppearance_AppCompat_Large = 2131755312;
        public static final int TextAppearance_AppCompat_Large_Inverse = 2131755313;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131755314;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131755315;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131755316;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131755317;
        public static final int TextAppearance_AppCompat_Medium = 2131755318;
        public static final int TextAppearance_AppCompat_Medium_Inverse = 2131755319;
        public static final int TextAppearance_AppCompat_Menu = 2131755320;
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131755321;
        public static final int TextAppearance_AppCompat_SearchResult_Title = 2131755322;
        public static final int TextAppearance_AppCompat_Small = 2131755323;
        public static final int TextAppearance_AppCompat_Small_Inverse = 2131755324;
        public static final int TextAppearance_AppCompat_Subhead = 2131755325;
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131755326;
        public static final int TextAppearance_AppCompat_Title = 2131755327;
        public static final int TextAppearance_AppCompat_Title_Inverse = 2131755328;
        public static final int TextAppearance_AppCompat_Tooltip = 2131755329;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131755330;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131755331;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131755332;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131755333;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131755334;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131755335;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131755336;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131755337;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131755338;
        public static final int TextAppearance_AppCompat_Widget_Button = 2131755339;
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131755340;
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131755341;
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131755342;
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131755343;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131755344;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131755345;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131755346;
        public static final int TextAppearance_AppCompat_Widget_Switch = 2131755347;
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131755348;
        public static final int TextAppearance_Compat_Notification = 2131755349;
        public static final int TextAppearance_Compat_Notification_Info = 2131755350;
        public static final int TextAppearance_Compat_Notification_Info_Media = 2131755351;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131755352;
        public static final int TextAppearance_Compat_Notification_Line2_Media = 2131755353;
        public static final int TextAppearance_Compat_Notification_Media = 2131755354;
        public static final int TextAppearance_Compat_Notification_Time = 2131755355;
        public static final int TextAppearance_Compat_Notification_Time_Media = 2131755356;
        public static final int TextAppearance_Compat_Notification_Title = 2131755357;
        public static final int TextAppearance_Compat_Notification_Title_Media = 2131755358;
        public static final int TextAppearance_Design_CollapsingToolbar_Expanded = 2131755359;
        public static final int TextAppearance_Design_Counter = 2131755360;
        public static final int TextAppearance_Design_Counter_Overflow = 2131755361;
        public static final int TextAppearance_Design_Error = 2131755362;
        public static final int TextAppearance_Design_HelperText = 2131755363;
        public static final int TextAppearance_Design_Hint = 2131755364;
        public static final int TextAppearance_Design_Snackbar_Message = 2131755365;
        public static final int TextAppearance_Design_Tab = 2131755366;
        public static final int TextAppearance_MaterialComponents_Badge = 2131755367;
        public static final int TextAppearance_MaterialComponents_Body1 = 2131755368;
        public static final int TextAppearance_MaterialComponents_Body2 = 2131755369;
        public static final int TextAppearance_MaterialComponents_Button = 2131755370;
        public static final int TextAppearance_MaterialComponents_Caption = 2131755371;
        public static final int TextAppearance_MaterialComponents_Chip = 2131755372;
        public static final int TextAppearance_MaterialComponents_Headline1 = 2131755373;
        public static final int TextAppearance_MaterialComponents_Headline2 = 2131755374;
        public static final int TextAppearance_MaterialComponents_Headline3 = 2131755375;
        public static final int TextAppearance_MaterialComponents_Headline4 = 2131755376;
        public static final int TextAppearance_MaterialComponents_Headline5 = 2131755377;
        public static final int TextAppearance_MaterialComponents_Headline6 = 2131755378;
        public static final int TextAppearance_MaterialComponents_Overline = 2131755379;
        public static final int TextAppearance_MaterialComponents_Subtitle1 = 2131755380;
        public static final int TextAppearance_MaterialComponents_Subtitle2 = 2131755381;
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131755382;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131755383;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131755384;
        public static final int ThemeOverlay_AppCompat = 2131755461;
        public static final int ThemeOverlay_AppCompat_ActionBar = 2131755462;
        public static final int ThemeOverlay_AppCompat_Dark = 2131755463;
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131755464;
        public static final int ThemeOverlay_AppCompat_DayNight = 2131755465;
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131755466;
        public static final int ThemeOverlay_AppCompat_Dialog = 2131755467;
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131755468;
        public static final int ThemeOverlay_AppCompat_Light = 2131755469;
        public static final int ThemeOverlay_Design_TextInputEditText = 2131755470;
        public static final int ThemeOverlay_MaterialComponents = 2131755471;
        public static final int ThemeOverlay_MaterialComponents_ActionBar = 2131755472;
        public static final int ThemeOverlay_MaterialComponents_ActionBar_Primary = 2131755473;
        public static final int ThemeOverlay_MaterialComponents_ActionBar_Surface = 2131755474;
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView = 2131755475;
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox = 2131755476;
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox_Dense = 2131755477;
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox = 2131755478;
        public static final int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense = 2131755479;
        public static final int ThemeOverlay_MaterialComponents_BottomAppBar_Primary = 2131755480;
        public static final int ThemeOverlay_MaterialComponents_BottomAppBar_Surface = 2131755481;
        public static final int ThemeOverlay_MaterialComponents_BottomSheetDialog = 2131755482;
        public static final int ThemeOverlay_MaterialComponents_Dark = 2131755483;
        public static final int ThemeOverlay_MaterialComponents_Dark_ActionBar = 2131755484;
        public static final int ThemeOverlay_MaterialComponents_DayNight_BottomSheetDialog = 2131755485;
        public static final int ThemeOverlay_MaterialComponents_Dialog = 2131755486;
        public static final int ThemeOverlay_MaterialComponents_Dialog_Alert = 2131755487;
        public static final int ThemeOverlay_MaterialComponents_Light = 2131755488;
        public static final int ThemeOverlay_MaterialComponents_Light_BottomSheetDialog = 2131755489;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog = 2131755490;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Centered = 2131755491;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date = 2131755492;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Calendar = 2131755493;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text = 2131755494;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text_Day = 2131755495;
        public static final int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Spinner = 2131755496;
        public static final int ThemeOverlay_MaterialComponents_MaterialCalendar = 2131755497;
        public static final int ThemeOverlay_MaterialComponents_MaterialCalendar_Fullscreen = 2131755498;
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText = 2131755499;
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox = 2131755500;
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox_Dense = 2131755501;
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox = 2131755502;
        public static final int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 2131755503;
        public static final int ThemeOverlay_MaterialComponents_Toolbar_Primary = 2131755504;
        public static final int ThemeOverlay_MaterialComponents_Toolbar_Surface = 2131755505;
        public static final int Theme_AppCompat = 2131755385;
        public static final int Theme_AppCompat_CompactMenu = 2131755386;
        public static final int Theme_AppCompat_DayNight = 2131755387;
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131755388;
        public static final int Theme_AppCompat_DayNight_Dialog = 2131755389;
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131755392;
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131755390;
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131755391;
        public static final int Theme_AppCompat_DayNight_NoActionBar = 2131755393;
        public static final int Theme_AppCompat_Dialog = 2131755394;
        public static final int Theme_AppCompat_DialogWhenLarge = 2131755397;
        public static final int Theme_AppCompat_Dialog_Alert = 2131755395;
        public static final int Theme_AppCompat_Dialog_MinWidth = 2131755396;
        public static final int Theme_AppCompat_Light = 2131755398;
        public static final int Theme_AppCompat_Light_DarkActionBar = 2131755399;
        public static final int Theme_AppCompat_Light_Dialog = 2131755400;
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131755403;
        public static final int Theme_AppCompat_Light_Dialog_Alert = 2131755401;
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131755402;
        public static final int Theme_AppCompat_Light_NoActionBar = 2131755404;
        public static final int Theme_AppCompat_NoActionBar = 2131755405;
        public static final int Theme_Design = 2131755406;
        public static final int Theme_Design_BottomSheetDialog = 2131755407;
        public static final int Theme_Design_Light = 2131755408;
        public static final int Theme_Design_Light_BottomSheetDialog = 2131755409;
        public static final int Theme_Design_Light_NoActionBar = 2131755410;
        public static final int Theme_Design_NoActionBar = 2131755411;
        public static final int Theme_MaterialComponents = 2131755412;
        public static final int Theme_MaterialComponents_BottomSheetDialog = 2131755413;
        public static final int Theme_MaterialComponents_Bridge = 2131755414;
        public static final int Theme_MaterialComponents_CompactMenu = 2131755415;
        public static final int Theme_MaterialComponents_DayNight = 2131755416;
        public static final int Theme_MaterialComponents_DayNight_BottomSheetDialog = 2131755417;
        public static final int Theme_MaterialComponents_DayNight_Bridge = 2131755418;
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar = 2131755419;
        public static final int Theme_MaterialComponents_DayNight_DarkActionBar_Bridge = 2131755420;
        public static final int Theme_MaterialComponents_DayNight_Dialog = 2131755421;
        public static final int Theme_MaterialComponents_DayNight_DialogWhenLarge = 2131755429;
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert = 2131755422;
        public static final int Theme_MaterialComponents_DayNight_Dialog_Alert_Bridge = 2131755423;
        public static final int Theme_MaterialComponents_DayNight_Dialog_Bridge = 2131755424;
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize = 2131755425;
        public static final int Theme_MaterialComponents_DayNight_Dialog_FixedSize_Bridge = 2131755426;
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth = 2131755427;
        public static final int Theme_MaterialComponents_DayNight_Dialog_MinWidth_Bridge = 2131755428;
        public static final int Theme_MaterialComponents_DayNight_NoActionBar = 2131755430;
        public static final int Theme_MaterialComponents_DayNight_NoActionBar_Bridge = 2131755431;
        public static final int Theme_MaterialComponents_Dialog = 2131755432;
        public static final int Theme_MaterialComponents_DialogWhenLarge = 2131755440;
        public static final int Theme_MaterialComponents_Dialog_Alert = 2131755433;
        public static final int Theme_MaterialComponents_Dialog_Alert_Bridge = 2131755434;
        public static final int Theme_MaterialComponents_Dialog_Bridge = 2131755435;
        public static final int Theme_MaterialComponents_Dialog_FixedSize = 2131755436;
        public static final int Theme_MaterialComponents_Dialog_FixedSize_Bridge = 2131755437;
        public static final int Theme_MaterialComponents_Dialog_MinWidth = 2131755438;
        public static final int Theme_MaterialComponents_Dialog_MinWidth_Bridge = 2131755439;
        public static final int Theme_MaterialComponents_Light = 2131755441;
        public static final int Theme_MaterialComponents_Light_BarSize = 2131755442;
        public static final int Theme_MaterialComponents_Light_BottomSheetDialog = 2131755443;
        public static final int Theme_MaterialComponents_Light_Bridge = 2131755444;
        public static final int Theme_MaterialComponents_Light_DarkActionBar = 2131755445;
        public static final int Theme_MaterialComponents_Light_DarkActionBar_Bridge = 2131755446;
        public static final int Theme_MaterialComponents_Light_Dialog = 2131755447;
        public static final int Theme_MaterialComponents_Light_DialogWhenLarge = 2131755455;
        public static final int Theme_MaterialComponents_Light_Dialog_Alert = 2131755448;
        public static final int Theme_MaterialComponents_Light_Dialog_Alert_Bridge = 2131755449;
        public static final int Theme_MaterialComponents_Light_Dialog_Bridge = 2131755450;
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize = 2131755451;
        public static final int Theme_MaterialComponents_Light_Dialog_FixedSize_Bridge = 2131755452;
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth = 2131755453;
        public static final int Theme_MaterialComponents_Light_Dialog_MinWidth_Bridge = 2131755454;
        public static final int Theme_MaterialComponents_Light_LargeTouch = 2131755456;
        public static final int Theme_MaterialComponents_Light_NoActionBar = 2131755457;
        public static final int Theme_MaterialComponents_Light_NoActionBar_Bridge = 2131755458;
        public static final int Theme_MaterialComponents_NoActionBar = 2131755459;
        public static final int Theme_MaterialComponents_NoActionBar_Bridge = 2131755460;
        public static final int Widget_AppCompat_ActionBar = 2131755506;
        public static final int Widget_AppCompat_ActionBar_Solid = 2131755507;
        public static final int Widget_AppCompat_ActionBar_TabBar = 2131755508;
        public static final int Widget_AppCompat_ActionBar_TabText = 2131755509;
        public static final int Widget_AppCompat_ActionBar_TabView = 2131755510;
        public static final int Widget_AppCompat_ActionButton = 2131755511;
        public static final int Widget_AppCompat_ActionButton_CloseMode = 2131755512;
        public static final int Widget_AppCompat_ActionButton_Overflow = 2131755513;
        public static final int Widget_AppCompat_ActionMode = 2131755514;
        public static final int Widget_AppCompat_ActivityChooserView = 2131755515;
        public static final int Widget_AppCompat_AutoCompleteTextView = 2131755516;
        public static final int Widget_AppCompat_Button = 2131755517;
        public static final int Widget_AppCompat_ButtonBar = 2131755523;
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131755524;
        public static final int Widget_AppCompat_Button_Borderless = 2131755518;
        public static final int Widget_AppCompat_Button_Borderless_Colored = 2131755519;
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131755520;
        public static final int Widget_AppCompat_Button_Colored = 2131755521;
        public static final int Widget_AppCompat_Button_Small = 2131755522;
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131755525;
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131755526;
        public static final int Widget_AppCompat_CompoundButton_Switch = 2131755527;
        public static final int Widget_AppCompat_DrawerArrowToggle = 2131755528;
        public static final int Widget_AppCompat_DropDownItem_Spinner = 2131755529;
        public static final int Widget_AppCompat_EditText = 2131755530;
        public static final int Widget_AppCompat_ImageButton = 2131755531;
        public static final int Widget_AppCompat_Light_ActionBar = 2131755532;
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131755533;
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131755534;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131755535;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131755536;
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131755537;
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131755538;
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131755539;
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131755540;
        public static final int Widget_AppCompat_Light_ActionButton = 2131755541;
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131755542;
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131755543;
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131755544;
        public static final int Widget_AppCompat_Light_ActivityChooserView = 2131755545;
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131755546;
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131755547;
        public static final int Widget_AppCompat_Light_ListPopupWindow = 2131755548;
        public static final int Widget_AppCompat_Light_ListView_DropDown = 2131755549;
        public static final int Widget_AppCompat_Light_PopupMenu = 2131755550;
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131755551;
        public static final int Widget_AppCompat_Light_SearchView = 2131755552;
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131755553;
        public static final int Widget_AppCompat_ListMenuView = 2131755554;
        public static final int Widget_AppCompat_ListPopupWindow = 2131755555;
        public static final int Widget_AppCompat_ListView = 2131755556;
        public static final int Widget_AppCompat_ListView_DropDown = 2131755557;
        public static final int Widget_AppCompat_ListView_Menu = 2131755558;
        public static final int Widget_AppCompat_PopupMenu = 2131755559;
        public static final int Widget_AppCompat_PopupMenu_Overflow = 2131755560;
        public static final int Widget_AppCompat_PopupWindow = 2131755561;
        public static final int Widget_AppCompat_ProgressBar = 2131755562;
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131755563;
        public static final int Widget_AppCompat_RatingBar = 2131755564;
        public static final int Widget_AppCompat_RatingBar_Indicator = 2131755565;
        public static final int Widget_AppCompat_RatingBar_Small = 2131755566;
        public static final int Widget_AppCompat_SearchView = 2131755567;
        public static final int Widget_AppCompat_SearchView_ActionBar = 2131755568;
        public static final int Widget_AppCompat_SeekBar = 2131755569;
        public static final int Widget_AppCompat_SeekBar_Discrete = 2131755570;
        public static final int Widget_AppCompat_Spinner = 2131755571;
        public static final int Widget_AppCompat_Spinner_DropDown = 2131755572;
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131755573;
        public static final int Widget_AppCompat_Spinner_Underlined = 2131755574;
        public static final int Widget_AppCompat_TextView = 2131755575;
        public static final int Widget_AppCompat_TextView_SpinnerItem = 2131755576;
        public static final int Widget_AppCompat_Toolbar = 2131755577;
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131755578;
        public static final int Widget_Compat_NotificationActionContainer = 2131755579;
        public static final int Widget_Compat_NotificationActionText = 2131755580;
        public static final int Widget_Design_AppBarLayout = 2131755581;
        public static final int Widget_Design_BottomNavigationView = 2131755582;
        public static final int Widget_Design_BottomSheet_Modal = 2131755583;
        public static final int Widget_Design_CollapsingToolbar = 2131755584;
        public static final int Widget_Design_FloatingActionButton = 2131755585;
        public static final int Widget_Design_NavigationView = 2131755586;
        public static final int Widget_Design_ScrimInsetsFrameLayout = 2131755587;
        public static final int Widget_Design_Snackbar = 2131755588;
        public static final int Widget_Design_TabLayout = 2131755589;
        public static final int Widget_Design_TextInputLayout = 2131755590;
        public static final int Widget_MaterialComponents_ActionBar_Primary = 2131755591;
        public static final int Widget_MaterialComponents_ActionBar_PrimarySurface = 2131755592;
        public static final int Widget_MaterialComponents_ActionBar_Solid = 2131755593;
        public static final int Widget_MaterialComponents_ActionBar_Surface = 2131755594;
        public static final int Widget_MaterialComponents_AppBarLayout_Primary = 2131755595;
        public static final int Widget_MaterialComponents_AppBarLayout_PrimarySurface = 2131755596;
        public static final int Widget_MaterialComponents_AppBarLayout_Surface = 2131755597;
        public static final int Widget_MaterialComponents_AutoCompleteTextView_FilledBox = 2131755598;
        public static final int Widget_MaterialComponents_AutoCompleteTextView_FilledBox_Dense = 2131755599;
        public static final int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox = 2131755600;
        public static final int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense = 2131755601;
        public static final int Widget_MaterialComponents_Badge = 2131755602;
        public static final int Widget_MaterialComponents_BottomAppBar = 2131755603;
        public static final int Widget_MaterialComponents_BottomAppBar_Colored = 2131755604;
        public static final int Widget_MaterialComponents_BottomAppBar_PrimarySurface = 2131755605;
        public static final int Widget_MaterialComponents_BottomNavigationView = 2131755606;
        public static final int Widget_MaterialComponents_BottomNavigationView_Colored = 2131755607;
        public static final int Widget_MaterialComponents_BottomNavigationView_PrimarySurface = 2131755608;
        public static final int Widget_MaterialComponents_BottomSheet = 2131755609;
        public static final int Widget_MaterialComponents_BottomSheet_Modal = 2131755610;
        public static final int Widget_MaterialComponents_Button = 2131755611;
        public static final int Widget_MaterialComponents_Button_Icon = 2131755612;
        public static final int Widget_MaterialComponents_Button_OutlinedButton = 2131755613;
        public static final int Widget_MaterialComponents_Button_OutlinedButton_Icon = 2131755614;
        public static final int Widget_MaterialComponents_Button_TextButton = 2131755615;
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog = 2131755616;
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog_Flush = 2131755617;
        public static final int Widget_MaterialComponents_Button_TextButton_Dialog_Icon = 2131755618;
        public static final int Widget_MaterialComponents_Button_TextButton_Icon = 2131755619;
        public static final int Widget_MaterialComponents_Button_TextButton_Snackbar = 2131755620;
        public static final int Widget_MaterialComponents_Button_UnelevatedButton = 2131755621;
        public static final int Widget_MaterialComponents_Button_UnelevatedButton_Icon = 2131755622;
        public static final int Widget_MaterialComponents_CardView = 2131755623;
        public static final int Widget_MaterialComponents_CheckedTextView = 2131755624;
        public static final int Widget_MaterialComponents_ChipGroup = 2131755629;
        public static final int Widget_MaterialComponents_Chip_Action = 2131755625;
        public static final int Widget_MaterialComponents_Chip_Choice = 2131755626;
        public static final int Widget_MaterialComponents_Chip_Entry = 2131755627;
        public static final int Widget_MaterialComponents_Chip_Filter = 2131755628;
        public static final int Widget_MaterialComponents_CompoundButton_CheckBox = 2131755630;
        public static final int Widget_MaterialComponents_CompoundButton_RadioButton = 2131755631;
        public static final int Widget_MaterialComponents_CompoundButton_Switch = 2131755632;
        public static final int Widget_MaterialComponents_ExtendedFloatingActionButton = 2131755633;
        public static final int Widget_MaterialComponents_ExtendedFloatingActionButton_Icon = 2131755634;
        public static final int Widget_MaterialComponents_FloatingActionButton = 2131755635;
        public static final int Widget_MaterialComponents_Light_ActionBar_Solid = 2131755636;
        public static final int Widget_MaterialComponents_MaterialButtonToggleGroup = 2131755637;
        public static final int Widget_MaterialComponents_MaterialCalendar = 2131755638;
        public static final int Widget_MaterialComponents_MaterialCalendar_Day = 2131755639;
        public static final int Widget_MaterialComponents_MaterialCalendar_DayTextView = 2131755643;
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Invalid = 2131755640;
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Selected = 2131755641;
        public static final int Widget_MaterialComponents_MaterialCalendar_Day_Today = 2131755642;
        public static final int Widget_MaterialComponents_MaterialCalendar_Fullscreen = 2131755644;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderConfirmButton = 2131755645;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderDivider = 2131755646;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderLayout = 2131755647;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderSelection = 2131755648;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderSelection_Fullscreen = 2131755649;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderTitle = 2131755650;
        public static final int Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 2131755651;
        public static final int Widget_MaterialComponents_MaterialCalendar_Item = 2131755652;
        public static final int Widget_MaterialComponents_MaterialCalendar_Year = 2131755653;
        public static final int Widget_MaterialComponents_MaterialCalendar_Year_Selected = 2131755654;
        public static final int Widget_MaterialComponents_MaterialCalendar_Year_Today = 2131755655;
        public static final int Widget_MaterialComponents_NavigationView = 2131755656;
        public static final int Widget_MaterialComponents_PopupMenu = 2131755657;
        public static final int Widget_MaterialComponents_PopupMenu_ContextMenu = 2131755658;
        public static final int Widget_MaterialComponents_PopupMenu_ListPopupWindow = 2131755659;
        public static final int Widget_MaterialComponents_PopupMenu_Overflow = 2131755660;
        public static final int Widget_MaterialComponents_Snackbar = 2131755661;
        public static final int Widget_MaterialComponents_Snackbar_FullWidth = 2131755662;
        public static final int Widget_MaterialComponents_TabLayout = 2131755663;
        public static final int Widget_MaterialComponents_TabLayout_Colored = 2131755664;
        public static final int Widget_MaterialComponents_TabLayout_PrimarySurface = 2131755665;
        public static final int Widget_MaterialComponents_TextInputEditText_FilledBox = 2131755666;
        public static final int Widget_MaterialComponents_TextInputEditText_FilledBox_Dense = 2131755667;
        public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox = 2131755668;
        public static final int Widget_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 2131755669;
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox = 2131755670;
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense = 2131755671;
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense_ExposedDropdownMenu = 2131755672;
        public static final int Widget_MaterialComponents_TextInputLayout_FilledBox_ExposedDropdownMenu = 2131755673;
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox = 2131755674;
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense = 2131755675;
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense_ExposedDropdownMenu = 2131755676;
        public static final int Widget_MaterialComponents_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 2131755677;
        public static final int Widget_MaterialComponents_TextView = 2131755678;
        public static final int Widget_MaterialComponents_Toolbar = 2131755679;
        public static final int Widget_MaterialComponents_Toolbar_Primary = 2131755680;
        public static final int Widget_MaterialComponents_Toolbar_PrimarySurface = 2131755681;
        public static final int Widget_MaterialComponents_Toolbar_Surface = 2131755682;
        public static final int Widget_Support_CoordinatorLayout = 2131755683;
        /* added by JADX */
        /* renamed from: AlertDialog.AppCompat */
        public static final int f0AlertDialog.AppCompat = 2131755008;
        /* added by JADX */
        /* renamed from: AlertDialog.AppCompat.Light */
        public static final int f1AlertDialog.AppCompat.Light = 2131755009;
        /* added by JADX */
        /* renamed from: Animation.AppCompat.Dialog */
        public static final int f2Animation.AppCompat.Dialog = 2131755010;
        /* added by JADX */
        /* renamed from: Animation.AppCompat.DropDownUp */
        public static final int f3Animation.AppCompat.DropDownUp = 2131755011;
        /* added by JADX */
        /* renamed from: Animation.AppCompat.Tooltip */
        public static final int f4Animation.AppCompat.Tooltip = 2131755012;
        /* added by JADX */
        /* renamed from: Animation.Design.BottomSheetDialog */
        public static final int f5Animation.Design.BottomSheetDialog = 2131755013;
        /* added by JADX */
        /* renamed from: Animation.MaterialComponents.BottomSheetDialog */
        public static final int f6Animation.MaterialComponents.BottomSheetDialog = 2131755014;
        /* added by JADX */
        /* renamed from: Base.AlertDialog.AppCompat */
        public static final int f7Base.AlertDialog.AppCompat = 2131755016;
        /* added by JADX */
        /* renamed from: Base.AlertDialog.AppCompat.Light */
        public static final int f8Base.AlertDialog.AppCompat.Light = 2131755017;
        /* added by JADX */
        /* renamed from: Base.Animation.AppCompat.Dialog */
        public static final int f9Base.Animation.AppCompat.Dialog = 2131755018;
        /* added by JADX */
        /* renamed from: Base.Animation.AppCompat.DropDownUp */
        public static final int f10Base.Animation.AppCompat.DropDownUp = 2131755019;
        /* added by JADX */
        /* renamed from: Base.Animation.AppCompat.Tooltip */
        public static final int f11Base.Animation.AppCompat.Tooltip = 2131755020;
        /* added by JADX */
        /* renamed from: Base.CardView */
        public static final int f12Base.CardView = 2131755021;
        /* added by JADX */
        /* renamed from: Base.DialogWindowTitle.AppCompat */
        public static final int f13Base.DialogWindowTitle.AppCompat = 2131755022;
        /* added by JADX */
        /* renamed from: Base.DialogWindowTitleBackground.AppCompat */
        public static final int f14Base.DialogWindowTitleBackground.AppCompat = 2131755023;
        /* added by JADX */
        /* renamed from: Base.MaterialAlertDialog.MaterialComponents.Title.Icon */
        public static final int f15Base.MaterialAlertDialog.MaterialComponents.Title.Icon = 2131755024;
        /* added by JADX */
        /* renamed from: Base.MaterialAlertDialog.MaterialComponents.Title.Panel */
        public static final int f16Base.MaterialAlertDialog.MaterialComponents.Title.Panel = 2131755025;
        /* added by JADX */
        /* renamed from: Base.MaterialAlertDialog.MaterialComponents.Title.Text */
        public static final int f17Base.MaterialAlertDialog.MaterialComponents.Title.Text = 2131755026;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat */
        public static final int f18Base.TextAppearance.AppCompat = 2131755027;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Body1 */
        public static final int f19Base.TextAppearance.AppCompat.Body1 = 2131755028;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Body2 */
        public static final int f20Base.TextAppearance.AppCompat.Body2 = 2131755029;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Button */
        public static final int f21Base.TextAppearance.AppCompat.Button = 2131755030;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Caption */
        public static final int f22Base.TextAppearance.AppCompat.Caption = 2131755031;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Display1 */
        public static final int f23Base.TextAppearance.AppCompat.Display1 = 2131755032;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Display2 */
        public static final int f24Base.TextAppearance.AppCompat.Display2 = 2131755033;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Display3 */
        public static final int f25Base.TextAppearance.AppCompat.Display3 = 2131755034;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Display4 */
        public static final int f26Base.TextAppearance.AppCompat.Display4 = 2131755035;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Headline */
        public static final int f27Base.TextAppearance.AppCompat.Headline = 2131755036;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Inverse */
        public static final int f28Base.TextAppearance.AppCompat.Inverse = 2131755037;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Large */
        public static final int f29Base.TextAppearance.AppCompat.Large = 2131755038;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Large.Inverse */
        public static final int f30Base.TextAppearance.AppCompat.Large.Inverse = 2131755039;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Large */
        public static final int f31Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Large = 2131755040;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Small */
        public static final int f32Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Small = 2131755041;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Medium */
        public static final int f33Base.TextAppearance.AppCompat.Medium = 2131755042;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Medium.Inverse */
        public static final int f34Base.TextAppearance.AppCompat.Medium.Inverse = 2131755043;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Menu */
        public static final int f35Base.TextAppearance.AppCompat.Menu = 2131755044;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.SearchResult */
        public static final int f36Base.TextAppearance.AppCompat.SearchResult = 2131755045;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.SearchResult.Subtitle */
        public static final int f37Base.TextAppearance.AppCompat.SearchResult.Subtitle = 2131755046;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.SearchResult.Title */
        public static final int f38Base.TextAppearance.AppCompat.SearchResult.Title = 2131755047;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Small */
        public static final int f39Base.TextAppearance.AppCompat.Small = 2131755048;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Small.Inverse */
        public static final int f40Base.TextAppearance.AppCompat.Small.Inverse = 2131755049;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Subhead */
        public static final int f41Base.TextAppearance.AppCompat.Subhead = 2131755050;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Subhead.Inverse */
        public static final int f42Base.TextAppearance.AppCompat.Subhead.Inverse = 2131755051;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Title */
        public static final int f43Base.TextAppearance.AppCompat.Title = 2131755052;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Title.Inverse */
        public static final int f44Base.TextAppearance.AppCompat.Title.Inverse = 2131755053;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Tooltip */
        public static final int f45Base.TextAppearance.AppCompat.Tooltip = 2131755054;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Menu */
        public static final int f46Base.TextAppearance.AppCompat.Widget.ActionBar.Menu = 2131755055;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle */
        public static final int f47Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle = 2131755056;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse */
        public static final int f48Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse = 2131755057;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Title */
        public static final int f49Base.TextAppearance.AppCompat.Widget.ActionBar.Title = 2131755058;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse */
        public static final int f50Base.TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse = 2131755059;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionMode.Subtitle */
        public static final int f51Base.TextAppearance.AppCompat.Widget.ActionMode.Subtitle = 2131755060;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionMode.Title */
        public static final int f52Base.TextAppearance.AppCompat.Widget.ActionMode.Title = 2131755061;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button */
        public static final int f53Base.TextAppearance.AppCompat.Widget.Button = 2131755062;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button.Borderless.Colored */
        public static final int f54Base.TextAppearance.AppCompat.Widget.Button.Borderless.Colored = 2131755063;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button.Colored */
        public static final int f55Base.TextAppearance.AppCompat.Widget.Button.Colored = 2131755064;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button.Inverse */
        public static final int f56Base.TextAppearance.AppCompat.Widget.Button.Inverse = 2131755065;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.DropDownItem */
        public static final int f57Base.TextAppearance.AppCompat.Widget.DropDownItem = 2131755066;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.PopupMenu.Header */
        public static final int f58Base.TextAppearance.AppCompat.Widget.PopupMenu.Header = 2131755067;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.PopupMenu.Large */
        public static final int f59Base.TextAppearance.AppCompat.Widget.PopupMenu.Large = 2131755068;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.PopupMenu.Small */
        public static final int f60Base.TextAppearance.AppCompat.Widget.PopupMenu.Small = 2131755069;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Switch */
        public static final int f61Base.TextAppearance.AppCompat.Widget.Switch = 2131755070;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.TextView.SpinnerItem */
        public static final int f62Base.TextAppearance.AppCompat.Widget.TextView.SpinnerItem = 2131755071;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.MaterialComponents.Badge */
        public static final int f63Base.TextAppearance.MaterialComponents.Badge = 2131755072;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.MaterialComponents.Button */
        public static final int f64Base.TextAppearance.MaterialComponents.Button = 2131755073;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.MaterialComponents.Headline6 */
        public static final int f65Base.TextAppearance.MaterialComponents.Headline6 = 2131755074;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.MaterialComponents.Subtitle2 */
        public static final int f66Base.TextAppearance.MaterialComponents.Subtitle2 = 2131755075;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.Widget.AppCompat.ExpandedMenu.Item */
        public static final int f67Base.TextAppearance.Widget.AppCompat.ExpandedMenu.Item = 2131755076;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.Widget.AppCompat.Toolbar.Subtitle */
        public static final int f68Base.TextAppearance.Widget.AppCompat.Toolbar.Subtitle = 2131755077;
        /* added by JADX */
        /* renamed from: Base.TextAppearance.Widget.AppCompat.Toolbar.Title */
        public static final int f69Base.TextAppearance.Widget.AppCompat.Toolbar.Title = 2131755078;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat */
        public static final int f70Base.Theme.AppCompat = 2131755079;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.CompactMenu */
        public static final int f71Base.Theme.AppCompat.CompactMenu = 2131755080;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Dialog */
        public static final int f72Base.Theme.AppCompat.Dialog = 2131755081;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Dialog.Alert */
        public static final int f73Base.Theme.AppCompat.Dialog.Alert = 2131755082;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Dialog.FixedSize */
        public static final int f74Base.Theme.AppCompat.Dialog.FixedSize = 2131755083;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Dialog.MinWidth */
        public static final int f75Base.Theme.AppCompat.Dialog.MinWidth = 2131755084;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.DialogWhenLarge */
        public static final int f76Base.Theme.AppCompat.DialogWhenLarge = 2131755085;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light */
        public static final int f77Base.Theme.AppCompat.Light = 2131755086;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light.DarkActionBar */
        public static final int f78Base.Theme.AppCompat.Light.DarkActionBar = 2131755087;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog */
        public static final int f79Base.Theme.AppCompat.Light.Dialog = 2131755088;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog.Alert */
        public static final int f80Base.Theme.AppCompat.Light.Dialog.Alert = 2131755089;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog.FixedSize */
        public static final int f81Base.Theme.AppCompat.Light.Dialog.FixedSize = 2131755090;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog.MinWidth */
        public static final int f82Base.Theme.AppCompat.Light.Dialog.MinWidth = 2131755091;
        /* added by JADX */
        /* renamed from: Base.Theme.AppCompat.Light.DialogWhenLarge */
        public static final int f83Base.Theme.AppCompat.Light.DialogWhenLarge = 2131755092;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents */
        public static final int f84Base.Theme.MaterialComponents = 2131755093;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Bridge */
        public static final int f85Base.Theme.MaterialComponents.Bridge = 2131755094;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.CompactMenu */
        public static final int f86Base.Theme.MaterialComponents.CompactMenu = 2131755095;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Dialog */
        public static final int f87Base.Theme.MaterialComponents.Dialog = 2131755096;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.Alert */
        public static final int f88Base.Theme.MaterialComponents.Dialog.Alert = 2131755097;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.Bridge */
        public static final int f89Base.Theme.MaterialComponents.Dialog.Bridge = 2131755098;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.FixedSize */
        public static final int f90Base.Theme.MaterialComponents.Dialog.FixedSize = 2131755099;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.MinWidth */
        public static final int f91Base.Theme.MaterialComponents.Dialog.MinWidth = 2131755100;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.DialogWhenLarge */
        public static final int f92Base.Theme.MaterialComponents.DialogWhenLarge = 2131755101;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light */
        public static final int f93Base.Theme.MaterialComponents.Light = 2131755102;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.Bridge */
        public static final int f94Base.Theme.MaterialComponents.Light.Bridge = 2131755103;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.DarkActionBar */
        public static final int f95Base.Theme.MaterialComponents.Light.DarkActionBar = 2131755104;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.DarkActionBar.Bridge */
        public static final int f96Base.Theme.MaterialComponents.Light.DarkActionBar.Bridge = 2131755105;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog */
        public static final int f97Base.Theme.MaterialComponents.Light.Dialog = 2131755106;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.Alert */
        public static final int f98Base.Theme.MaterialComponents.Light.Dialog.Alert = 2131755107;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.Bridge */
        public static final int f99Base.Theme.MaterialComponents.Light.Dialog.Bridge = 2131755108;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.FixedSize */
        public static final int f100Base.Theme.MaterialComponents.Light.Dialog.FixedSize = 2131755109;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.MinWidth */
        public static final int f101Base.Theme.MaterialComponents.Light.Dialog.MinWidth = 2131755110;
        /* added by JADX */
        /* renamed from: Base.Theme.MaterialComponents.Light.DialogWhenLarge */
        public static final int f102Base.Theme.MaterialComponents.Light.DialogWhenLarge = 2131755111;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat */
        public static final int f103Base.ThemeOverlay.AppCompat = 2131755112;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat.ActionBar */
        public static final int f104Base.ThemeOverlay.AppCompat.ActionBar = 2131755113;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dark */
        public static final int f105Base.ThemeOverlay.AppCompat.Dark = 2131755114;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dark.ActionBar */
        public static final int f106Base.ThemeOverlay.AppCompat.Dark.ActionBar = 2131755115;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dialog */
        public static final int f107Base.ThemeOverlay.AppCompat.Dialog = 2131755116;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dialog.Alert */
        public static final int f108Base.ThemeOverlay.AppCompat.Dialog.Alert = 2131755117;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.AppCompat.Light */
        public static final int f109Base.ThemeOverlay.AppCompat.Light = 2131755118;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.Dialog */
        public static final int f110Base.ThemeOverlay.MaterialComponents.Dialog = 2131755119;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.Dialog.Alert */
        public static final int f111Base.ThemeOverlay.MaterialComponents.Dialog.Alert = 2131755120;
        /* added by JADX */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.MaterialAlertDialog */
        public static final int f112Base.ThemeOverlay.MaterialComponents.MaterialAlertDialog = 2131755121;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents */
        public static final int f113Base.V14.Theme.MaterialComponents = 2131755122;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Bridge */
        public static final int f114Base.V14.Theme.MaterialComponents.Bridge = 2131755123;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Dialog */
        public static final int f115Base.V14.Theme.MaterialComponents.Dialog = 2131755124;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Dialog.Bridge */
        public static final int f116Base.V14.Theme.MaterialComponents.Dialog.Bridge = 2131755125;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light */
        public static final int f117Base.V14.Theme.MaterialComponents.Light = 2131755126;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.Bridge */
        public static final int f118Base.V14.Theme.MaterialComponents.Light.Bridge = 2131755127;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.DarkActionBar.Bridge */
        public static final int f119Base.V14.Theme.MaterialComponents.Light.DarkActionBar.Bridge = 2131755128;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.Dialog */
        public static final int f120Base.V14.Theme.MaterialComponents.Light.Dialog = 2131755129;
        /* added by JADX */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.Dialog.Bridge */
        public static final int f121Base.V14.Theme.MaterialComponents.Light.Dialog.Bridge = 2131755130;
        /* added by JADX */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.Dialog */
        public static final int f122Base.V14.ThemeOverlay.MaterialComponents.Dialog = 2131755131;
        /* added by JADX */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.Dialog.Alert */
        public static final int f123Base.V14.ThemeOverlay.MaterialComponents.Dialog.Alert = 2131755132;
        /* added by JADX */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.MaterialAlertDialog */
        public static final int f124Base.V14.ThemeOverlay.MaterialComponents.MaterialAlertDialog = 2131755133;
        /* added by JADX */
        /* renamed from: Base.V21.Theme.AppCompat */
        public static final int f125Base.V21.Theme.AppCompat = 2131755134;
        /* added by JADX */
        /* renamed from: Base.V21.Theme.AppCompat.Dialog */
        public static final int f126Base.V21.Theme.AppCompat.Dialog = 2131755135;
        /* added by JADX */
        /* renamed from: Base.V21.Theme.AppCompat.Light */
        public static final int f127Base.V21.Theme.AppCompat.Light = 2131755136;
        /* added by JADX */
        /* renamed from: Base.V21.Theme.AppCompat.Light.Dialog */
        public static final int f128Base.V21.Theme.AppCompat.Light.Dialog = 2131755137;
        /* added by JADX */
        /* renamed from: Base.V21.ThemeOverlay.AppCompat.Dialog */
        public static final int f129Base.V21.ThemeOverlay.AppCompat.Dialog = 2131755138;
        /* added by JADX */
        /* renamed from: Base.V22.Theme.AppCompat */
        public static final int f130Base.V22.Theme.AppCompat = 2131755139;
        /* added by JADX */
        /* renamed from: Base.V22.Theme.AppCompat.Light */
        public static final int f131Base.V22.Theme.AppCompat.Light = 2131755140;
        /* added by JADX */
        /* renamed from: Base.V23.Theme.AppCompat */
        public static final int f132Base.V23.Theme.AppCompat = 2131755141;
        /* added by JADX */
        /* renamed from: Base.V23.Theme.AppCompat.Light */
        public static final int f133Base.V23.Theme.AppCompat.Light = 2131755142;
        /* added by JADX */
        /* renamed from: Base.V26.Theme.AppCompat */
        public static final int f134Base.V26.Theme.AppCompat = 2131755143;
        /* added by JADX */
        /* renamed from: Base.V26.Theme.AppCompat.Light */
        public static final int f135Base.V26.Theme.AppCompat.Light = 2131755144;
        /* added by JADX */
        /* renamed from: Base.V26.Widget.AppCompat.Toolbar */
        public static final int f136Base.V26.Widget.AppCompat.Toolbar = 2131755145;
        /* added by JADX */
        /* renamed from: Base.V28.Theme.AppCompat */
        public static final int f137Base.V28.Theme.AppCompat = 2131755146;
        /* added by JADX */
        /* renamed from: Base.V28.Theme.AppCompat.Light */
        public static final int f138Base.V28.Theme.AppCompat.Light = 2131755147;
        /* added by JADX */
        /* renamed from: Base.V7.Theme.AppCompat */
        public static final int f139Base.V7.Theme.AppCompat = 2131755148;
        /* added by JADX */
        /* renamed from: Base.V7.Theme.AppCompat.Dialog */
        public static final int f140Base.V7.Theme.AppCompat.Dialog = 2131755149;
        /* added by JADX */
        /* renamed from: Base.V7.Theme.AppCompat.Light */
        public static final int f141Base.V7.Theme.AppCompat.Light = 2131755150;
        /* added by JADX */
        /* renamed from: Base.V7.Theme.AppCompat.Light.Dialog */
        public static final int f142Base.V7.Theme.AppCompat.Light.Dialog = 2131755151;
        /* added by JADX */
        /* renamed from: Base.V7.ThemeOverlay.AppCompat.Dialog */
        public static final int f143Base.V7.ThemeOverlay.AppCompat.Dialog = 2131755152;
        /* added by JADX */
        /* renamed from: Base.V7.Widget.AppCompat.AutoCompleteTextView */
        public static final int f144Base.V7.Widget.AppCompat.AutoCompleteTextView = 2131755153;
        /* added by JADX */
        /* renamed from: Base.V7.Widget.AppCompat.EditText */
        public static final int f145Base.V7.Widget.AppCompat.EditText = 2131755154;
        /* added by JADX */
        /* renamed from: Base.V7.Widget.AppCompat.Toolbar */
        public static final int f146Base.V7.Widget.AppCompat.Toolbar = 2131755155;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionBar */
        public static final int f147Base.Widget.AppCompat.ActionBar = 2131755156;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionBar.Solid */
        public static final int f148Base.Widget.AppCompat.ActionBar.Solid = 2131755157;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionBar.TabBar */
        public static final int f149Base.Widget.AppCompat.ActionBar.TabBar = 2131755158;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionBar.TabText */
        public static final int f150Base.Widget.AppCompat.ActionBar.TabText = 2131755159;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionBar.TabView */
        public static final int f151Base.Widget.AppCompat.ActionBar.TabView = 2131755160;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionButton */
        public static final int f152Base.Widget.AppCompat.ActionButton = 2131755161;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionButton.CloseMode */
        public static final int f153Base.Widget.AppCompat.ActionButton.CloseMode = 2131755162;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionButton.Overflow */
        public static final int f154Base.Widget.AppCompat.ActionButton.Overflow = 2131755163;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActionMode */
        public static final int f155Base.Widget.AppCompat.ActionMode = 2131755164;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ActivityChooserView */
        public static final int f156Base.Widget.AppCompat.ActivityChooserView = 2131755165;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.AutoCompleteTextView */
        public static final int f157Base.Widget.AppCompat.AutoCompleteTextView = 2131755166;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Button */
        public static final int f158Base.Widget.AppCompat.Button = 2131755167;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Button.Borderless */
        public static final int f159Base.Widget.AppCompat.Button.Borderless = 2131755168;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Button.Borderless.Colored */
        public static final int f160Base.Widget.AppCompat.Button.Borderless.Colored = 2131755169;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Button.ButtonBar.AlertDialog */
        public static final int f161Base.Widget.AppCompat.Button.ButtonBar.AlertDialog = 2131755170;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Button.Colored */
        public static final int f162Base.Widget.AppCompat.Button.Colored = 2131755171;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Button.Small */
        public static final int f163Base.Widget.AppCompat.Button.Small = 2131755172;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ButtonBar */
        public static final int f164Base.Widget.AppCompat.ButtonBar = 2131755173;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ButtonBar.AlertDialog */
        public static final int f165Base.Widget.AppCompat.ButtonBar.AlertDialog = 2131755174;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.CompoundButton.CheckBox */
        public static final int f166Base.Widget.AppCompat.CompoundButton.CheckBox = 2131755175;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.CompoundButton.RadioButton */
        public static final int f167Base.Widget.AppCompat.CompoundButton.RadioButton = 2131755176;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.CompoundButton.Switch */
        public static final int f168Base.Widget.AppCompat.CompoundButton.Switch = 2131755177;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.DrawerArrowToggle */
        public static final int f169Base.Widget.AppCompat.DrawerArrowToggle = 2131755178;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.DrawerArrowToggle.Common */
        public static final int f170Base.Widget.AppCompat.DrawerArrowToggle.Common = 2131755179;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.DropDownItem.Spinner */
        public static final int f171Base.Widget.AppCompat.DropDownItem.Spinner = 2131755180;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.EditText */
        public static final int f172Base.Widget.AppCompat.EditText = 2131755181;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ImageButton */
        public static final int f173Base.Widget.AppCompat.ImageButton = 2131755182;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar */
        public static final int f174Base.Widget.AppCompat.Light.ActionBar = 2131755183;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.Solid */
        public static final int f175Base.Widget.AppCompat.Light.ActionBar.Solid = 2131755184;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabBar */
        public static final int f176Base.Widget.AppCompat.Light.ActionBar.TabBar = 2131755185;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabText */
        public static final int f177Base.Widget.AppCompat.Light.ActionBar.TabText = 2131755186;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabText.Inverse */
        public static final int f178Base.Widget.AppCompat.Light.ActionBar.TabText.Inverse = 2131755187;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabView */
        public static final int f179Base.Widget.AppCompat.Light.ActionBar.TabView = 2131755188;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.PopupMenu */
        public static final int f180Base.Widget.AppCompat.Light.PopupMenu = 2131755189;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Light.PopupMenu.Overflow */
        public static final int f181Base.Widget.AppCompat.Light.PopupMenu.Overflow = 2131755190;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ListMenuView */
        public static final int f182Base.Widget.AppCompat.ListMenuView = 2131755191;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ListPopupWindow */
        public static final int f183Base.Widget.AppCompat.ListPopupWindow = 2131755192;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ListView */
        public static final int f184Base.Widget.AppCompat.ListView = 2131755193;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ListView.DropDown */
        public static final int f185Base.Widget.AppCompat.ListView.DropDown = 2131755194;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ListView.Menu */
        public static final int f186Base.Widget.AppCompat.ListView.Menu = 2131755195;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.PopupMenu */
        public static final int f187Base.Widget.AppCompat.PopupMenu = 2131755196;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.PopupMenu.Overflow */
        public static final int f188Base.Widget.AppCompat.PopupMenu.Overflow = 2131755197;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.PopupWindow */
        public static final int f189Base.Widget.AppCompat.PopupWindow = 2131755198;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ProgressBar */
        public static final int f190Base.Widget.AppCompat.ProgressBar = 2131755199;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.ProgressBar.Horizontal */
        public static final int f191Base.Widget.AppCompat.ProgressBar.Horizontal = 2131755200;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.RatingBar */
        public static final int f192Base.Widget.AppCompat.RatingBar = 2131755201;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.RatingBar.Indicator */
        public static final int f193Base.Widget.AppCompat.RatingBar.Indicator = 2131755202;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.RatingBar.Small */
        public static final int f194Base.Widget.AppCompat.RatingBar.Small = 2131755203;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.SearchView */
        public static final int f195Base.Widget.AppCompat.SearchView = 2131755204;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.SearchView.ActionBar */
        public static final int f196Base.Widget.AppCompat.SearchView.ActionBar = 2131755205;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.SeekBar */
        public static final int f197Base.Widget.AppCompat.SeekBar = 2131755206;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.SeekBar.Discrete */
        public static final int f198Base.Widget.AppCompat.SeekBar.Discrete = 2131755207;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Spinner */
        public static final int f199Base.Widget.AppCompat.Spinner = 2131755208;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Spinner.Underlined */
        public static final int f200Base.Widget.AppCompat.Spinner.Underlined = 2131755209;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.TextView */
        public static final int f201Base.Widget.AppCompat.TextView = 2131755210;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.TextView.SpinnerItem */
        public static final int f202Base.Widget.AppCompat.TextView.SpinnerItem = 2131755211;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Toolbar */
        public static final int f203Base.Widget.AppCompat.Toolbar = 2131755212;
        /* added by JADX */
        /* renamed from: Base.Widget.AppCompat.Toolbar.Button.Navigation */
        public static final int f204Base.Widget.AppCompat.Toolbar.Button.Navigation = 2131755213;
        /* added by JADX */
        /* renamed from: Base.Widget.Design.TabLayout */
        public static final int f205Base.Widget.Design.TabLayout = 2131755214;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.AutoCompleteTextView */
        public static final int f206Base.Widget.MaterialComponents.AutoCompleteTextView = 2131755215;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.CheckedTextView */
        public static final int f207Base.Widget.MaterialComponents.CheckedTextView = 2131755216;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.Chip */
        public static final int f208Base.Widget.MaterialComponents.Chip = 2131755217;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu */
        public static final int f209Base.Widget.MaterialComponents.PopupMenu = 2131755218;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu.ContextMenu */
        public static final int f210Base.Widget.MaterialComponents.PopupMenu.ContextMenu = 2131755219;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu.ListPopupWindow */
        public static final int f211Base.Widget.MaterialComponents.PopupMenu.ListPopupWindow = 2131755220;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu.Overflow */
        public static final int f212Base.Widget.MaterialComponents.PopupMenu.Overflow = 2131755221;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.TextInputEditText */
        public static final int f213Base.Widget.MaterialComponents.TextInputEditText = 2131755222;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.TextInputLayout */
        public static final int f214Base.Widget.MaterialComponents.TextInputLayout = 2131755223;
        /* added by JADX */
        /* renamed from: Base.Widget.MaterialComponents.TextView */
        public static final int f215Base.Widget.MaterialComponents.TextView = 2131755224;
        /* added by JADX */
        /* renamed from: CardView.Dark */
        public static final int f216CardView.Dark = 2131755226;
        /* added by JADX */
        /* renamed from: CardView.Light */
        public static final int f217CardView.Light = 2131755227;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents */
        public static final int f218MaterialAlertDialog.MaterialComponents = 2131755229;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Body.Text */
        public static final int f219MaterialAlertDialog.MaterialComponents.Body.Text = 2131755230;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Picker.Date.Calendar */
        public static final int f220MaterialAlertDialog.MaterialComponents.Picker.Date.Calendar = 2131755231;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Picker.Date.Spinner */
        public static final int f221MaterialAlertDialog.MaterialComponents.Picker.Date.Spinner = 2131755232;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Icon */
        public static final int f222MaterialAlertDialog.MaterialComponents.Title.Icon = 2131755233;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Icon.CenterStacked */
        public static final int f223MaterialAlertDialog.MaterialComponents.Title.Icon.CenterStacked = 2131755234;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Panel */
        public static final int f224MaterialAlertDialog.MaterialComponents.Title.Panel = 2131755235;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Panel.CenterStacked */
        public static final int f225MaterialAlertDialog.MaterialComponents.Title.Panel.CenterStacked = 2131755236;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Text */
        public static final int f226MaterialAlertDialog.MaterialComponents.Title.Text = 2131755237;
        /* added by JADX */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Text.CenterStacked */
        public static final int f227MaterialAlertDialog.MaterialComponents.Title.Text.CenterStacked = 2131755238;
        /* added by JADX */
        /* renamed from: Platform.AppCompat */
        public static final int f228Platform.AppCompat = 2131755239;
        /* added by JADX */
        /* renamed from: Platform.AppCompat.Light */
        public static final int f229Platform.AppCompat.Light = 2131755240;
        /* added by JADX */
        /* renamed from: Platform.MaterialComponents */
        public static final int f230Platform.MaterialComponents = 2131755241;
        /* added by JADX */
        /* renamed from: Platform.MaterialComponents.Dialog */
        public static final int f231Platform.MaterialComponents.Dialog = 2131755242;
        /* added by JADX */
        /* renamed from: Platform.MaterialComponents.Light */
        public static final int f232Platform.MaterialComponents.Light = 2131755243;
        /* added by JADX */
        /* renamed from: Platform.MaterialComponents.Light.Dialog */
        public static final int f233Platform.MaterialComponents.Light.Dialog = 2131755244;
        /* added by JADX */
        /* renamed from: Platform.ThemeOverlay.AppCompat */
        public static final int f234Platform.ThemeOverlay.AppCompat = 2131755245;
        /* added by JADX */
        /* renamed from: Platform.ThemeOverlay.AppCompat.Dark */
        public static final int f235Platform.ThemeOverlay.AppCompat.Dark = 2131755246;
        /* added by JADX */
        /* renamed from: Platform.ThemeOverlay.AppCompat.Light */
        public static final int f236Platform.ThemeOverlay.AppCompat.Light = 2131755247;
        /* added by JADX */
        /* renamed from: Platform.V21.AppCompat */
        public static final int f237Platform.V21.AppCompat = 2131755248;
        /* added by JADX */
        /* renamed from: Platform.V21.AppCompat.Light */
        public static final int f238Platform.V21.AppCompat.Light = 2131755249;
        /* added by JADX */
        /* renamed from: Platform.V25.AppCompat */
        public static final int f239Platform.V25.AppCompat = 2131755250;
        /* added by JADX */
        /* renamed from: Platform.V25.AppCompat.Light */
        public static final int f240Platform.V25.AppCompat.Light = 2131755251;
        /* added by JADX */
        /* renamed from: Platform.Widget.AppCompat.Spinner */
        public static final int f241Platform.Widget.AppCompat.Spinner = 2131755252;
        /* added by JADX */
        /* renamed from: RtlOverlay.DialogWindowTitle.AppCompat */
        public static final int f242RtlOverlay.DialogWindowTitle.AppCompat = 2131755253;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.ActionBar.TitleItem */
        public static final int f243RtlOverlay.Widget.AppCompat.ActionBar.TitleItem = 2131755254;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.DialogTitle.Icon */
        public static final int f244RtlOverlay.Widget.AppCompat.DialogTitle.Icon = 2131755255;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem */
        public static final int f245RtlOverlay.Widget.AppCompat.PopupMenuItem = 2131755256;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.InternalGroup */
        public static final int f246RtlOverlay.Widget.AppCompat.PopupMenuItem.InternalGroup = 2131755257;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.Shortcut */
        public static final int f247RtlOverlay.Widget.AppCompat.PopupMenuItem.Shortcut = 2131755258;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.SubmenuArrow */
        public static final int f248RtlOverlay.Widget.AppCompat.PopupMenuItem.SubmenuArrow = 2131755259;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.Text */
        public static final int f249RtlOverlay.Widget.AppCompat.PopupMenuItem.Text = 2131755260;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.Title */
        public static final int f250RtlOverlay.Widget.AppCompat.PopupMenuItem.Title = 2131755261;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown */
        public static final int f251RtlOverlay.Widget.AppCompat.Search.DropDown = 2131755262;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Icon1 */
        public static final int f252RtlOverlay.Widget.AppCompat.Search.DropDown.Icon1 = 2131755263;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Icon2 */
        public static final int f253RtlOverlay.Widget.AppCompat.Search.DropDown.Icon2 = 2131755264;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Query */
        public static final int f254RtlOverlay.Widget.AppCompat.Search.DropDown.Query = 2131755265;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Text */
        public static final int f255RtlOverlay.Widget.AppCompat.Search.DropDown.Text = 2131755266;
        /* added by JADX */
        /* renamed from: RtlOverlay.Widget.AppCompat.SearchView.MagIcon */
        public static final int f256RtlOverlay.Widget.AppCompat.SearchView.MagIcon = 2131755267;
        /* added by JADX */
        /* renamed from: RtlUnderlay.Widget.AppCompat.ActionButton */
        public static final int f257RtlUnderlay.Widget.AppCompat.ActionButton = 2131755268;
        /* added by JADX */
        /* renamed from: RtlUnderlay.Widget.AppCompat.ActionButton.Overflow */
        public static final int f258RtlUnderlay.Widget.AppCompat.ActionButton.Overflow = 2131755269;
        /* added by JADX */
        /* renamed from: ShapeAppearance.MaterialComponents */
        public static final int f259ShapeAppearance.MaterialComponents = 2131755270;
        /* added by JADX */
        /* renamed from: ShapeAppearance.MaterialComponents.LargeComponent */
        public static final int f260ShapeAppearance.MaterialComponents.LargeComponent = 2131755271;
        /* added by JADX */
        /* renamed from: ShapeAppearance.MaterialComponents.MediumComponent */
        public static final int f261ShapeAppearance.MaterialComponents.MediumComponent = 2131755272;
        /* added by JADX */
        /* renamed from: ShapeAppearance.MaterialComponents.SmallComponent */
        public static final int f262ShapeAppearance.MaterialComponents.SmallComponent = 2131755273;
        /* added by JADX */
        /* renamed from: ShapeAppearance.MaterialComponents.Test */
        public static final int f263ShapeAppearance.MaterialComponents.Test = 2131755274;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.BottomLeftDifferentCornerSize */
        public static final int f264ShapeAppearanceOverlay.BottomLeftDifferentCornerSize = 2131755276;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.BottomRightCut */
        public static final int f265ShapeAppearanceOverlay.BottomRightCut = 2131755277;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.Cut */
        public static final int f266ShapeAppearanceOverlay.Cut = 2131755278;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.DifferentCornerSize */
        public static final int f267ShapeAppearanceOverlay.DifferentCornerSize = 2131755279;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.BottomSheet */
        public static final int f268ShapeAppearanceOverlay.MaterialComponents.BottomSheet = 2131755280;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.Chip */
        public static final int f269ShapeAppearanceOverlay.MaterialComponents.Chip = 2131755281;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.ExtendedFloatingActionButton */
        public static final int f270x84132995 = 2131755282;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.FloatingActionButton */
        public static final int f271ShapeAppearanceOverlay.MaterialComponents.FloatingActionButton = 2131755283;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Day */
        public static final int f272ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Day = 2131755284;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Window.Fullscreen */
        public static final int f273x43a8845e = 2131755285;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Year */
        public static final int f274ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Year = 2131755286;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.TextInputLayout.FilledBox */
        public static final int f275xf9d7f814 = 2131755287;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.TopLeftCut */
        public static final int f276ShapeAppearanceOverlay.TopLeftCut = 2131755288;
        /* added by JADX */
        /* renamed from: ShapeAppearanceOverlay.TopRightDifferentCornerSize */
        public static final int f277ShapeAppearanceOverlay.TopRightDifferentCornerSize = 2131755289;
        /* added by JADX */
        /* renamed from: Test.ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Day */
        public static final int f278xc2beccdd = 2131755290;
        /* added by JADX */
        /* renamed from: Test.Theme.MaterialComponents.MaterialCalendar */
        public static final int f279Test.Theme.MaterialComponents.MaterialCalendar = 2131755291;
        /* added by JADX */
        /* renamed from: Test.Widget.MaterialComponents.MaterialCalendar */
        public static final int f280Test.Widget.MaterialComponents.MaterialCalendar = 2131755292;
        /* added by JADX */
        /* renamed from: Test.Widget.MaterialComponents.MaterialCalendar.Day */
        public static final int f281Test.Widget.MaterialComponents.MaterialCalendar.Day = 2131755293;
        /* added by JADX */
        /* renamed from: Test.Widget.MaterialComponents.MaterialCalendar.Day.Selected */
        public static final int f282Test.Widget.MaterialComponents.MaterialCalendar.Day.Selected = 2131755294;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat */
        public static final int f283TextAppearance.AppCompat = 2131755301;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Body1 */
        public static final int f284TextAppearance.AppCompat.Body1 = 2131755302;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Body2 */
        public static final int f285TextAppearance.AppCompat.Body2 = 2131755303;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Button */
        public static final int f286TextAppearance.AppCompat.Button = 2131755304;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Caption */
        public static final int f287TextAppearance.AppCompat.Caption = 2131755305;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Display1 */
        public static final int f288TextAppearance.AppCompat.Display1 = 2131755306;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Display2 */
        public static final int f289TextAppearance.AppCompat.Display2 = 2131755307;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Display3 */
        public static final int f290TextAppearance.AppCompat.Display3 = 2131755308;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Display4 */
        public static final int f291TextAppearance.AppCompat.Display4 = 2131755309;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Headline */
        public static final int f292TextAppearance.AppCompat.Headline = 2131755310;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Inverse */
        public static final int f293TextAppearance.AppCompat.Inverse = 2131755311;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Large */
        public static final int f294TextAppearance.AppCompat.Large = 2131755312;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Large.Inverse */
        public static final int f295TextAppearance.AppCompat.Large.Inverse = 2131755313;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Light.SearchResult.Subtitle */
        public static final int f296TextAppearance.AppCompat.Light.SearchResult.Subtitle = 2131755314;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Light.SearchResult.Title */
        public static final int f297TextAppearance.AppCompat.Light.SearchResult.Title = 2131755315;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Light.Widget.PopupMenu.Large */
        public static final int f298TextAppearance.AppCompat.Light.Widget.PopupMenu.Large = 2131755316;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Light.Widget.PopupMenu.Small */
        public static final int f299TextAppearance.AppCompat.Light.Widget.PopupMenu.Small = 2131755317;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Medium */
        public static final int f300TextAppearance.AppCompat.Medium = 2131755318;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Medium.Inverse */
        public static final int f301TextAppearance.AppCompat.Medium.Inverse = 2131755319;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Menu */
        public static final int f302TextAppearance.AppCompat.Menu = 2131755320;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.SearchResult.Subtitle */
        public static final int f303TextAppearance.AppCompat.SearchResult.Subtitle = 2131755321;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.SearchResult.Title */
        public static final int f304TextAppearance.AppCompat.SearchResult.Title = 2131755322;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Small */
        public static final int f305TextAppearance.AppCompat.Small = 2131755323;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Small.Inverse */
        public static final int f306TextAppearance.AppCompat.Small.Inverse = 2131755324;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Subhead */
        public static final int f307TextAppearance.AppCompat.Subhead = 2131755325;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Subhead.Inverse */
        public static final int f308TextAppearance.AppCompat.Subhead.Inverse = 2131755326;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Title */
        public static final int f309TextAppearance.AppCompat.Title = 2131755327;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Title.Inverse */
        public static final int f310TextAppearance.AppCompat.Title.Inverse = 2131755328;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Tooltip */
        public static final int f311TextAppearance.AppCompat.Tooltip = 2131755329;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Menu */
        public static final int f312TextAppearance.AppCompat.Widget.ActionBar.Menu = 2131755330;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Subtitle */
        public static final int f313TextAppearance.AppCompat.Widget.ActionBar.Subtitle = 2131755331;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse */
        public static final int f314TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse = 2131755332;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Title */
        public static final int f315TextAppearance.AppCompat.Widget.ActionBar.Title = 2131755333;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse */
        public static final int f316TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse = 2131755334;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Subtitle */
        public static final int f317TextAppearance.AppCompat.Widget.ActionMode.Subtitle = 2131755335;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Subtitle.Inverse */
        public static final int f318TextAppearance.AppCompat.Widget.ActionMode.Subtitle.Inverse = 2131755336;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Title */
        public static final int f319TextAppearance.AppCompat.Widget.ActionMode.Title = 2131755337;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Title.Inverse */
        public static final int f320TextAppearance.AppCompat.Widget.ActionMode.Title.Inverse = 2131755338;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.Button */
        public static final int f321TextAppearance.AppCompat.Widget.Button = 2131755339;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.Button.Borderless.Colored */
        public static final int f322TextAppearance.AppCompat.Widget.Button.Borderless.Colored = 2131755340;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.Button.Colored */
        public static final int f323TextAppearance.AppCompat.Widget.Button.Colored = 2131755341;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.Button.Inverse */
        public static final int f324TextAppearance.AppCompat.Widget.Button.Inverse = 2131755342;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.DropDownItem */
        public static final int f325TextAppearance.AppCompat.Widget.DropDownItem = 2131755343;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.PopupMenu.Header */
        public static final int f326TextAppearance.AppCompat.Widget.PopupMenu.Header = 2131755344;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.PopupMenu.Large */
        public static final int f327TextAppearance.AppCompat.Widget.PopupMenu.Large = 2131755345;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.PopupMenu.Small */
        public static final int f328TextAppearance.AppCompat.Widget.PopupMenu.Small = 2131755346;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.Switch */
        public static final int f329TextAppearance.AppCompat.Widget.Switch = 2131755347;
        /* added by JADX */
        /* renamed from: TextAppearance.AppCompat.Widget.TextView.SpinnerItem */
        public static final int f330TextAppearance.AppCompat.Widget.TextView.SpinnerItem = 2131755348;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification */
        public static final int f331TextAppearance.Compat.Notification = 2131755349;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Info */
        public static final int f332TextAppearance.Compat.Notification.Info = 2131755350;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Info.Media */
        public static final int f333TextAppearance.Compat.Notification.Info.Media = 2131755351;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Line2 */
        public static final int f334TextAppearance.Compat.Notification.Line2 = 2131755352;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Line2.Media */
        public static final int f335TextAppearance.Compat.Notification.Line2.Media = 2131755353;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Media */
        public static final int f336TextAppearance.Compat.Notification.Media = 2131755354;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Time */
        public static final int f337TextAppearance.Compat.Notification.Time = 2131755355;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Time.Media */
        public static final int f338TextAppearance.Compat.Notification.Time.Media = 2131755356;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Title */
        public static final int f339TextAppearance.Compat.Notification.Title = 2131755357;
        /* added by JADX */
        /* renamed from: TextAppearance.Compat.Notification.Title.Media */
        public static final int f340TextAppearance.Compat.Notification.Title.Media = 2131755358;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.CollapsingToolbar.Expanded */
        public static final int f341TextAppearance.Design.CollapsingToolbar.Expanded = 2131755359;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.Counter */
        public static final int f342TextAppearance.Design.Counter = 2131755360;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.Counter.Overflow */
        public static final int f343TextAppearance.Design.Counter.Overflow = 2131755361;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.Error */
        public static final int f344TextAppearance.Design.Error = 2131755362;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.HelperText */
        public static final int f345TextAppearance.Design.HelperText = 2131755363;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.Hint */
        public static final int f346TextAppearance.Design.Hint = 2131755364;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.Snackbar.Message */
        public static final int f347TextAppearance.Design.Snackbar.Message = 2131755365;
        /* added by JADX */
        /* renamed from: TextAppearance.Design.Tab */
        public static final int f348TextAppearance.Design.Tab = 2131755366;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Badge */
        public static final int f349TextAppearance.MaterialComponents.Badge = 2131755367;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Body1 */
        public static final int f350TextAppearance.MaterialComponents.Body1 = 2131755368;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Body2 */
        public static final int f351TextAppearance.MaterialComponents.Body2 = 2131755369;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Button */
        public static final int f352TextAppearance.MaterialComponents.Button = 2131755370;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Caption */
        public static final int f353TextAppearance.MaterialComponents.Caption = 2131755371;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Chip */
        public static final int f354TextAppearance.MaterialComponents.Chip = 2131755372;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Headline1 */
        public static final int f355TextAppearance.MaterialComponents.Headline1 = 2131755373;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Headline2 */
        public static final int f356TextAppearance.MaterialComponents.Headline2 = 2131755374;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Headline3 */
        public static final int f357TextAppearance.MaterialComponents.Headline3 = 2131755375;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Headline4 */
        public static final int f358TextAppearance.MaterialComponents.Headline4 = 2131755376;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Headline5 */
        public static final int f359TextAppearance.MaterialComponents.Headline5 = 2131755377;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Headline6 */
        public static final int f360TextAppearance.MaterialComponents.Headline6 = 2131755378;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Overline */
        public static final int f361TextAppearance.MaterialComponents.Overline = 2131755379;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Subtitle1 */
        public static final int f362TextAppearance.MaterialComponents.Subtitle1 = 2131755380;
        /* added by JADX */
        /* renamed from: TextAppearance.MaterialComponents.Subtitle2 */
        public static final int f363TextAppearance.MaterialComponents.Subtitle2 = 2131755381;
        /* added by JADX */
        /* renamed from: TextAppearance.Widget.AppCompat.ExpandedMenu.Item */
        public static final int f364TextAppearance.Widget.AppCompat.ExpandedMenu.Item = 2131755382;
        /* added by JADX */
        /* renamed from: TextAppearance.Widget.AppCompat.Toolbar.Subtitle */
        public static final int f365TextAppearance.Widget.AppCompat.Toolbar.Subtitle = 2131755383;
        /* added by JADX */
        /* renamed from: TextAppearance.Widget.AppCompat.Toolbar.Title */
        public static final int f366TextAppearance.Widget.AppCompat.Toolbar.Title = 2131755384;
        /* added by JADX */
        /* renamed from: Theme.AppCompat */
        public static final int f367Theme.AppCompat = 2131755385;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.CompactMenu */
        public static final int f368Theme.AppCompat.CompactMenu = 2131755386;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight */
        public static final int f369Theme.AppCompat.DayNight = 2131755387;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight.DarkActionBar */
        public static final int f370Theme.AppCompat.DayNight.DarkActionBar = 2131755388;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight.Dialog */
        public static final int f371Theme.AppCompat.DayNight.Dialog = 2131755389;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight.Dialog.Alert */
        public static final int f372Theme.AppCompat.DayNight.Dialog.Alert = 2131755390;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight.Dialog.MinWidth */
        public static final int f373Theme.AppCompat.DayNight.Dialog.MinWidth = 2131755391;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight.DialogWhenLarge */
        public static final int f374Theme.AppCompat.DayNight.DialogWhenLarge = 2131755392;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DayNight.NoActionBar */
        public static final int f375Theme.AppCompat.DayNight.NoActionBar = 2131755393;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Dialog */
        public static final int f376Theme.AppCompat.Dialog = 2131755394;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Dialog.Alert */
        public static final int f377Theme.AppCompat.Dialog.Alert = 2131755395;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Dialog.MinWidth */
        public static final int f378Theme.AppCompat.Dialog.MinWidth = 2131755396;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.DialogWhenLarge */
        public static final int f379Theme.AppCompat.DialogWhenLarge = 2131755397;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light */
        public static final int f380Theme.AppCompat.Light = 2131755398;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light.DarkActionBar */
        public static final int f381Theme.AppCompat.Light.DarkActionBar = 2131755399;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light.Dialog */
        public static final int f382Theme.AppCompat.Light.Dialog = 2131755400;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light.Dialog.Alert */
        public static final int f383Theme.AppCompat.Light.Dialog.Alert = 2131755401;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light.Dialog.MinWidth */
        public static final int f384Theme.AppCompat.Light.Dialog.MinWidth = 2131755402;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light.DialogWhenLarge */
        public static final int f385Theme.AppCompat.Light.DialogWhenLarge = 2131755403;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.Light.NoActionBar */
        public static final int f386Theme.AppCompat.Light.NoActionBar = 2131755404;
        /* added by JADX */
        /* renamed from: Theme.AppCompat.NoActionBar */
        public static final int f387Theme.AppCompat.NoActionBar = 2131755405;
        /* added by JADX */
        /* renamed from: Theme.Design */
        public static final int f388Theme.Design = 2131755406;
        /* added by JADX */
        /* renamed from: Theme.Design.BottomSheetDialog */
        public static final int f389Theme.Design.BottomSheetDialog = 2131755407;
        /* added by JADX */
        /* renamed from: Theme.Design.Light */
        public static final int f390Theme.Design.Light = 2131755408;
        /* added by JADX */
        /* renamed from: Theme.Design.Light.BottomSheetDialog */
        public static final int f391Theme.Design.Light.BottomSheetDialog = 2131755409;
        /* added by JADX */
        /* renamed from: Theme.Design.Light.NoActionBar */
        public static final int f392Theme.Design.Light.NoActionBar = 2131755410;
        /* added by JADX */
        /* renamed from: Theme.Design.NoActionBar */
        public static final int f393Theme.Design.NoActionBar = 2131755411;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents */
        public static final int f394Theme.MaterialComponents = 2131755412;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.BottomSheetDialog */
        public static final int f395Theme.MaterialComponents.BottomSheetDialog = 2131755413;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Bridge */
        public static final int f396Theme.MaterialComponents.Bridge = 2131755414;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.CompactMenu */
        public static final int f397Theme.MaterialComponents.CompactMenu = 2131755415;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight */
        public static final int f398Theme.MaterialComponents.DayNight = 2131755416;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.BottomSheetDialog */
        public static final int f399Theme.MaterialComponents.DayNight.BottomSheetDialog = 2131755417;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Bridge */
        public static final int f400Theme.MaterialComponents.DayNight.Bridge = 2131755418;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.DarkActionBar */
        public static final int f401Theme.MaterialComponents.DayNight.DarkActionBar = 2131755419;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.DarkActionBar.Bridge */
        public static final int f402Theme.MaterialComponents.DayNight.DarkActionBar.Bridge = 2131755420;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog */
        public static final int f403Theme.MaterialComponents.DayNight.Dialog = 2131755421;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.Alert */
        public static final int f404Theme.MaterialComponents.DayNight.Dialog.Alert = 2131755422;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.Alert.Bridge */
        public static final int f405Theme.MaterialComponents.DayNight.Dialog.Alert.Bridge = 2131755423;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.Bridge */
        public static final int f406Theme.MaterialComponents.DayNight.Dialog.Bridge = 2131755424;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.FixedSize */
        public static final int f407Theme.MaterialComponents.DayNight.Dialog.FixedSize = 2131755425;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.FixedSize.Bridge */
        public static final int f408Theme.MaterialComponents.DayNight.Dialog.FixedSize.Bridge = 2131755426;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.MinWidth */
        public static final int f409Theme.MaterialComponents.DayNight.Dialog.MinWidth = 2131755427;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.MinWidth.Bridge */
        public static final int f410Theme.MaterialComponents.DayNight.Dialog.MinWidth.Bridge = 2131755428;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.DialogWhenLarge */
        public static final int f411Theme.MaterialComponents.DayNight.DialogWhenLarge = 2131755429;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.NoActionBar */
        public static final int f412Theme.MaterialComponents.DayNight.NoActionBar = 2131755430;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DayNight.NoActionBar.Bridge */
        public static final int f413Theme.MaterialComponents.DayNight.NoActionBar.Bridge = 2131755431;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog */
        public static final int f414Theme.MaterialComponents.Dialog = 2131755432;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.Alert */
        public static final int f415Theme.MaterialComponents.Dialog.Alert = 2131755433;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.Alert.Bridge */
        public static final int f416Theme.MaterialComponents.Dialog.Alert.Bridge = 2131755434;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.Bridge */
        public static final int f417Theme.MaterialComponents.Dialog.Bridge = 2131755435;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.FixedSize */
        public static final int f418Theme.MaterialComponents.Dialog.FixedSize = 2131755436;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.FixedSize.Bridge */
        public static final int f419Theme.MaterialComponents.Dialog.FixedSize.Bridge = 2131755437;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.MinWidth */
        public static final int f420Theme.MaterialComponents.Dialog.MinWidth = 2131755438;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Dialog.MinWidth.Bridge */
        public static final int f421Theme.MaterialComponents.Dialog.MinWidth.Bridge = 2131755439;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.DialogWhenLarge */
        public static final int f422Theme.MaterialComponents.DialogWhenLarge = 2131755440;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light */
        public static final int f423Theme.MaterialComponents.Light = 2131755441;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.BarSize */
        public static final int f424Theme.MaterialComponents.Light.BarSize = 2131755442;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.BottomSheetDialog */
        public static final int f425Theme.MaterialComponents.Light.BottomSheetDialog = 2131755443;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Bridge */
        public static final int f426Theme.MaterialComponents.Light.Bridge = 2131755444;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.DarkActionBar */
        public static final int f427Theme.MaterialComponents.Light.DarkActionBar = 2131755445;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.DarkActionBar.Bridge */
        public static final int f428Theme.MaterialComponents.Light.DarkActionBar.Bridge = 2131755446;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog */
        public static final int f429Theme.MaterialComponents.Light.Dialog = 2131755447;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.Alert */
        public static final int f430Theme.MaterialComponents.Light.Dialog.Alert = 2131755448;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.Alert.Bridge */
        public static final int f431Theme.MaterialComponents.Light.Dialog.Alert.Bridge = 2131755449;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.Bridge */
        public static final int f432Theme.MaterialComponents.Light.Dialog.Bridge = 2131755450;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.FixedSize */
        public static final int f433Theme.MaterialComponents.Light.Dialog.FixedSize = 2131755451;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.FixedSize.Bridge */
        public static final int f434Theme.MaterialComponents.Light.Dialog.FixedSize.Bridge = 2131755452;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.MinWidth */
        public static final int f435Theme.MaterialComponents.Light.Dialog.MinWidth = 2131755453;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.MinWidth.Bridge */
        public static final int f436Theme.MaterialComponents.Light.Dialog.MinWidth.Bridge = 2131755454;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.DialogWhenLarge */
        public static final int f437Theme.MaterialComponents.Light.DialogWhenLarge = 2131755455;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.LargeTouch */
        public static final int f438Theme.MaterialComponents.Light.LargeTouch = 2131755456;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.NoActionBar */
        public static final int f439Theme.MaterialComponents.Light.NoActionBar = 2131755457;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.Light.NoActionBar.Bridge */
        public static final int f440Theme.MaterialComponents.Light.NoActionBar.Bridge = 2131755458;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.NoActionBar */
        public static final int f441Theme.MaterialComponents.NoActionBar = 2131755459;
        /* added by JADX */
        /* renamed from: Theme.MaterialComponents.NoActionBar.Bridge */
        public static final int f442Theme.MaterialComponents.NoActionBar.Bridge = 2131755460;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat */
        public static final int f443ThemeOverlay.AppCompat = 2131755461;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.ActionBar */
        public static final int f444ThemeOverlay.AppCompat.ActionBar = 2131755462;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.Dark */
        public static final int f445ThemeOverlay.AppCompat.Dark = 2131755463;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.Dark.ActionBar */
        public static final int f446ThemeOverlay.AppCompat.Dark.ActionBar = 2131755464;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.DayNight */
        public static final int f447ThemeOverlay.AppCompat.DayNight = 2131755465;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.DayNight.ActionBar */
        public static final int f448ThemeOverlay.AppCompat.DayNight.ActionBar = 2131755466;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.Dialog */
        public static final int f449ThemeOverlay.AppCompat.Dialog = 2131755467;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.Dialog.Alert */
        public static final int f450ThemeOverlay.AppCompat.Dialog.Alert = 2131755468;
        /* added by JADX */
        /* renamed from: ThemeOverlay.AppCompat.Light */
        public static final int f451ThemeOverlay.AppCompat.Light = 2131755469;
        /* added by JADX */
        /* renamed from: ThemeOverlay.Design.TextInputEditText */
        public static final int f452ThemeOverlay.Design.TextInputEditText = 2131755470;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents */
        public static final int f453ThemeOverlay.MaterialComponents = 2131755471;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.ActionBar */
        public static final int f454ThemeOverlay.MaterialComponents.ActionBar = 2131755472;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.ActionBar.Primary */
        public static final int f455ThemeOverlay.MaterialComponents.ActionBar.Primary = 2131755473;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.ActionBar.Surface */
        public static final int f456ThemeOverlay.MaterialComponents.ActionBar.Surface = 2131755474;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView */
        public static final int f457ThemeOverlay.MaterialComponents.AutoCompleteTextView = 2131755475;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox */
        public static final int f458ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox = 2131755476;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox.Dense */
        public static final int f459xb2869690 = 2131755477;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox */
        public static final int f460ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox = 2131755478;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense */
        public static final int f461xbe4f4e10 = 2131755479;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.BottomAppBar.Primary */
        public static final int f462ThemeOverlay.MaterialComponents.BottomAppBar.Primary = 2131755480;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.BottomAppBar.Surface */
        public static final int f463ThemeOverlay.MaterialComponents.BottomAppBar.Surface = 2131755481;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.BottomSheetDialog */
        public static final int f464ThemeOverlay.MaterialComponents.BottomSheetDialog = 2131755482;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Dark */
        public static final int f465ThemeOverlay.MaterialComponents.Dark = 2131755483;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Dark.ActionBar */
        public static final int f466ThemeOverlay.MaterialComponents.Dark.ActionBar = 2131755484;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.DayNight.BottomSheetDialog */
        public static final int f467ThemeOverlay.MaterialComponents.DayNight.BottomSheetDialog = 2131755485;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Dialog */
        public static final int f468ThemeOverlay.MaterialComponents.Dialog = 2131755486;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Dialog.Alert */
        public static final int f469ThemeOverlay.MaterialComponents.Dialog.Alert = 2131755487;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Light */
        public static final int f470ThemeOverlay.MaterialComponents.Light = 2131755488;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Light.BottomSheetDialog */
        public static final int f471ThemeOverlay.MaterialComponents.Light.BottomSheetDialog = 2131755489;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog */
        public static final int f472ThemeOverlay.MaterialComponents.MaterialAlertDialog = 2131755490;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Centered */
        public static final int f473ThemeOverlay.MaterialComponents.MaterialAlertDialog.Centered = 2131755491;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date */
        public static final int f474ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date = 2131755492;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Calendar */
        public static final int f475x71501b99 = 2131755493;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Header.Text */
        public static final int f476x84f7ddd3 = 2131755494;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Header.Text.Day */
        public static final int f477x6774b0e1 = 2131755495;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Spinner */
        public static final int f478xbe129a5e = 2131755496;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialCalendar */
        public static final int f479ThemeOverlay.MaterialComponents.MaterialCalendar = 2131755497;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialCalendar.Fullscreen */
        public static final int f480ThemeOverlay.MaterialComponents.MaterialCalendar.Fullscreen = 2131755498;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText */
        public static final int f481ThemeOverlay.MaterialComponents.TextInputEditText = 2131755499;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox */
        public static final int f482ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox = 2131755500;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox.Dense */
        public static final int f483x786ef2f6 = 2131755501;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox */
        public static final int f484ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox = 2131755502;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox.Dense */
        public static final int f485xab9228f6 = 2131755503;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Toolbar.Primary */
        public static final int f486ThemeOverlay.MaterialComponents.Toolbar.Primary = 2131755504;
        /* added by JADX */
        /* renamed from: ThemeOverlay.MaterialComponents.Toolbar.Surface */
        public static final int f487ThemeOverlay.MaterialComponents.Toolbar.Surface = 2131755505;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionBar */
        public static final int f488Widget.AppCompat.ActionBar = 2131755506;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionBar.Solid */
        public static final int f489Widget.AppCompat.ActionBar.Solid = 2131755507;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionBar.TabBar */
        public static final int f490Widget.AppCompat.ActionBar.TabBar = 2131755508;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionBar.TabText */
        public static final int f491Widget.AppCompat.ActionBar.TabText = 2131755509;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionBar.TabView */
        public static final int f492Widget.AppCompat.ActionBar.TabView = 2131755510;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionButton */
        public static final int f493Widget.AppCompat.ActionButton = 2131755511;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionButton.CloseMode */
        public static final int f494Widget.AppCompat.ActionButton.CloseMode = 2131755512;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionButton.Overflow */
        public static final int f495Widget.AppCompat.ActionButton.Overflow = 2131755513;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActionMode */
        public static final int f496Widget.AppCompat.ActionMode = 2131755514;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ActivityChooserView */
        public static final int f497Widget.AppCompat.ActivityChooserView = 2131755515;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.AutoCompleteTextView */
        public static final int f498Widget.AppCompat.AutoCompleteTextView = 2131755516;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Button */
        public static final int f499Widget.AppCompat.Button = 2131755517;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Button.Borderless */
        public static final int f500Widget.AppCompat.Button.Borderless = 2131755518;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Button.Borderless.Colored */
        public static final int f501Widget.AppCompat.Button.Borderless.Colored = 2131755519;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Button.ButtonBar.AlertDialog */
        public static final int f502Widget.AppCompat.Button.ButtonBar.AlertDialog = 2131755520;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Button.Colored */
        public static final int f503Widget.AppCompat.Button.Colored = 2131755521;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Button.Small */
        public static final int f504Widget.AppCompat.Button.Small = 2131755522;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ButtonBar */
        public static final int f505Widget.AppCompat.ButtonBar = 2131755523;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ButtonBar.AlertDialog */
        public static final int f506Widget.AppCompat.ButtonBar.AlertDialog = 2131755524;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.CompoundButton.CheckBox */
        public static final int f507Widget.AppCompat.CompoundButton.CheckBox = 2131755525;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.CompoundButton.RadioButton */
        public static final int f508Widget.AppCompat.CompoundButton.RadioButton = 2131755526;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.CompoundButton.Switch */
        public static final int f509Widget.AppCompat.CompoundButton.Switch = 2131755527;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.DrawerArrowToggle */
        public static final int f510Widget.AppCompat.DrawerArrowToggle = 2131755528;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.DropDownItem.Spinner */
        public static final int f511Widget.AppCompat.DropDownItem.Spinner = 2131755529;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.EditText */
        public static final int f512Widget.AppCompat.EditText = 2131755530;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ImageButton */
        public static final int f513Widget.AppCompat.ImageButton = 2131755531;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar */
        public static final int f514Widget.AppCompat.Light.ActionBar = 2131755532;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.Solid */
        public static final int f515Widget.AppCompat.Light.ActionBar.Solid = 2131755533;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.Solid.Inverse */
        public static final int f516Widget.AppCompat.Light.ActionBar.Solid.Inverse = 2131755534;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabBar */
        public static final int f517Widget.AppCompat.Light.ActionBar.TabBar = 2131755535;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabBar.Inverse */
        public static final int f518Widget.AppCompat.Light.ActionBar.TabBar.Inverse = 2131755536;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabText */
        public static final int f519Widget.AppCompat.Light.ActionBar.TabText = 2131755537;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabText.Inverse */
        public static final int f520Widget.AppCompat.Light.ActionBar.TabText.Inverse = 2131755538;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabView */
        public static final int f521Widget.AppCompat.Light.ActionBar.TabView = 2131755539;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabView.Inverse */
        public static final int f522Widget.AppCompat.Light.ActionBar.TabView.Inverse = 2131755540;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionButton */
        public static final int f523Widget.AppCompat.Light.ActionButton = 2131755541;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionButton.CloseMode */
        public static final int f524Widget.AppCompat.Light.ActionButton.CloseMode = 2131755542;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionButton.Overflow */
        public static final int f525Widget.AppCompat.Light.ActionButton.Overflow = 2131755543;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActionMode.Inverse */
        public static final int f526Widget.AppCompat.Light.ActionMode.Inverse = 2131755544;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ActivityChooserView */
        public static final int f527Widget.AppCompat.Light.ActivityChooserView = 2131755545;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.AutoCompleteTextView */
        public static final int f528Widget.AppCompat.Light.AutoCompleteTextView = 2131755546;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.DropDownItem.Spinner */
        public static final int f529Widget.AppCompat.Light.DropDownItem.Spinner = 2131755547;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ListPopupWindow */
        public static final int f530Widget.AppCompat.Light.ListPopupWindow = 2131755548;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.ListView.DropDown */
        public static final int f531Widget.AppCompat.Light.ListView.DropDown = 2131755549;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.PopupMenu */
        public static final int f532Widget.AppCompat.Light.PopupMenu = 2131755550;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.PopupMenu.Overflow */
        public static final int f533Widget.AppCompat.Light.PopupMenu.Overflow = 2131755551;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.SearchView */
        public static final int f534Widget.AppCompat.Light.SearchView = 2131755552;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Light.Spinner.DropDown.ActionBar */
        public static final int f535Widget.AppCompat.Light.Spinner.DropDown.ActionBar = 2131755553;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ListMenuView */
        public static final int f536Widget.AppCompat.ListMenuView = 2131755554;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ListPopupWindow */
        public static final int f537Widget.AppCompat.ListPopupWindow = 2131755555;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ListView */
        public static final int f538Widget.AppCompat.ListView = 2131755556;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ListView.DropDown */
        public static final int f539Widget.AppCompat.ListView.DropDown = 2131755557;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ListView.Menu */
        public static final int f540Widget.AppCompat.ListView.Menu = 2131755558;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.PopupMenu */
        public static final int f541Widget.AppCompat.PopupMenu = 2131755559;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.PopupMenu.Overflow */
        public static final int f542Widget.AppCompat.PopupMenu.Overflow = 2131755560;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.PopupWindow */
        public static final int f543Widget.AppCompat.PopupWindow = 2131755561;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ProgressBar */
        public static final int f544Widget.AppCompat.ProgressBar = 2131755562;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.ProgressBar.Horizontal */
        public static final int f545Widget.AppCompat.ProgressBar.Horizontal = 2131755563;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.RatingBar */
        public static final int f546Widget.AppCompat.RatingBar = 2131755564;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.RatingBar.Indicator */
        public static final int f547Widget.AppCompat.RatingBar.Indicator = 2131755565;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.RatingBar.Small */
        public static final int f548Widget.AppCompat.RatingBar.Small = 2131755566;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.SearchView */
        public static final int f549Widget.AppCompat.SearchView = 2131755567;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.SearchView.ActionBar */
        public static final int f550Widget.AppCompat.SearchView.ActionBar = 2131755568;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.SeekBar */
        public static final int f551Widget.AppCompat.SeekBar = 2131755569;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.SeekBar.Discrete */
        public static final int f552Widget.AppCompat.SeekBar.Discrete = 2131755570;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Spinner */
        public static final int f553Widget.AppCompat.Spinner = 2131755571;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Spinner.DropDown */
        public static final int f554Widget.AppCompat.Spinner.DropDown = 2131755572;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Spinner.DropDown.ActionBar */
        public static final int f555Widget.AppCompat.Spinner.DropDown.ActionBar = 2131755573;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Spinner.Underlined */
        public static final int f556Widget.AppCompat.Spinner.Underlined = 2131755574;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.TextView */
        public static final int f557Widget.AppCompat.TextView = 2131755575;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.TextView.SpinnerItem */
        public static final int f558Widget.AppCompat.TextView.SpinnerItem = 2131755576;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Toolbar */
        public static final int f559Widget.AppCompat.Toolbar = 2131755577;
        /* added by JADX */
        /* renamed from: Widget.AppCompat.Toolbar.Button.Navigation */
        public static final int f560Widget.AppCompat.Toolbar.Button.Navigation = 2131755578;
        /* added by JADX */
        /* renamed from: Widget.Compat.NotificationActionContainer */
        public static final int f561Widget.Compat.NotificationActionContainer = 2131755579;
        /* added by JADX */
        /* renamed from: Widget.Compat.NotificationActionText */
        public static final int f562Widget.Compat.NotificationActionText = 2131755580;
        /* added by JADX */
        /* renamed from: Widget.Design.AppBarLayout */
        public static final int f563Widget.Design.AppBarLayout = 2131755581;
        /* added by JADX */
        /* renamed from: Widget.Design.BottomNavigationView */
        public static final int f564Widget.Design.BottomNavigationView = 2131755582;
        /* added by JADX */
        /* renamed from: Widget.Design.BottomSheet.Modal */
        public static final int f565Widget.Design.BottomSheet.Modal = 2131755583;
        /* added by JADX */
        /* renamed from: Widget.Design.CollapsingToolbar */
        public static final int f566Widget.Design.CollapsingToolbar = 2131755584;
        /* added by JADX */
        /* renamed from: Widget.Design.FloatingActionButton */
        public static final int f567Widget.Design.FloatingActionButton = 2131755585;
        /* added by JADX */
        /* renamed from: Widget.Design.NavigationView */
        public static final int f568Widget.Design.NavigationView = 2131755586;
        /* added by JADX */
        /* renamed from: Widget.Design.ScrimInsetsFrameLayout */
        public static final int f569Widget.Design.ScrimInsetsFrameLayout = 2131755587;
        /* added by JADX */
        /* renamed from: Widget.Design.Snackbar */
        public static final int f570Widget.Design.Snackbar = 2131755588;
        /* added by JADX */
        /* renamed from: Widget.Design.TabLayout */
        public static final int f571Widget.Design.TabLayout = 2131755589;
        /* added by JADX */
        /* renamed from: Widget.Design.TextInputLayout */
        public static final int f572Widget.Design.TextInputLayout = 2131755590;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ActionBar.Primary */
        public static final int f573Widget.MaterialComponents.ActionBar.Primary = 2131755591;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ActionBar.PrimarySurface */
        public static final int f574Widget.MaterialComponents.ActionBar.PrimarySurface = 2131755592;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ActionBar.Solid */
        public static final int f575Widget.MaterialComponents.ActionBar.Solid = 2131755593;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ActionBar.Surface */
        public static final int f576Widget.MaterialComponents.ActionBar.Surface = 2131755594;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AppBarLayout.Primary */
        public static final int f577Widget.MaterialComponents.AppBarLayout.Primary = 2131755595;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AppBarLayout.PrimarySurface */
        public static final int f578Widget.MaterialComponents.AppBarLayout.PrimarySurface = 2131755596;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AppBarLayout.Surface */
        public static final int f579Widget.MaterialComponents.AppBarLayout.Surface = 2131755597;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.FilledBox */
        public static final int f580Widget.MaterialComponents.AutoCompleteTextView.FilledBox = 2131755598;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.FilledBox.Dense */
        public static final int f581Widget.MaterialComponents.AutoCompleteTextView.FilledBox.Dense = 2131755599;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox */
        public static final int f582Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox = 2131755600;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense */
        public static final int f583Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense = 2131755601;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Badge */
        public static final int f584Widget.MaterialComponents.Badge = 2131755602;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomAppBar */
        public static final int f585Widget.MaterialComponents.BottomAppBar = 2131755603;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomAppBar.Colored */
        public static final int f586Widget.MaterialComponents.BottomAppBar.Colored = 2131755604;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomAppBar.PrimarySurface */
        public static final int f587Widget.MaterialComponents.BottomAppBar.PrimarySurface = 2131755605;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomNavigationView */
        public static final int f588Widget.MaterialComponents.BottomNavigationView = 2131755606;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomNavigationView.Colored */
        public static final int f589Widget.MaterialComponents.BottomNavigationView.Colored = 2131755607;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomNavigationView.PrimarySurface */
        public static final int f590Widget.MaterialComponents.BottomNavigationView.PrimarySurface = 2131755608;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomSheet */
        public static final int f591Widget.MaterialComponents.BottomSheet = 2131755609;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.BottomSheet.Modal */
        public static final int f592Widget.MaterialComponents.BottomSheet.Modal = 2131755610;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button */
        public static final int f593Widget.MaterialComponents.Button = 2131755611;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.Icon */
        public static final int f594Widget.MaterialComponents.Button.Icon = 2131755612;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.OutlinedButton */
        public static final int f595Widget.MaterialComponents.Button.OutlinedButton = 2131755613;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.OutlinedButton.Icon */
        public static final int f596Widget.MaterialComponents.Button.OutlinedButton.Icon = 2131755614;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.TextButton */
        public static final int f597Widget.MaterialComponents.Button.TextButton = 2131755615;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Dialog */
        public static final int f598Widget.MaterialComponents.Button.TextButton.Dialog = 2131755616;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Dialog.Flush */
        public static final int f599Widget.MaterialComponents.Button.TextButton.Dialog.Flush = 2131755617;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Dialog.Icon */
        public static final int f600Widget.MaterialComponents.Button.TextButton.Dialog.Icon = 2131755618;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Icon */
        public static final int f601Widget.MaterialComponents.Button.TextButton.Icon = 2131755619;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Snackbar */
        public static final int f602Widget.MaterialComponents.Button.TextButton.Snackbar = 2131755620;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.UnelevatedButton */
        public static final int f603Widget.MaterialComponents.Button.UnelevatedButton = 2131755621;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Button.UnelevatedButton.Icon */
        public static final int f604Widget.MaterialComponents.Button.UnelevatedButton.Icon = 2131755622;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.CardView */
        public static final int f605Widget.MaterialComponents.CardView = 2131755623;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.CheckedTextView */
        public static final int f606Widget.MaterialComponents.CheckedTextView = 2131755624;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Chip.Action */
        public static final int f607Widget.MaterialComponents.Chip.Action = 2131755625;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Chip.Choice */
        public static final int f608Widget.MaterialComponents.Chip.Choice = 2131755626;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Chip.Entry */
        public static final int f609Widget.MaterialComponents.Chip.Entry = 2131755627;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Chip.Filter */
        public static final int f610Widget.MaterialComponents.Chip.Filter = 2131755628;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ChipGroup */
        public static final int f611Widget.MaterialComponents.ChipGroup = 2131755629;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.CompoundButton.CheckBox */
        public static final int f612Widget.MaterialComponents.CompoundButton.CheckBox = 2131755630;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.CompoundButton.RadioButton */
        public static final int f613Widget.MaterialComponents.CompoundButton.RadioButton = 2131755631;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.CompoundButton.Switch */
        public static final int f614Widget.MaterialComponents.CompoundButton.Switch = 2131755632;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ExtendedFloatingActionButton */
        public static final int f615Widget.MaterialComponents.ExtendedFloatingActionButton = 2131755633;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.ExtendedFloatingActionButton.Icon */
        public static final int f616Widget.MaterialComponents.ExtendedFloatingActionButton.Icon = 2131755634;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.FloatingActionButton */
        public static final int f617Widget.MaterialComponents.FloatingActionButton = 2131755635;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Light.ActionBar.Solid */
        public static final int f618Widget.MaterialComponents.Light.ActionBar.Solid = 2131755636;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialButtonToggleGroup */
        public static final int f619Widget.MaterialComponents.MaterialButtonToggleGroup = 2131755637;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar */
        public static final int f620Widget.MaterialComponents.MaterialCalendar = 2131755638;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day */
        public static final int f621Widget.MaterialComponents.MaterialCalendar.Day = 2131755639;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day.Invalid */
        public static final int f622Widget.MaterialComponents.MaterialCalendar.Day.Invalid = 2131755640;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day.Selected */
        public static final int f623Widget.MaterialComponents.MaterialCalendar.Day.Selected = 2131755641;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day.Today */
        public static final int f624Widget.MaterialComponents.MaterialCalendar.Day.Today = 2131755642;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.DayTextView */
        public static final int f625Widget.MaterialComponents.MaterialCalendar.DayTextView = 2131755643;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Fullscreen */
        public static final int f626Widget.MaterialComponents.MaterialCalendar.Fullscreen = 2131755644;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderConfirmButton */
        public static final int f627Widget.MaterialComponents.MaterialCalendar.HeaderConfirmButton = 2131755645;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderDivider */
        public static final int f628Widget.MaterialComponents.MaterialCalendar.HeaderDivider = 2131755646;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderLayout */
        public static final int f629Widget.MaterialComponents.MaterialCalendar.HeaderLayout = 2131755647;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderSelection */
        public static final int f630Widget.MaterialComponents.MaterialCalendar.HeaderSelection = 2131755648;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderSelection.Fullscreen */
        public static final int f631x11aeb5cc = 2131755649;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderTitle */
        public static final int f632Widget.MaterialComponents.MaterialCalendar.HeaderTitle = 2131755650;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderToggleButton */
        public static final int f633Widget.MaterialComponents.MaterialCalendar.HeaderToggleButton = 2131755651;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Item */
        public static final int f634Widget.MaterialComponents.MaterialCalendar.Item = 2131755652;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Year */
        public static final int f635Widget.MaterialComponents.MaterialCalendar.Year = 2131755653;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Year.Selected */
        public static final int f636Widget.MaterialComponents.MaterialCalendar.Year.Selected = 2131755654;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Year.Today */
        public static final int f637Widget.MaterialComponents.MaterialCalendar.Year.Today = 2131755655;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.NavigationView */
        public static final int f638Widget.MaterialComponents.NavigationView = 2131755656;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.PopupMenu */
        public static final int f639Widget.MaterialComponents.PopupMenu = 2131755657;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.PopupMenu.ContextMenu */
        public static final int f640Widget.MaterialComponents.PopupMenu.ContextMenu = 2131755658;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.PopupMenu.ListPopupWindow */
        public static final int f641Widget.MaterialComponents.PopupMenu.ListPopupWindow = 2131755659;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.PopupMenu.Overflow */
        public static final int f642Widget.MaterialComponents.PopupMenu.Overflow = 2131755660;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Snackbar */
        public static final int f643Widget.MaterialComponents.Snackbar = 2131755661;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Snackbar.FullWidth */
        public static final int f644Widget.MaterialComponents.Snackbar.FullWidth = 2131755662;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TabLayout */
        public static final int f645Widget.MaterialComponents.TabLayout = 2131755663;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TabLayout.Colored */
        public static final int f646Widget.MaterialComponents.TabLayout.Colored = 2131755664;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TabLayout.PrimarySurface */
        public static final int f647Widget.MaterialComponents.TabLayout.PrimarySurface = 2131755665;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.FilledBox */
        public static final int f648Widget.MaterialComponents.TextInputEditText.FilledBox = 2131755666;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.FilledBox.Dense */
        public static final int f649Widget.MaterialComponents.TextInputEditText.FilledBox.Dense = 2131755667;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.OutlinedBox */
        public static final int f650Widget.MaterialComponents.TextInputEditText.OutlinedBox = 2131755668;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.OutlinedBox.Dense */
        public static final int f651Widget.MaterialComponents.TextInputEditText.OutlinedBox.Dense = 2131755669;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox */
        public static final int f652Widget.MaterialComponents.TextInputLayout.FilledBox = 2131755670;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox.Dense */
        public static final int f653Widget.MaterialComponents.TextInputLayout.FilledBox.Dense = 2131755671;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox.Dense.ExposedDropdownMenu */
        public static final int f654x298774ae = 2131755672;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox.ExposedDropdownMenu */
        public static final int f655x4a2647dd = 2131755673;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox */
        public static final int f656Widget.MaterialComponents.TextInputLayout.OutlinedBox = 2131755674;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense */
        public static final int f657Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense = 2131755675;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense.ExposedDropdownMenu */
        public static final int f658x5a10252e = 2131755676;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox.ExposedDropdownMenu */
        public static final int f659xf91d585d = 2131755677;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.TextView */
        public static final int f660Widget.MaterialComponents.TextView = 2131755678;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Toolbar */
        public static final int f661Widget.MaterialComponents.Toolbar = 2131755679;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Toolbar.Primary */
        public static final int f662Widget.MaterialComponents.Toolbar.Primary = 2131755680;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Toolbar.PrimarySurface */
        public static final int f663Widget.MaterialComponents.Toolbar.PrimarySurface = 2131755681;
        /* added by JADX */
        /* renamed from: Widget.MaterialComponents.Toolbar.Surface */
        public static final int f664Widget.MaterialComponents.Toolbar.Surface = 2131755682;
        /* added by JADX */
        /* renamed from: Widget.Support.CoordinatorLayout */
        public static final int f665Widget.Support.CoordinatorLayout = 2131755683;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] ActionBar = new int[]{attr.background, attr.backgroundSplit, attr.backgroundStacked, attr.contentInsetEnd, attr.contentInsetEndWithActions, attr.contentInsetLeft, attr.contentInsetRight, attr.contentInsetStart, attr.contentInsetStartWithNavigation, attr.customNavigationLayout, attr.displayOptions, attr.divider, attr.elevation, attr.height, attr.hideOnContentScroll, attr.homeAsUpIndicator, attr.homeLayout, attr.icon, attr.indeterminateProgressStyle, attr.itemPadding, attr.logo, attr.navigationMode, attr.popupTheme, attr.progressBarPadding, attr.progressBarStyle, attr.subtitle, attr.subtitleTextStyle, attr.title, attr.titleTextStyle};
        public static final int[] ActionBarLayout = new int[]{16842931};
        public static final int ActionBarLayout_android_layout_gravity = 0;
        public static final int ActionBar_background = 0;
        public static final int ActionBar_backgroundSplit = 1;
        public static final int ActionBar_backgroundStacked = 2;
        public static final int ActionBar_contentInsetEnd = 3;
        public static final int ActionBar_contentInsetEndWithActions = 4;
        public static final int ActionBar_contentInsetLeft = 5;
        public static final int ActionBar_contentInsetRight = 6;
        public static final int ActionBar_contentInsetStart = 7;
        public static final int ActionBar_contentInsetStartWithNavigation = 8;
        public static final int ActionBar_customNavigationLayout = 9;
        public static final int ActionBar_displayOptions = 10;
        public static final int ActionBar_divider = 11;
        public static final int ActionBar_elevation = 12;
        public static final int ActionBar_height = 13;
        public static final int ActionBar_hideOnContentScroll = 14;
        public static final int ActionBar_homeAsUpIndicator = 15;
        public static final int ActionBar_homeLayout = 16;
        public static final int ActionBar_icon = 17;
        public static final int ActionBar_indeterminateProgressStyle = 18;
        public static final int ActionBar_itemPadding = 19;
        public static final int ActionBar_logo = 20;
        public static final int ActionBar_navigationMode = 21;
        public static final int ActionBar_popupTheme = 22;
        public static final int ActionBar_progressBarPadding = 23;
        public static final int ActionBar_progressBarStyle = 24;
        public static final int ActionBar_subtitle = 25;
        public static final int ActionBar_subtitleTextStyle = 26;
        public static final int ActionBar_title = 27;
        public static final int ActionBar_titleTextStyle = 28;
        public static final int[] ActionMenuItemView = new int[]{16843071};
        public static final int ActionMenuItemView_android_minWidth = 0;
        public static final int[] ActionMenuView = new int[0];
        public static final int[] ActionMode = new int[]{attr.background, attr.backgroundSplit, attr.closeItemLayout, attr.height, attr.subtitleTextStyle, attr.titleTextStyle};
        public static final int ActionMode_background = 0;
        public static final int ActionMode_backgroundSplit = 1;
        public static final int ActionMode_closeItemLayout = 2;
        public static final int ActionMode_height = 3;
        public static final int ActionMode_subtitleTextStyle = 4;
        public static final int ActionMode_titleTextStyle = 5;
        public static final int[] ActivityChooserView = new int[]{attr.expandActivityOverflowButtonDrawable, attr.initialActivityCount};
        public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
        public static final int ActivityChooserView_initialActivityCount = 1;
        public static final int[] AlertDialog = new int[]{16842994, attr.buttonIconDimen, attr.buttonPanelSideLayout, attr.listItemLayout, attr.listLayout, attr.multiChoiceItemLayout, attr.showTitle, attr.singleChoiceItemLayout};
        public static final int AlertDialog_android_layout = 0;
        public static final int AlertDialog_buttonIconDimen = 1;
        public static final int AlertDialog_buttonPanelSideLayout = 2;
        public static final int AlertDialog_listItemLayout = 3;
        public static final int AlertDialog_listLayout = 4;
        public static final int AlertDialog_multiChoiceItemLayout = 5;
        public static final int AlertDialog_showTitle = 6;
        public static final int AlertDialog_singleChoiceItemLayout = 7;
        public static final int[] AnimatedStateListDrawableCompat = new int[]{16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
        public static final int AnimatedStateListDrawableCompat_android_dither = 0;
        public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
        public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
        public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
        public static final int AnimatedStateListDrawableCompat_android_visible = 1;
        public static final int[] AnimatedStateListDrawableItem = new int[]{16842960, 16843161};
        public static final int AnimatedStateListDrawableItem_android_drawable = 1;
        public static final int AnimatedStateListDrawableItem_android_id = 0;
        public static final int[] AnimatedStateListDrawableTransition = new int[]{16843161, 16843849, 16843850, 16843851};
        public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
        public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
        public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
        public static final int AnimatedStateListDrawableTransition_android_toId = 1;
        public static final int[] AppBarLayout = new int[]{16842964, 16843919, 16844096, attr.elevation, attr.expanded, attr.liftOnScroll, attr.liftOnScrollTargetViewId, attr.statusBarForeground};
        public static final int[] AppBarLayoutStates = new int[]{attr.state_collapsed, attr.state_collapsible, attr.state_liftable, attr.state_lifted};
        public static final int AppBarLayoutStates_state_collapsed = 0;
        public static final int AppBarLayoutStates_state_collapsible = 1;
        public static final int AppBarLayoutStates_state_liftable = 2;
        public static final int AppBarLayoutStates_state_lifted = 3;
        public static final int[] AppBarLayout_Layout = new int[]{attr.layout_scrollFlags, attr.layout_scrollInterpolator};
        public static final int AppBarLayout_Layout_layout_scrollFlags = 0;
        public static final int AppBarLayout_Layout_layout_scrollInterpolator = 1;
        public static final int AppBarLayout_android_background = 0;
        public static final int AppBarLayout_android_keyboardNavigationCluster = 2;
        public static final int AppBarLayout_android_touchscreenBlocksFocus = 1;
        public static final int AppBarLayout_elevation = 3;
        public static final int AppBarLayout_expanded = 4;
        public static final int AppBarLayout_liftOnScroll = 5;
        public static final int AppBarLayout_liftOnScrollTargetViewId = 6;
        public static final int AppBarLayout_statusBarForeground = 7;
        public static final int[] AppCompatImageView = new int[]{16843033, attr.srcCompat, attr.tint, attr.tintMode};
        public static final int AppCompatImageView_android_src = 0;
        public static final int AppCompatImageView_srcCompat = 1;
        public static final int AppCompatImageView_tint = 2;
        public static final int AppCompatImageView_tintMode = 3;
        public static final int[] AppCompatSeekBar = new int[]{16843074, attr.tickMark, attr.tickMarkTint, attr.tickMarkTintMode};
        public static final int AppCompatSeekBar_android_thumb = 0;
        public static final int AppCompatSeekBar_tickMark = 1;
        public static final int AppCompatSeekBar_tickMarkTint = 2;
        public static final int AppCompatSeekBar_tickMarkTintMode = 3;
        public static final int[] AppCompatTextHelper = new int[]{16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667};
        public static final int AppCompatTextHelper_android_drawableBottom = 2;
        public static final int AppCompatTextHelper_android_drawableEnd = 6;
        public static final int AppCompatTextHelper_android_drawableLeft = 3;
        public static final int AppCompatTextHelper_android_drawableRight = 4;
        public static final int AppCompatTextHelper_android_drawableStart = 5;
        public static final int AppCompatTextHelper_android_drawableTop = 1;
        public static final int AppCompatTextHelper_android_textAppearance = 0;
        public static final int[] AppCompatTextView = new int[]{16842804, attr.autoSizeMaxTextSize, attr.autoSizeMinTextSize, attr.autoSizePresetSizes, attr.autoSizeStepGranularity, attr.autoSizeTextType, attr.drawableBottomCompat, attr.drawableEndCompat, attr.drawableLeftCompat, attr.drawableRightCompat, attr.drawableStartCompat, attr.drawableTint, attr.drawableTintMode, attr.drawableTopCompat, attr.firstBaselineToTopHeight, attr.fontFamily, attr.fontVariationSettings, attr.lastBaselineToBottomHeight, attr.lineHeight, attr.textAllCaps, attr.textLocale};
        public static final int AppCompatTextView_android_textAppearance = 0;
        public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
        public static final int AppCompatTextView_autoSizeMinTextSize = 2;
        public static final int AppCompatTextView_autoSizePresetSizes = 3;
        public static final int AppCompatTextView_autoSizeStepGranularity = 4;
        public static final int AppCompatTextView_autoSizeTextType = 5;
        public static final int AppCompatTextView_drawableBottomCompat = 6;
        public static final int AppCompatTextView_drawableEndCompat = 7;
        public static final int AppCompatTextView_drawableLeftCompat = 8;
        public static final int AppCompatTextView_drawableRightCompat = 9;
        public static final int AppCompatTextView_drawableStartCompat = 10;
        public static final int AppCompatTextView_drawableTint = 11;
        public static final int AppCompatTextView_drawableTintMode = 12;
        public static final int AppCompatTextView_drawableTopCompat = 13;
        public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
        public static final int AppCompatTextView_fontFamily = 15;
        public static final int AppCompatTextView_fontVariationSettings = 16;
        public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
        public static final int AppCompatTextView_lineHeight = 18;
        public static final int AppCompatTextView_textAllCaps = 19;
        public static final int AppCompatTextView_textLocale = 20;
        public static final int[] AppCompatTheme = new int[]{16842839, 16842926, attr.actionBarDivider, attr.actionBarItemBackground, attr.actionBarPopupTheme, attr.actionBarSize, attr.actionBarSplitStyle, attr.actionBarStyle, attr.actionBarTabBarStyle, attr.actionBarTabStyle, attr.actionBarTabTextStyle, attr.actionBarTheme, attr.actionBarWidgetTheme, attr.actionButtonStyle, attr.actionDropDownStyle, attr.actionMenuTextAppearance, attr.actionMenuTextColor, attr.actionModeBackground, attr.actionModeCloseButtonStyle, attr.actionModeCloseDrawable, attr.actionModeCopyDrawable, attr.actionModeCutDrawable, attr.actionModeFindDrawable, attr.actionModePasteDrawable, attr.actionModePopupWindowStyle, attr.actionModeSelectAllDrawable, attr.actionModeShareDrawable, attr.actionModeSplitBackground, attr.actionModeStyle, attr.actionModeWebSearchDrawable, attr.actionOverflowButtonStyle, attr.actionOverflowMenuStyle, attr.activityChooserViewStyle, attr.alertDialogButtonGroupStyle, attr.alertDialogCenterButtons, attr.alertDialogStyle, attr.alertDialogTheme, attr.autoCompleteTextViewStyle, attr.borderlessButtonStyle, attr.buttonBarButtonStyle, attr.buttonBarNegativeButtonStyle, attr.buttonBarNeutralButtonStyle, attr.buttonBarPositiveButtonStyle, attr.buttonBarStyle, attr.buttonStyle, attr.buttonStyleSmall, attr.checkboxStyle, attr.checkedTextViewStyle, attr.colorAccent, attr.colorBackgroundFloating, attr.colorButtonNormal, attr.colorControlActivated, attr.colorControlHighlight, attr.colorControlNormal, attr.colorError, attr.colorPrimary, attr.colorPrimaryDark, attr.colorSwitchThumbNormal, attr.controlBackground, attr.dialogCornerRadius, attr.dialogPreferredPadding, attr.dialogTheme, attr.dividerHorizontal, attr.dividerVertical, attr.dropDownListViewStyle, attr.dropdownListPreferredItemHeight, attr.editTextBackground, attr.editTextColor, attr.editTextStyle, attr.homeAsUpIndicator, attr.imageButtonStyle, attr.listChoiceBackgroundIndicator, attr.listChoiceIndicatorMultipleAnimated, attr.listChoiceIndicatorSingleAnimated, attr.listDividerAlertDialog, attr.listMenuViewStyle, attr.listPopupWindowStyle, attr.listPreferredItemHeight, attr.listPreferredItemHeightLarge, attr.listPreferredItemHeightSmall, attr.listPreferredItemPaddingEnd, attr.listPreferredItemPaddingLeft, attr.listPreferredItemPaddingRight, attr.listPreferredItemPaddingStart, attr.panelBackground, attr.panelMenuListTheme, attr.panelMenuListWidth, attr.popupMenuStyle, attr.popupWindowStyle, attr.radioButtonStyle, attr.ratingBarStyle, attr.ratingBarStyleIndicator, attr.ratingBarStyleSmall, attr.searchViewStyle, attr.seekBarStyle, attr.selectableItemBackground, attr.selectableItemBackgroundBorderless, attr.spinnerDropDownItemStyle, attr.spinnerStyle, attr.switchStyle, attr.textAppearanceLargePopupMenu, attr.textAppearanceListItem, attr.textAppearanceListItemSecondary, attr.textAppearanceListItemSmall, attr.textAppearancePopupMenuHeader, attr.textAppearanceSearchResultSubtitle, attr.textAppearanceSearchResultTitle, attr.textAppearanceSmallPopupMenu, attr.textColorAlertDialogListItem, attr.textColorSearchUrl, attr.toolbarNavigationButtonStyle, attr.toolbarStyle, attr.tooltipForegroundColor, attr.tooltipFrameBackground, attr.viewInflaterClass, attr.windowActionBar, attr.windowActionBarOverlay, attr.windowActionModeOverlay, attr.windowFixedHeightMajor, attr.windowFixedHeightMinor, attr.windowFixedWidthMajor, attr.windowFixedWidthMinor, attr.windowMinWidthMajor, attr.windowMinWidthMinor, attr.windowNoTitle};
        public static final int AppCompatTheme_actionBarDivider = 2;
        public static final int AppCompatTheme_actionBarItemBackground = 3;
        public static final int AppCompatTheme_actionBarPopupTheme = 4;
        public static final int AppCompatTheme_actionBarSize = 5;
        public static final int AppCompatTheme_actionBarSplitStyle = 6;
        public static final int AppCompatTheme_actionBarStyle = 7;
        public static final int AppCompatTheme_actionBarTabBarStyle = 8;
        public static final int AppCompatTheme_actionBarTabStyle = 9;
        public static final int AppCompatTheme_actionBarTabTextStyle = 10;
        public static final int AppCompatTheme_actionBarTheme = 11;
        public static final int AppCompatTheme_actionBarWidgetTheme = 12;
        public static final int AppCompatTheme_actionButtonStyle = 13;
        public static final int AppCompatTheme_actionDropDownStyle = 14;
        public static final int AppCompatTheme_actionMenuTextAppearance = 15;
        public static final int AppCompatTheme_actionMenuTextColor = 16;
        public static final int AppCompatTheme_actionModeBackground = 17;
        public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
        public static final int AppCompatTheme_actionModeCloseDrawable = 19;
        public static final int AppCompatTheme_actionModeCopyDrawable = 20;
        public static final int AppCompatTheme_actionModeCutDrawable = 21;
        public static final int AppCompatTheme_actionModeFindDrawable = 22;
        public static final int AppCompatTheme_actionModePasteDrawable = 23;
        public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
        public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
        public static final int AppCompatTheme_actionModeShareDrawable = 26;
        public static final int AppCompatTheme_actionModeSplitBackground = 27;
        public static final int AppCompatTheme_actionModeStyle = 28;
        public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
        public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
        public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
        public static final int AppCompatTheme_activityChooserViewStyle = 32;
        public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
        public static final int AppCompatTheme_alertDialogCenterButtons = 34;
        public static final int AppCompatTheme_alertDialogStyle = 35;
        public static final int AppCompatTheme_alertDialogTheme = 36;
        public static final int AppCompatTheme_android_windowAnimationStyle = 1;
        public static final int AppCompatTheme_android_windowIsFloating = 0;
        public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
        public static final int AppCompatTheme_borderlessButtonStyle = 38;
        public static final int AppCompatTheme_buttonBarButtonStyle = 39;
        public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
        public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
        public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
        public static final int AppCompatTheme_buttonBarStyle = 43;
        public static final int AppCompatTheme_buttonStyle = 44;
        public static final int AppCompatTheme_buttonStyleSmall = 45;
        public static final int AppCompatTheme_checkboxStyle = 46;
        public static final int AppCompatTheme_checkedTextViewStyle = 47;
        public static final int AppCompatTheme_colorAccent = 48;
        public static final int AppCompatTheme_colorBackgroundFloating = 49;
        public static final int AppCompatTheme_colorButtonNormal = 50;
        public static final int AppCompatTheme_colorControlActivated = 51;
        public static final int AppCompatTheme_colorControlHighlight = 52;
        public static final int AppCompatTheme_colorControlNormal = 53;
        public static final int AppCompatTheme_colorError = 54;
        public static final int AppCompatTheme_colorPrimary = 55;
        public static final int AppCompatTheme_colorPrimaryDark = 56;
        public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
        public static final int AppCompatTheme_controlBackground = 58;
        public static final int AppCompatTheme_dialogCornerRadius = 59;
        public static final int AppCompatTheme_dialogPreferredPadding = 60;
        public static final int AppCompatTheme_dialogTheme = 61;
        public static final int AppCompatTheme_dividerHorizontal = 62;
        public static final int AppCompatTheme_dividerVertical = 63;
        public static final int AppCompatTheme_dropDownListViewStyle = 64;
        public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
        public static final int AppCompatTheme_editTextBackground = 66;
        public static final int AppCompatTheme_editTextColor = 67;
        public static final int AppCompatTheme_editTextStyle = 68;
        public static final int AppCompatTheme_homeAsUpIndicator = 69;
        public static final int AppCompatTheme_imageButtonStyle = 70;
        public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
        public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
        public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
        public static final int AppCompatTheme_listDividerAlertDialog = 74;
        public static final int AppCompatTheme_listMenuViewStyle = 75;
        public static final int AppCompatTheme_listPopupWindowStyle = 76;
        public static final int AppCompatTheme_listPreferredItemHeight = 77;
        public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
        public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
        public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
        public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
        public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
        public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
        public static final int AppCompatTheme_panelBackground = 84;
        public static final int AppCompatTheme_panelMenuListTheme = 85;
        public static final int AppCompatTheme_panelMenuListWidth = 86;
        public static final int AppCompatTheme_popupMenuStyle = 87;
        public static final int AppCompatTheme_popupWindowStyle = 88;
        public static final int AppCompatTheme_radioButtonStyle = 89;
        public static final int AppCompatTheme_ratingBarStyle = 90;
        public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
        public static final int AppCompatTheme_ratingBarStyleSmall = 92;
        public static final int AppCompatTheme_searchViewStyle = 93;
        public static final int AppCompatTheme_seekBarStyle = 94;
        public static final int AppCompatTheme_selectableItemBackground = 95;
        public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
        public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
        public static final int AppCompatTheme_spinnerStyle = 98;
        public static final int AppCompatTheme_switchStyle = 99;
        public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
        public static final int AppCompatTheme_textAppearanceListItem = 101;
        public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
        public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
        public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
        public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
        public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
        public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
        public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
        public static final int AppCompatTheme_textColorSearchUrl = 109;
        public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
        public static final int AppCompatTheme_toolbarStyle = 111;
        public static final int AppCompatTheme_tooltipForegroundColor = 112;
        public static final int AppCompatTheme_tooltipFrameBackground = 113;
        public static final int AppCompatTheme_viewInflaterClass = 114;
        public static final int AppCompatTheme_windowActionBar = 115;
        public static final int AppCompatTheme_windowActionBarOverlay = 116;
        public static final int AppCompatTheme_windowActionModeOverlay = 117;
        public static final int AppCompatTheme_windowFixedHeightMajor = 118;
        public static final int AppCompatTheme_windowFixedHeightMinor = 119;
        public static final int AppCompatTheme_windowFixedWidthMajor = 120;
        public static final int AppCompatTheme_windowFixedWidthMinor = 121;
        public static final int AppCompatTheme_windowMinWidthMajor = 122;
        public static final int AppCompatTheme_windowMinWidthMinor = 123;
        public static final int AppCompatTheme_windowNoTitle = 124;
        public static final int[] Badge = new int[]{attr.backgroundColor, attr.badgeGravity, attr.badgeTextColor, attr.maxCharacterCount, attr.number};
        public static final int Badge_backgroundColor = 0;
        public static final int Badge_badgeGravity = 1;
        public static final int Badge_badgeTextColor = 2;
        public static final int Badge_maxCharacterCount = 3;
        public static final int Badge_number = 4;
        public static final int[] BottomAppBar = new int[]{attr.backgroundTint, attr.elevation, attr.fabAlignmentMode, attr.fabAnimationMode, attr.fabCradleMargin, attr.fabCradleRoundedCornerRadius, attr.fabCradleVerticalOffset, attr.hideOnScroll};
        public static final int BottomAppBar_backgroundTint = 0;
        public static final int BottomAppBar_elevation = 1;
        public static final int BottomAppBar_fabAlignmentMode = 2;
        public static final int BottomAppBar_fabAnimationMode = 3;
        public static final int BottomAppBar_fabCradleMargin = 4;
        public static final int BottomAppBar_fabCradleRoundedCornerRadius = 5;
        public static final int BottomAppBar_fabCradleVerticalOffset = 6;
        public static final int BottomAppBar_hideOnScroll = 7;
        public static final int[] BottomNavigationView = new int[]{attr.backgroundTint, attr.elevation, attr.itemBackground, attr.itemHorizontalTranslationEnabled, attr.itemIconSize, attr.itemIconTint, attr.itemRippleColor, attr.itemTextAppearanceActive, attr.itemTextAppearanceInactive, attr.itemTextColor, attr.labelVisibilityMode, attr.menu};
        public static final int BottomNavigationView_backgroundTint = 0;
        public static final int BottomNavigationView_elevation = 1;
        public static final int BottomNavigationView_itemBackground = 2;
        public static final int BottomNavigationView_itemHorizontalTranslationEnabled = 3;
        public static final int BottomNavigationView_itemIconSize = 4;
        public static final int BottomNavigationView_itemIconTint = 5;
        public static final int BottomNavigationView_itemRippleColor = 6;
        public static final int BottomNavigationView_itemTextAppearanceActive = 7;
        public static final int BottomNavigationView_itemTextAppearanceInactive = 8;
        public static final int BottomNavigationView_itemTextColor = 9;
        public static final int BottomNavigationView_labelVisibilityMode = 10;
        public static final int BottomNavigationView_menu = 11;
        public static final int[] BottomSheetBehavior_Layout = new int[]{16843840, attr.backgroundTint, attr.behavior_expandedOffset, attr.behavior_fitToContents, attr.behavior_halfExpandedRatio, attr.behavior_hideable, attr.behavior_peekHeight, attr.behavior_saveFlags, attr.behavior_skipCollapsed, attr.shapeAppearance, attr.shapeAppearanceOverlay};
        public static final int BottomSheetBehavior_Layout_android_elevation = 0;
        public static final int BottomSheetBehavior_Layout_backgroundTint = 1;
        public static final int BottomSheetBehavior_Layout_behavior_expandedOffset = 2;
        public static final int BottomSheetBehavior_Layout_behavior_fitToContents = 3;
        public static final int BottomSheetBehavior_Layout_behavior_halfExpandedRatio = 4;
        public static final int BottomSheetBehavior_Layout_behavior_hideable = 5;
        public static final int BottomSheetBehavior_Layout_behavior_peekHeight = 6;
        public static final int BottomSheetBehavior_Layout_behavior_saveFlags = 7;
        public static final int BottomSheetBehavior_Layout_behavior_skipCollapsed = 8;
        public static final int BottomSheetBehavior_Layout_shapeAppearance = 9;
        public static final int BottomSheetBehavior_Layout_shapeAppearanceOverlay = 10;
        public static final int[] ButtonBarLayout = new int[]{attr.allowStacking};
        public static final int ButtonBarLayout_allowStacking = 0;
        public static final int[] CardView = new int[]{16843071, 16843072, attr.cardBackgroundColor, attr.cardCornerRadius, attr.cardElevation, attr.cardMaxElevation, attr.cardPreventCornerOverlap, attr.cardUseCompatPadding, attr.contentPadding, attr.contentPaddingBottom, attr.contentPaddingLeft, attr.contentPaddingRight, attr.contentPaddingTop};
        public static final int CardView_android_minHeight = 1;
        public static final int CardView_android_minWidth = 0;
        public static final int CardView_cardBackgroundColor = 2;
        public static final int CardView_cardCornerRadius = 3;
        public static final int CardView_cardElevation = 4;
        public static final int CardView_cardMaxElevation = 5;
        public static final int CardView_cardPreventCornerOverlap = 6;
        public static final int CardView_cardUseCompatPadding = 7;
        public static final int CardView_contentPadding = 8;
        public static final int CardView_contentPaddingBottom = 9;
        public static final int CardView_contentPaddingLeft = 10;
        public static final int CardView_contentPaddingRight = 11;
        public static final int CardView_contentPaddingTop = 12;
        public static final int[] Chip = new int[]{16842804, 16842904, 16842923, 16843039, 16843087, 16843237, attr.checkedIcon, attr.checkedIconEnabled, attr.checkedIconVisible, attr.chipBackgroundColor, attr.chipCornerRadius, attr.chipEndPadding, attr.chipIcon, attr.chipIconEnabled, attr.chipIconSize, attr.chipIconTint, attr.chipIconVisible, attr.chipMinHeight, attr.chipMinTouchTargetSize, attr.chipStartPadding, attr.chipStrokeColor, attr.chipStrokeWidth, attr.chipSurfaceColor, attr.closeIcon, attr.closeIconEnabled, attr.closeIconEndPadding, attr.closeIconSize, attr.closeIconStartPadding, attr.closeIconTint, attr.closeIconVisible, attr.ensureMinTouchTargetSize, attr.hideMotionSpec, attr.iconEndPadding, attr.iconStartPadding, attr.rippleColor, attr.shapeAppearance, attr.shapeAppearanceOverlay, attr.showMotionSpec, attr.textEndPadding, attr.textStartPadding};
        public static final int[] ChipGroup = new int[]{attr.checkedChip, attr.chipSpacing, attr.chipSpacingHorizontal, attr.chipSpacingVertical, attr.singleLine, attr.singleSelection};
        public static final int ChipGroup_checkedChip = 0;
        public static final int ChipGroup_chipSpacing = 1;
        public static final int ChipGroup_chipSpacingHorizontal = 2;
        public static final int ChipGroup_chipSpacingVertical = 3;
        public static final int ChipGroup_singleLine = 4;
        public static final int ChipGroup_singleSelection = 5;
        public static final int Chip_android_checkable = 5;
        public static final int Chip_android_ellipsize = 2;
        public static final int Chip_android_maxWidth = 3;
        public static final int Chip_android_text = 4;
        public static final int Chip_android_textAppearance = 0;
        public static final int Chip_android_textColor = 1;
        public static final int Chip_checkedIcon = 6;
        public static final int Chip_checkedIconEnabled = 7;
        public static final int Chip_checkedIconVisible = 8;
        public static final int Chip_chipBackgroundColor = 9;
        public static final int Chip_chipCornerRadius = 10;
        public static final int Chip_chipEndPadding = 11;
        public static final int Chip_chipIcon = 12;
        public static final int Chip_chipIconEnabled = 13;
        public static final int Chip_chipIconSize = 14;
        public static final int Chip_chipIconTint = 15;
        public static final int Chip_chipIconVisible = 16;
        public static final int Chip_chipMinHeight = 17;
        public static final int Chip_chipMinTouchTargetSize = 18;
        public static final int Chip_chipStartPadding = 19;
        public static final int Chip_chipStrokeColor = 20;
        public static final int Chip_chipStrokeWidth = 21;
        public static final int Chip_chipSurfaceColor = 22;
        public static final int Chip_closeIcon = 23;
        public static final int Chip_closeIconEnabled = 24;
        public static final int Chip_closeIconEndPadding = 25;
        public static final int Chip_closeIconSize = 26;
        public static final int Chip_closeIconStartPadding = 27;
        public static final int Chip_closeIconTint = 28;
        public static final int Chip_closeIconVisible = 29;
        public static final int Chip_ensureMinTouchTargetSize = 30;
        public static final int Chip_hideMotionSpec = 31;
        public static final int Chip_iconEndPadding = 32;
        public static final int Chip_iconStartPadding = 33;
        public static final int Chip_rippleColor = 34;
        public static final int Chip_shapeAppearance = 35;
        public static final int Chip_shapeAppearanceOverlay = 36;
        public static final int Chip_showMotionSpec = 37;
        public static final int Chip_textEndPadding = 38;
        public static final int Chip_textStartPadding = 39;
        public static final int[] CircleImageView = new int[]{attr.civ_border_color, attr.civ_border_overlay, attr.civ_border_width, attr.civ_circle_background_color};
        public static final int CircleImageView_civ_border_color = 0;
        public static final int CircleImageView_civ_border_overlay = 1;
        public static final int CircleImageView_civ_border_width = 2;
        public static final int CircleImageView_civ_circle_background_color = 3;
        public static final int[] CollapsingToolbarLayout = new int[]{attr.collapsedTitleGravity, attr.collapsedTitleTextAppearance, attr.contentScrim, attr.expandedTitleGravity, attr.expandedTitleMargin, attr.expandedTitleMarginBottom, attr.expandedTitleMarginEnd, attr.expandedTitleMarginStart, attr.expandedTitleMarginTop, attr.expandedTitleTextAppearance, attr.scrimAnimationDuration, attr.scrimVisibleHeightTrigger, attr.statusBarScrim, attr.title, attr.titleEnabled, attr.toolbarId};
        public static final int[] CollapsingToolbarLayout_Layout = new int[]{attr.layout_collapseMode, attr.layout_collapseParallaxMultiplier};
        public static final int CollapsingToolbarLayout_Layout_layout_collapseMode = 0;
        public static final int CollapsingToolbarLayout_Layout_layout_collapseParallaxMultiplier = 1;
        public static final int CollapsingToolbarLayout_collapsedTitleGravity = 0;
        public static final int CollapsingToolbarLayout_collapsedTitleTextAppearance = 1;
        public static final int CollapsingToolbarLayout_contentScrim = 2;
        public static final int CollapsingToolbarLayout_expandedTitleGravity = 3;
        public static final int CollapsingToolbarLayout_expandedTitleMargin = 4;
        public static final int CollapsingToolbarLayout_expandedTitleMarginBottom = 5;
        public static final int CollapsingToolbarLayout_expandedTitleMarginEnd = 6;
        public static final int CollapsingToolbarLayout_expandedTitleMarginStart = 7;
        public static final int CollapsingToolbarLayout_expandedTitleMarginTop = 8;
        public static final int CollapsingToolbarLayout_expandedTitleTextAppearance = 9;
        public static final int CollapsingToolbarLayout_scrimAnimationDuration = 10;
        public static final int CollapsingToolbarLayout_scrimVisibleHeightTrigger = 11;
        public static final int CollapsingToolbarLayout_statusBarScrim = 12;
        public static final int CollapsingToolbarLayout_title = 13;
        public static final int CollapsingToolbarLayout_titleEnabled = 14;
        public static final int CollapsingToolbarLayout_toolbarId = 15;
        public static final int[] ColorStateListItem = new int[]{16843173, 16843551, attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] CompoundButton = new int[]{16843015, attr.buttonCompat, attr.buttonTint, attr.buttonTintMode};
        public static final int CompoundButton_android_button = 0;
        public static final int CompoundButton_buttonCompat = 1;
        public static final int CompoundButton_buttonTint = 2;
        public static final int CompoundButton_buttonTintMode = 3;
        public static final int[] ConstraintLayout_Layout = new int[]{16842948, 16843039, 16843040, 16843071, 16843072, attr.barrierAllowsGoneWidgets, attr.barrierDirection, attr.chainUseRtl, attr.constraintSet, attr.constraint_referenced_ids, attr.layout_constrainedHeight, attr.layout_constrainedWidth, attr.layout_constraintBaseline_creator, attr.layout_constraintBaseline_toBaselineOf, attr.layout_constraintBottom_creator, attr.layout_constraintBottom_toBottomOf, attr.layout_constraintBottom_toTopOf, attr.layout_constraintCircle, attr.layout_constraintCircleAngle, attr.layout_constraintCircleRadius, attr.layout_constraintDimensionRatio, attr.layout_constraintEnd_toEndOf, attr.layout_constraintEnd_toStartOf, attr.layout_constraintGuide_begin, attr.layout_constraintGuide_end, attr.layout_constraintGuide_percent, attr.layout_constraintHeight_default, attr.layout_constraintHeight_max, attr.layout_constraintHeight_min, attr.layout_constraintHeight_percent, attr.layout_constraintHorizontal_bias, attr.layout_constraintHorizontal_chainStyle, attr.layout_constraintHorizontal_weight, attr.layout_constraintLeft_creator, attr.layout_constraintLeft_toLeftOf, attr.layout_constraintLeft_toRightOf, attr.layout_constraintRight_creator, attr.layout_constraintRight_toLeftOf, attr.layout_constraintRight_toRightOf, attr.layout_constraintStart_toEndOf, attr.layout_constraintStart_toStartOf, attr.layout_constraintTop_creator, attr.layout_constraintTop_toBottomOf, attr.layout_constraintTop_toTopOf, attr.layout_constraintVertical_bias, attr.layout_constraintVertical_chainStyle, attr.layout_constraintVertical_weight, attr.layout_constraintWidth_default, attr.layout_constraintWidth_max, attr.layout_constraintWidth_min, attr.layout_constraintWidth_percent, attr.layout_editor_absoluteX, attr.layout_editor_absoluteY, attr.layout_goneMarginBottom, attr.layout_goneMarginEnd, attr.layout_goneMarginLeft, attr.layout_goneMarginRight, attr.layout_goneMarginStart, attr.layout_goneMarginTop, attr.layout_optimizationLevel};
        public static final int ConstraintLayout_Layout_android_maxHeight = 2;
        public static final int ConstraintLayout_Layout_android_maxWidth = 1;
        public static final int ConstraintLayout_Layout_android_minHeight = 4;
        public static final int ConstraintLayout_Layout_android_minWidth = 3;
        public static final int ConstraintLayout_Layout_android_orientation = 0;
        public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
        public static final int ConstraintLayout_Layout_barrierDirection = 6;
        public static final int ConstraintLayout_Layout_chainUseRtl = 7;
        public static final int ConstraintLayout_Layout_constraintSet = 8;
        public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
        public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
        public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
        public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
        public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
        public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
        public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
        public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
        public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
        public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
        public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
        public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
        public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
        public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
        public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
        public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
        public static final int[] ConstraintLayout_placeholder = new int[]{attr.content, attr.emptyVisibility};
        public static final int ConstraintLayout_placeholder_content = 0;
        public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
        public static final int[] ConstraintSet = new int[]{16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, attr.barrierAllowsGoneWidgets, attr.barrierDirection, attr.chainUseRtl, attr.constraint_referenced_ids, attr.layout_constrainedHeight, attr.layout_constrainedWidth, attr.layout_constraintBaseline_creator, attr.layout_constraintBaseline_toBaselineOf, attr.layout_constraintBottom_creator, attr.layout_constraintBottom_toBottomOf, attr.layout_constraintBottom_toTopOf, attr.layout_constraintCircle, attr.layout_constraintCircleAngle, attr.layout_constraintCircleRadius, attr.layout_constraintDimensionRatio, attr.layout_constraintEnd_toEndOf, attr.layout_constraintEnd_toStartOf, attr.layout_constraintGuide_begin, attr.layout_constraintGuide_end, attr.layout_constraintGuide_percent, attr.layout_constraintHeight_default, attr.layout_constraintHeight_max, attr.layout_constraintHeight_min, attr.layout_constraintHeight_percent, attr.layout_constraintHorizontal_bias, attr.layout_constraintHorizontal_chainStyle, attr.layout_constraintHorizontal_weight, attr.layout_constraintLeft_creator, attr.layout_constraintLeft_toLeftOf, attr.layout_constraintLeft_toRightOf, attr.layout_constraintRight_creator, attr.layout_constraintRight_toLeftOf, attr.layout_constraintRight_toRightOf, attr.layout_constraintStart_toEndOf, attr.layout_constraintStart_toStartOf, attr.layout_constraintTop_creator, attr.layout_constraintTop_toBottomOf, attr.layout_constraintTop_toTopOf, attr.layout_constraintVertical_bias, attr.layout_constraintVertical_chainStyle, attr.layout_constraintVertical_weight, attr.layout_constraintWidth_default, attr.layout_constraintWidth_max, attr.layout_constraintWidth_min, attr.layout_constraintWidth_percent, attr.layout_editor_absoluteX, attr.layout_editor_absoluteY, attr.layout_goneMarginBottom, attr.layout_goneMarginEnd, attr.layout_goneMarginLeft, attr.layout_goneMarginRight, attr.layout_goneMarginStart, attr.layout_goneMarginTop};
        public static final int ConstraintSet_android_alpha = 13;
        public static final int ConstraintSet_android_elevation = 26;
        public static final int ConstraintSet_android_id = 1;
        public static final int ConstraintSet_android_layout_height = 4;
        public static final int ConstraintSet_android_layout_marginBottom = 8;
        public static final int ConstraintSet_android_layout_marginEnd = 24;
        public static final int ConstraintSet_android_layout_marginLeft = 5;
        public static final int ConstraintSet_android_layout_marginRight = 7;
        public static final int ConstraintSet_android_layout_marginStart = 23;
        public static final int ConstraintSet_android_layout_marginTop = 6;
        public static final int ConstraintSet_android_layout_width = 3;
        public static final int ConstraintSet_android_maxHeight = 10;
        public static final int ConstraintSet_android_maxWidth = 9;
        public static final int ConstraintSet_android_minHeight = 12;
        public static final int ConstraintSet_android_minWidth = 11;
        public static final int ConstraintSet_android_orientation = 0;
        public static final int ConstraintSet_android_rotation = 20;
        public static final int ConstraintSet_android_rotationX = 21;
        public static final int ConstraintSet_android_rotationY = 22;
        public static final int ConstraintSet_android_scaleX = 18;
        public static final int ConstraintSet_android_scaleY = 19;
        public static final int ConstraintSet_android_transformPivotX = 14;
        public static final int ConstraintSet_android_transformPivotY = 15;
        public static final int ConstraintSet_android_translationX = 16;
        public static final int ConstraintSet_android_translationY = 17;
        public static final int ConstraintSet_android_translationZ = 25;
        public static final int ConstraintSet_android_visibility = 2;
        public static final int ConstraintSet_barrierAllowsGoneWidgets = 27;
        public static final int ConstraintSet_barrierDirection = 28;
        public static final int ConstraintSet_chainUseRtl = 29;
        public static final int ConstraintSet_constraint_referenced_ids = 30;
        public static final int ConstraintSet_layout_constrainedHeight = 31;
        public static final int ConstraintSet_layout_constrainedWidth = 32;
        public static final int ConstraintSet_layout_constraintBaseline_creator = 33;
        public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 34;
        public static final int ConstraintSet_layout_constraintBottom_creator = 35;
        public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 36;
        public static final int ConstraintSet_layout_constraintBottom_toTopOf = 37;
        public static final int ConstraintSet_layout_constraintCircle = 38;
        public static final int ConstraintSet_layout_constraintCircleAngle = 39;
        public static final int ConstraintSet_layout_constraintCircleRadius = 40;
        public static final int ConstraintSet_layout_constraintDimensionRatio = 41;
        public static final int ConstraintSet_layout_constraintEnd_toEndOf = 42;
        public static final int ConstraintSet_layout_constraintEnd_toStartOf = 43;
        public static final int ConstraintSet_layout_constraintGuide_begin = 44;
        public static final int ConstraintSet_layout_constraintGuide_end = 45;
        public static final int ConstraintSet_layout_constraintGuide_percent = 46;
        public static final int ConstraintSet_layout_constraintHeight_default = 47;
        public static final int ConstraintSet_layout_constraintHeight_max = 48;
        public static final int ConstraintSet_layout_constraintHeight_min = 49;
        public static final int ConstraintSet_layout_constraintHeight_percent = 50;
        public static final int ConstraintSet_layout_constraintHorizontal_bias = 51;
        public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 52;
        public static final int ConstraintSet_layout_constraintHorizontal_weight = 53;
        public static final int ConstraintSet_layout_constraintLeft_creator = 54;
        public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 55;
        public static final int ConstraintSet_layout_constraintLeft_toRightOf = 56;
        public static final int ConstraintSet_layout_constraintRight_creator = 57;
        public static final int ConstraintSet_layout_constraintRight_toLeftOf = 58;
        public static final int ConstraintSet_layout_constraintRight_toRightOf = 59;
        public static final int ConstraintSet_layout_constraintStart_toEndOf = 60;
        public static final int ConstraintSet_layout_constraintStart_toStartOf = 61;
        public static final int ConstraintSet_layout_constraintTop_creator = 62;
        public static final int ConstraintSet_layout_constraintTop_toBottomOf = 63;
        public static final int ConstraintSet_layout_constraintTop_toTopOf = 64;
        public static final int ConstraintSet_layout_constraintVertical_bias = 65;
        public static final int ConstraintSet_layout_constraintVertical_chainStyle = 66;
        public static final int ConstraintSet_layout_constraintVertical_weight = 67;
        public static final int ConstraintSet_layout_constraintWidth_default = 68;
        public static final int ConstraintSet_layout_constraintWidth_max = 69;
        public static final int ConstraintSet_layout_constraintWidth_min = 70;
        public static final int ConstraintSet_layout_constraintWidth_percent = 71;
        public static final int ConstraintSet_layout_editor_absoluteX = 72;
        public static final int ConstraintSet_layout_editor_absoluteY = 73;
        public static final int ConstraintSet_layout_goneMarginBottom = 74;
        public static final int ConstraintSet_layout_goneMarginEnd = 75;
        public static final int ConstraintSet_layout_goneMarginLeft = 76;
        public static final int ConstraintSet_layout_goneMarginRight = 77;
        public static final int ConstraintSet_layout_goneMarginStart = 78;
        public static final int ConstraintSet_layout_goneMarginTop = 79;
        public static final int[] CoordinatorLayout = new int[]{attr.keylines, attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = new int[]{16842931, attr.layout_anchor, attr.layout_anchorGravity, attr.layout_behavior, attr.layout_dodgeInsetEdges, attr.layout_insetEdge, attr.layout_keyline};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] DrawerArrowToggle = new int[]{attr.arrowHeadLength, attr.arrowShaftLength, attr.barLength, attr.color, attr.drawableSize, attr.gapBetweenBars, attr.spinBars, attr.thickness};
        public static final int DrawerArrowToggle_arrowHeadLength = 0;
        public static final int DrawerArrowToggle_arrowShaftLength = 1;
        public static final int DrawerArrowToggle_barLength = 2;
        public static final int DrawerArrowToggle_color = 3;
        public static final int DrawerArrowToggle_drawableSize = 4;
        public static final int DrawerArrowToggle_gapBetweenBars = 5;
        public static final int DrawerArrowToggle_spinBars = 6;
        public static final int DrawerArrowToggle_thickness = 7;
        public static final int[] ExtendedFloatingActionButton = new int[]{attr.elevation, attr.extendMotionSpec, attr.hideMotionSpec, attr.showMotionSpec, attr.shrinkMotionSpec};
        public static final int[] ExtendedFloatingActionButton_Behavior_Layout = new int[]{attr.behavior_autoHide, attr.behavior_autoShrink};
        public static final int ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide = 0;
        public static final int ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink = 1;
        public static final int ExtendedFloatingActionButton_elevation = 0;
        public static final int ExtendedFloatingActionButton_extendMotionSpec = 1;
        public static final int ExtendedFloatingActionButton_hideMotionSpec = 2;
        public static final int ExtendedFloatingActionButton_showMotionSpec = 3;
        public static final int ExtendedFloatingActionButton_shrinkMotionSpec = 4;
        public static final int[] FloatingActionButton = new int[]{attr.backgroundTint, attr.backgroundTintMode, attr.borderWidth, attr.elevation, attr.ensureMinTouchTargetSize, attr.fabCustomSize, attr.fabSize, attr.hideMotionSpec, attr.hoveredFocusedTranslationZ, attr.maxImageSize, attr.pressedTranslationZ, attr.rippleColor, attr.shapeAppearance, attr.shapeAppearanceOverlay, attr.showMotionSpec, attr.useCompatPadding};
        public static final int[] FloatingActionButton_Behavior_Layout = new int[]{attr.behavior_autoHide};
        public static final int FloatingActionButton_Behavior_Layout_behavior_autoHide = 0;
        public static final int FloatingActionButton_backgroundTint = 0;
        public static final int FloatingActionButton_backgroundTintMode = 1;
        public static final int FloatingActionButton_borderWidth = 2;
        public static final int FloatingActionButton_elevation = 3;
        public static final int FloatingActionButton_ensureMinTouchTargetSize = 4;
        public static final int FloatingActionButton_fabCustomSize = 5;
        public static final int FloatingActionButton_fabSize = 6;
        public static final int FloatingActionButton_hideMotionSpec = 7;
        public static final int FloatingActionButton_hoveredFocusedTranslationZ = 8;
        public static final int FloatingActionButton_maxImageSize = 9;
        public static final int FloatingActionButton_pressedTranslationZ = 10;
        public static final int FloatingActionButton_rippleColor = 11;
        public static final int FloatingActionButton_shapeAppearance = 12;
        public static final int FloatingActionButton_shapeAppearanceOverlay = 13;
        public static final int FloatingActionButton_showMotionSpec = 14;
        public static final int FloatingActionButton_useCompatPadding = 15;
        public static final int[] FlowLayout = new int[]{attr.itemSpacing, attr.lineSpacing};
        public static final int FlowLayout_itemSpacing = 0;
        public static final int FlowLayout_lineSpacing = 1;
        public static final int[] FontFamily = new int[]{attr.fontProviderAuthority, attr.fontProviderCerts, attr.fontProviderFetchStrategy, attr.fontProviderFetchTimeout, attr.fontProviderPackage, attr.fontProviderQuery};
        public static final int[] FontFamilyFont = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, attr.font, attr.fontStyle, attr.fontVariationSettings, attr.fontWeight, attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] ForegroundLinearLayout = new int[]{16843017, 16843264, attr.foregroundInsidePadding};
        public static final int ForegroundLinearLayout_android_foreground = 0;
        public static final int ForegroundLinearLayout_android_foregroundGravity = 1;
        public static final int ForegroundLinearLayout_foregroundInsidePadding = 2;
        public static final int[] GradientColor = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = new int[]{16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] LinearConstraintLayout = new int[]{16842948};
        public static final int LinearConstraintLayout_android_orientation = 0;
        public static final int[] LinearLayoutCompat = new int[]{16842927, 16842948, 16843046, 16843047, 16843048, attr.divider, attr.dividerPadding, attr.measureWithLargestChild, attr.showDividers};
        public static final int[] LinearLayoutCompat_Layout = new int[]{16842931, 16842996, 16842997, 16843137};
        public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
        public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
        public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
        public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
        public static final int LinearLayoutCompat_android_baselineAligned = 2;
        public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
        public static final int LinearLayoutCompat_android_gravity = 0;
        public static final int LinearLayoutCompat_android_orientation = 1;
        public static final int LinearLayoutCompat_android_weightSum = 4;
        public static final int LinearLayoutCompat_divider = 5;
        public static final int LinearLayoutCompat_dividerPadding = 6;
        public static final int LinearLayoutCompat_measureWithLargestChild = 7;
        public static final int LinearLayoutCompat_showDividers = 8;
        public static final int[] ListPopupWindow = new int[]{16843436, 16843437};
        public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
        public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
        public static final int[] LoadingImageView = new int[]{attr.circleCrop, attr.imageAspectRatio, attr.imageAspectRatioAdjust};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] MaterialAlertDialog = new int[]{attr.backgroundInsetBottom, attr.backgroundInsetEnd, attr.backgroundInsetStart, attr.backgroundInsetTop};
        public static final int[] MaterialAlertDialogTheme = new int[]{attr.materialAlertDialogBodyTextStyle, attr.materialAlertDialogTheme, attr.materialAlertDialogTitleIconStyle, attr.materialAlertDialogTitlePanelStyle, attr.materialAlertDialogTitleTextStyle};
        public static final int MaterialAlertDialogTheme_materialAlertDialogBodyTextStyle = 0;
        public static final int MaterialAlertDialogTheme_materialAlertDialogTheme = 1;
        public static final int MaterialAlertDialogTheme_materialAlertDialogTitleIconStyle = 2;
        public static final int MaterialAlertDialogTheme_materialAlertDialogTitlePanelStyle = 3;
        public static final int MaterialAlertDialogTheme_materialAlertDialogTitleTextStyle = 4;
        public static final int MaterialAlertDialog_backgroundInsetBottom = 0;
        public static final int MaterialAlertDialog_backgroundInsetEnd = 1;
        public static final int MaterialAlertDialog_backgroundInsetStart = 2;
        public static final int MaterialAlertDialog_backgroundInsetTop = 3;
        public static final int[] MaterialButton = new int[]{16843191, 16843192, 16843193, 16843194, 16843237, attr.backgroundTint, attr.backgroundTintMode, attr.cornerRadius, attr.elevation, attr.icon, attr.iconGravity, attr.iconPadding, attr.iconSize, attr.iconTint, attr.iconTintMode, attr.rippleColor, attr.shapeAppearance, attr.shapeAppearanceOverlay, attr.strokeColor, attr.strokeWidth};
        public static final int[] MaterialButtonToggleGroup = new int[]{attr.checkedButton, attr.singleSelection};
        public static final int MaterialButtonToggleGroup_checkedButton = 0;
        public static final int MaterialButtonToggleGroup_singleSelection = 1;
        public static final int MaterialButton_android_checkable = 4;
        public static final int MaterialButton_android_insetBottom = 3;
        public static final int MaterialButton_android_insetLeft = 0;
        public static final int MaterialButton_android_insetRight = 1;
        public static final int MaterialButton_android_insetTop = 2;
        public static final int MaterialButton_backgroundTint = 5;
        public static final int MaterialButton_backgroundTintMode = 6;
        public static final int MaterialButton_cornerRadius = 7;
        public static final int MaterialButton_elevation = 8;
        public static final int MaterialButton_icon = 9;
        public static final int MaterialButton_iconGravity = 10;
        public static final int MaterialButton_iconPadding = 11;
        public static final int MaterialButton_iconSize = 12;
        public static final int MaterialButton_iconTint = 13;
        public static final int MaterialButton_iconTintMode = 14;
        public static final int MaterialButton_rippleColor = 15;
        public static final int MaterialButton_shapeAppearance = 16;
        public static final int MaterialButton_shapeAppearanceOverlay = 17;
        public static final int MaterialButton_strokeColor = 18;
        public static final int MaterialButton_strokeWidth = 19;
        public static final int[] MaterialCalendar = new int[]{16843277, attr.dayInvalidStyle, attr.daySelectedStyle, attr.dayStyle, attr.dayTodayStyle, attr.rangeFillColor, attr.yearSelectedStyle, attr.yearStyle, attr.yearTodayStyle};
        public static final int[] MaterialCalendarItem = new int[]{16843191, 16843192, 16843193, 16843194, attr.itemFillColor, attr.itemShapeAppearance, attr.itemShapeAppearanceOverlay, attr.itemStrokeColor, attr.itemStrokeWidth, attr.itemTextColor};
        public static final int MaterialCalendarItem_android_insetBottom = 3;
        public static final int MaterialCalendarItem_android_insetLeft = 0;
        public static final int MaterialCalendarItem_android_insetRight = 1;
        public static final int MaterialCalendarItem_android_insetTop = 2;
        public static final int MaterialCalendarItem_itemFillColor = 4;
        public static final int MaterialCalendarItem_itemShapeAppearance = 5;
        public static final int MaterialCalendarItem_itemShapeAppearanceOverlay = 6;
        public static final int MaterialCalendarItem_itemStrokeColor = 7;
        public static final int MaterialCalendarItem_itemStrokeWidth = 8;
        public static final int MaterialCalendarItem_itemTextColor = 9;
        public static final int MaterialCalendar_android_windowFullscreen = 0;
        public static final int MaterialCalendar_dayInvalidStyle = 1;
        public static final int MaterialCalendar_daySelectedStyle = 2;
        public static final int MaterialCalendar_dayStyle = 3;
        public static final int MaterialCalendar_dayTodayStyle = 4;
        public static final int MaterialCalendar_rangeFillColor = 5;
        public static final int MaterialCalendar_yearSelectedStyle = 6;
        public static final int MaterialCalendar_yearStyle = 7;
        public static final int MaterialCalendar_yearTodayStyle = 8;
        public static final int[] MaterialCardView = new int[]{16843237, attr.cardForegroundColor, attr.checkedIcon, attr.checkedIconTint, attr.rippleColor, attr.shapeAppearance, attr.shapeAppearanceOverlay, attr.state_dragged, attr.strokeColor, attr.strokeWidth};
        public static final int MaterialCardView_android_checkable = 0;
        public static final int MaterialCardView_cardForegroundColor = 1;
        public static final int MaterialCardView_checkedIcon = 2;
        public static final int MaterialCardView_checkedIconTint = 3;
        public static final int MaterialCardView_rippleColor = 4;
        public static final int MaterialCardView_shapeAppearance = 5;
        public static final int MaterialCardView_shapeAppearanceOverlay = 6;
        public static final int MaterialCardView_state_dragged = 7;
        public static final int MaterialCardView_strokeColor = 8;
        public static final int MaterialCardView_strokeWidth = 9;
        public static final int[] MaterialCheckBox = new int[]{attr.buttonTint, attr.useMaterialThemeColors};
        public static final int MaterialCheckBox_buttonTint = 0;
        public static final int MaterialCheckBox_useMaterialThemeColors = 1;
        public static final int[] MaterialRadioButton = new int[]{attr.useMaterialThemeColors};
        public static final int MaterialRadioButton_useMaterialThemeColors = 0;
        public static final int[] MaterialShape = new int[]{attr.shapeAppearance, attr.shapeAppearanceOverlay};
        public static final int MaterialShape_shapeAppearance = 0;
        public static final int MaterialShape_shapeAppearanceOverlay = 1;
        public static final int[] MaterialTextAppearance = new int[]{16844159, attr.lineHeight};
        public static final int MaterialTextAppearance_android_lineHeight = 0;
        public static final int MaterialTextAppearance_lineHeight = 1;
        public static final int[] MaterialTextView = new int[]{16842804, 16844159, attr.lineHeight};
        public static final int MaterialTextView_android_lineHeight = 1;
        public static final int MaterialTextView_android_textAppearance = 0;
        public static final int MaterialTextView_lineHeight = 2;
        public static final int[] MenuGroup = new int[]{16842766, 16842960, 16843156, 16843230, 16843231, 16843232};
        public static final int MenuGroup_android_checkableBehavior = 5;
        public static final int MenuGroup_android_enabled = 0;
        public static final int MenuGroup_android_id = 1;
        public static final int MenuGroup_android_menuCategory = 3;
        public static final int MenuGroup_android_orderInCategory = 4;
        public static final int MenuGroup_android_visible = 2;
        public static final int[] MenuItem = new int[]{16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 16843236, 16843237, 16843375, attr.actionLayout, attr.actionProviderClass, attr.actionViewClass, attr.alphabeticModifiers, attr.contentDescription, attr.iconTint, attr.iconTintMode, attr.numericModifiers, attr.showAsAction, attr.tooltipText};
        public static final int MenuItem_actionLayout = 13;
        public static final int MenuItem_actionProviderClass = 14;
        public static final int MenuItem_actionViewClass = 15;
        public static final int MenuItem_alphabeticModifiers = 16;
        public static final int MenuItem_android_alphabeticShortcut = 9;
        public static final int MenuItem_android_checkable = 11;
        public static final int MenuItem_android_checked = 3;
        public static final int MenuItem_android_enabled = 1;
        public static final int MenuItem_android_icon = 0;
        public static final int MenuItem_android_id = 2;
        public static final int MenuItem_android_menuCategory = 5;
        public static final int MenuItem_android_numericShortcut = 10;
        public static final int MenuItem_android_onClick = 12;
        public static final int MenuItem_android_orderInCategory = 6;
        public static final int MenuItem_android_title = 7;
        public static final int MenuItem_android_titleCondensed = 8;
        public static final int MenuItem_android_visible = 4;
        public static final int MenuItem_contentDescription = 17;
        public static final int MenuItem_iconTint = 18;
        public static final int MenuItem_iconTintMode = 19;
        public static final int MenuItem_numericModifiers = 20;
        public static final int MenuItem_showAsAction = 21;
        public static final int MenuItem_tooltipText = 22;
        public static final int[] MenuView = new int[]{16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, attr.preserveIconSpacing, attr.subMenuArrow};
        public static final int MenuView_android_headerBackground = 4;
        public static final int MenuView_android_horizontalDivider = 2;
        public static final int MenuView_android_itemBackground = 5;
        public static final int MenuView_android_itemIconDisabledAlpha = 6;
        public static final int MenuView_android_itemTextAppearance = 1;
        public static final int MenuView_android_verticalDivider = 3;
        public static final int MenuView_android_windowAnimationStyle = 0;
        public static final int MenuView_preserveIconSpacing = 7;
        public static final int MenuView_subMenuArrow = 8;
        public static final int[] NavigationView = new int[]{16842964, 16842973, 16843039, attr.elevation, attr.headerLayout, attr.itemBackground, attr.itemHorizontalPadding, attr.itemIconPadding, attr.itemIconSize, attr.itemIconTint, attr.itemMaxLines, attr.itemShapeAppearance, attr.itemShapeAppearanceOverlay, attr.itemShapeFillColor, attr.itemShapeInsetBottom, attr.itemShapeInsetEnd, attr.itemShapeInsetStart, attr.itemShapeInsetTop, attr.itemTextAppearance, attr.itemTextColor, attr.menu};
        public static final int NavigationView_android_background = 0;
        public static final int NavigationView_android_fitsSystemWindows = 1;
        public static final int NavigationView_android_maxWidth = 2;
        public static final int NavigationView_elevation = 3;
        public static final int NavigationView_headerLayout = 4;
        public static final int NavigationView_itemBackground = 5;
        public static final int NavigationView_itemHorizontalPadding = 6;
        public static final int NavigationView_itemIconPadding = 7;
        public static final int NavigationView_itemIconSize = 8;
        public static final int NavigationView_itemIconTint = 9;
        public static final int NavigationView_itemMaxLines = 10;
        public static final int NavigationView_itemShapeAppearance = 11;
        public static final int NavigationView_itemShapeAppearanceOverlay = 12;
        public static final int NavigationView_itemShapeFillColor = 13;
        public static final int NavigationView_itemShapeInsetBottom = 14;
        public static final int NavigationView_itemShapeInsetEnd = 15;
        public static final int NavigationView_itemShapeInsetStart = 16;
        public static final int NavigationView_itemShapeInsetTop = 17;
        public static final int NavigationView_itemTextAppearance = 18;
        public static final int NavigationView_itemTextColor = 19;
        public static final int NavigationView_menu = 20;
        public static final int[] PopupWindow = new int[]{16843126, 16843465, attr.overlapAnchor};
        public static final int[] PopupWindowBackgroundState = new int[]{attr.state_above_anchor};
        public static final int PopupWindowBackgroundState_state_above_anchor = 0;
        public static final int PopupWindow_android_popupAnimationStyle = 1;
        public static final int PopupWindow_android_popupBackground = 0;
        public static final int PopupWindow_overlapAnchor = 2;
        public static final int[] RecycleListView = new int[]{attr.paddingBottomNoButtons, attr.paddingTopNoTitle};
        public static final int RecycleListView_paddingBottomNoButtons = 0;
        public static final int RecycleListView_paddingTopNoTitle = 1;
        public static final int[] RecyclerView = new int[]{16842948, 16842987, 16842993, attr.fastScrollEnabled, attr.fastScrollHorizontalThumbDrawable, attr.fastScrollHorizontalTrackDrawable, attr.fastScrollVerticalThumbDrawable, attr.fastScrollVerticalTrackDrawable, attr.layoutManager, attr.reverseLayout, attr.spanCount, attr.stackFromEnd};
        public static final int RecyclerView_android_clipToPadding = 1;
        public static final int RecyclerView_android_descendantFocusability = 2;
        public static final int RecyclerView_android_orientation = 0;
        public static final int RecyclerView_fastScrollEnabled = 3;
        public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
        public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
        public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
        public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
        public static final int RecyclerView_layoutManager = 8;
        public static final int RecyclerView_reverseLayout = 9;
        public static final int RecyclerView_spanCount = 10;
        public static final int RecyclerView_stackFromEnd = 11;
        public static final int[] ScrimInsetsFrameLayout = new int[]{attr.insetForeground};
        public static final int ScrimInsetsFrameLayout_insetForeground = 0;
        public static final int[] ScrollingViewBehavior_Layout = new int[]{attr.behavior_overlapTop};
        public static final int ScrollingViewBehavior_Layout_behavior_overlapTop = 0;
        public static final int[] SearchView = new int[]{16842970, 16843039, 16843296, 16843364, attr.closeIcon, attr.commitIcon, attr.defaultQueryHint, attr.goIcon, attr.iconifiedByDefault, attr.layout, attr.queryBackground, attr.queryHint, attr.searchHintIcon, attr.searchIcon, attr.submitBackground, attr.suggestionRowLayout, attr.voiceIcon};
        public static final int SearchView_android_focusable = 0;
        public static final int SearchView_android_imeOptions = 3;
        public static final int SearchView_android_inputType = 2;
        public static final int SearchView_android_maxWidth = 1;
        public static final int SearchView_closeIcon = 4;
        public static final int SearchView_commitIcon = 5;
        public static final int SearchView_defaultQueryHint = 6;
        public static final int SearchView_goIcon = 7;
        public static final int SearchView_iconifiedByDefault = 8;
        public static final int SearchView_layout = 9;
        public static final int SearchView_queryBackground = 10;
        public static final int SearchView_queryHint = 11;
        public static final int SearchView_searchHintIcon = 12;
        public static final int SearchView_searchIcon = 13;
        public static final int SearchView_submitBackground = 14;
        public static final int SearchView_suggestionRowLayout = 15;
        public static final int SearchView_voiceIcon = 16;
        public static final int[] ShapeAppearance = new int[]{attr.cornerFamily, attr.cornerFamilyBottomLeft, attr.cornerFamilyBottomRight, attr.cornerFamilyTopLeft, attr.cornerFamilyTopRight, attr.cornerSize, attr.cornerSizeBottomLeft, attr.cornerSizeBottomRight, attr.cornerSizeTopLeft, attr.cornerSizeTopRight};
        public static final int ShapeAppearance_cornerFamily = 0;
        public static final int ShapeAppearance_cornerFamilyBottomLeft = 1;
        public static final int ShapeAppearance_cornerFamilyBottomRight = 2;
        public static final int ShapeAppearance_cornerFamilyTopLeft = 3;
        public static final int ShapeAppearance_cornerFamilyTopRight = 4;
        public static final int ShapeAppearance_cornerSize = 5;
        public static final int ShapeAppearance_cornerSizeBottomLeft = 6;
        public static final int ShapeAppearance_cornerSizeBottomRight = 7;
        public static final int ShapeAppearance_cornerSizeTopLeft = 8;
        public static final int ShapeAppearance_cornerSizeTopRight = 9;
        public static final int[] SignInButton = new int[]{attr.buttonSize, attr.colorScheme, attr.scopeUris};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;
        public static final int[] Snackbar = new int[]{attr.snackbarButtonStyle, attr.snackbarStyle};
        public static final int[] SnackbarLayout = new int[]{16843039, attr.actionTextColorAlpha, attr.animationMode, attr.backgroundOverlayColorAlpha, attr.elevation, attr.maxActionInlineWidth};
        public static final int SnackbarLayout_actionTextColorAlpha = 1;
        public static final int SnackbarLayout_android_maxWidth = 0;
        public static final int SnackbarLayout_animationMode = 2;
        public static final int SnackbarLayout_backgroundOverlayColorAlpha = 3;
        public static final int SnackbarLayout_elevation = 4;
        public static final int SnackbarLayout_maxActionInlineWidth = 5;
        public static final int Snackbar_snackbarButtonStyle = 0;
        public static final int Snackbar_snackbarStyle = 1;
        public static final int[] Spinner = new int[]{16842930, 16843126, 16843131, 16843362, attr.popupTheme};
        public static final int Spinner_android_dropDownWidth = 3;
        public static final int Spinner_android_entries = 0;
        public static final int Spinner_android_popupBackground = 1;
        public static final int Spinner_android_prompt = 2;
        public static final int Spinner_popupTheme = 4;
        public static final int[] StateListDrawable = new int[]{16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int[] StateListDrawableItem = new int[]{16843161};
        public static final int StateListDrawableItem_android_drawable = 0;
        public static final int StateListDrawable_android_constantSize = 3;
        public static final int StateListDrawable_android_dither = 0;
        public static final int StateListDrawable_android_enterFadeDuration = 4;
        public static final int StateListDrawable_android_exitFadeDuration = 5;
        public static final int StateListDrawable_android_variablePadding = 2;
        public static final int StateListDrawable_android_visible = 1;
        public static final int[] SwitchCompat = new int[]{16843044, 16843045, 16843074, attr.showText, attr.splitTrack, attr.switchMinWidth, attr.switchPadding, attr.switchTextAppearance, attr.thumbTextPadding, attr.thumbTint, attr.thumbTintMode, attr.track, attr.trackTint, attr.trackTintMode};
        public static final int SwitchCompat_android_textOff = 1;
        public static final int SwitchCompat_android_textOn = 0;
        public static final int SwitchCompat_android_thumb = 2;
        public static final int SwitchCompat_showText = 3;
        public static final int SwitchCompat_splitTrack = 4;
        public static final int SwitchCompat_switchMinWidth = 5;
        public static final int SwitchCompat_switchPadding = 6;
        public static final int SwitchCompat_switchTextAppearance = 7;
        public static final int SwitchCompat_thumbTextPadding = 8;
        public static final int SwitchCompat_thumbTint = 9;
        public static final int SwitchCompat_thumbTintMode = 10;
        public static final int SwitchCompat_track = 11;
        public static final int SwitchCompat_trackTint = 12;
        public static final int SwitchCompat_trackTintMode = 13;
        public static final int[] SwitchMaterial = new int[]{attr.useMaterialThemeColors};
        public static final int SwitchMaterial_useMaterialThemeColors = 0;
        public static final int[] TabItem = new int[]{16842754, 16842994, 16843087};
        public static final int TabItem_android_icon = 0;
        public static final int TabItem_android_layout = 1;
        public static final int TabItem_android_text = 2;
        public static final int[] TabLayout = new int[]{attr.tabBackground, attr.tabContentStart, attr.tabGravity, attr.tabIconTint, attr.tabIconTintMode, attr.tabIndicator, attr.tabIndicatorAnimationDuration, attr.tabIndicatorColor, attr.tabIndicatorFullWidth, attr.tabIndicatorGravity, attr.tabIndicatorHeight, attr.tabInlineLabel, attr.tabMaxWidth, attr.tabMinWidth, attr.tabMode, attr.tabPadding, attr.tabPaddingBottom, attr.tabPaddingEnd, attr.tabPaddingStart, attr.tabPaddingTop, attr.tabRippleColor, attr.tabSelectedTextColor, attr.tabTextAppearance, attr.tabTextColor, attr.tabUnboundedRipple};
        public static final int TabLayout_tabBackground = 0;
        public static final int TabLayout_tabContentStart = 1;
        public static final int TabLayout_tabGravity = 2;
        public static final int TabLayout_tabIconTint = 3;
        public static final int TabLayout_tabIconTintMode = 4;
        public static final int TabLayout_tabIndicator = 5;
        public static final int TabLayout_tabIndicatorAnimationDuration = 6;
        public static final int TabLayout_tabIndicatorColor = 7;
        public static final int TabLayout_tabIndicatorFullWidth = 8;
        public static final int TabLayout_tabIndicatorGravity = 9;
        public static final int TabLayout_tabIndicatorHeight = 10;
        public static final int TabLayout_tabInlineLabel = 11;
        public static final int TabLayout_tabMaxWidth = 12;
        public static final int TabLayout_tabMinWidth = 13;
        public static final int TabLayout_tabMode = 14;
        public static final int TabLayout_tabPadding = 15;
        public static final int TabLayout_tabPaddingBottom = 16;
        public static final int TabLayout_tabPaddingEnd = 17;
        public static final int TabLayout_tabPaddingStart = 18;
        public static final int TabLayout_tabPaddingTop = 19;
        public static final int TabLayout_tabRippleColor = 20;
        public static final int TabLayout_tabSelectedTextColor = 21;
        public static final int TabLayout_tabTextAppearance = 22;
        public static final int TabLayout_tabTextColor = 23;
        public static final int TabLayout_tabUnboundedRipple = 24;
        public static final int[] TextAppearance = new int[]{16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 16844165, attr.fontFamily, attr.fontVariationSettings, attr.textAllCaps, attr.textLocale};
        public static final int TextAppearance_android_fontFamily = 10;
        public static final int TextAppearance_android_shadowColor = 6;
        public static final int TextAppearance_android_shadowDx = 7;
        public static final int TextAppearance_android_shadowDy = 8;
        public static final int TextAppearance_android_shadowRadius = 9;
        public static final int TextAppearance_android_textColor = 3;
        public static final int TextAppearance_android_textColorHint = 4;
        public static final int TextAppearance_android_textColorLink = 5;
        public static final int TextAppearance_android_textFontWeight = 11;
        public static final int TextAppearance_android_textSize = 0;
        public static final int TextAppearance_android_textStyle = 2;
        public static final int TextAppearance_android_typeface = 1;
        public static final int TextAppearance_fontFamily = 12;
        public static final int TextAppearance_fontVariationSettings = 13;
        public static final int TextAppearance_textAllCaps = 14;
        public static final int TextAppearance_textLocale = 15;
        public static final int[] TextInputLayout = new int[]{16842906, 16843088, attr.boxBackgroundColor, attr.boxBackgroundMode, attr.boxCollapsedPaddingTop, attr.boxCornerRadiusBottomEnd, attr.boxCornerRadiusBottomStart, attr.boxCornerRadiusTopEnd, attr.boxCornerRadiusTopStart, attr.boxStrokeColor, attr.boxStrokeWidth, attr.boxStrokeWidthFocused, attr.counterEnabled, attr.counterMaxLength, attr.counterOverflowTextAppearance, attr.counterOverflowTextColor, attr.counterTextAppearance, attr.counterTextColor, attr.endIconCheckable, attr.endIconContentDescription, attr.endIconDrawable, attr.endIconMode, attr.endIconTint, attr.endIconTintMode, attr.errorEnabled, attr.errorIconDrawable, attr.errorIconTint, attr.errorIconTintMode, attr.errorTextAppearance, attr.errorTextColor, attr.helperText, attr.helperTextEnabled, attr.helperTextTextAppearance, attr.helperTextTextColor, attr.hintAnimationEnabled, attr.hintEnabled, attr.hintTextAppearance, attr.hintTextColor, attr.passwordToggleContentDescription, attr.passwordToggleDrawable, attr.passwordToggleEnabled, attr.passwordToggleTint, attr.passwordToggleTintMode, attr.shapeAppearance, attr.shapeAppearanceOverlay, attr.startIconCheckable, attr.startIconContentDescription, attr.startIconDrawable, attr.startIconTint, attr.startIconTintMode};
        public static final int TextInputLayout_android_hint = 1;
        public static final int TextInputLayout_android_textColorHint = 0;
        public static final int TextInputLayout_boxBackgroundColor = 2;
        public static final int TextInputLayout_boxBackgroundMode = 3;
        public static final int TextInputLayout_boxCollapsedPaddingTop = 4;
        public static final int TextInputLayout_boxCornerRadiusBottomEnd = 5;
        public static final int TextInputLayout_boxCornerRadiusBottomStart = 6;
        public static final int TextInputLayout_boxCornerRadiusTopEnd = 7;
        public static final int TextInputLayout_boxCornerRadiusTopStart = 8;
        public static final int TextInputLayout_boxStrokeColor = 9;
        public static final int TextInputLayout_boxStrokeWidth = 10;
        public static final int TextInputLayout_boxStrokeWidthFocused = 11;
        public static final int TextInputLayout_counterEnabled = 12;
        public static final int TextInputLayout_counterMaxLength = 13;
        public static final int TextInputLayout_counterOverflowTextAppearance = 14;
        public static final int TextInputLayout_counterOverflowTextColor = 15;
        public static final int TextInputLayout_counterTextAppearance = 16;
        public static final int TextInputLayout_counterTextColor = 17;
        public static final int TextInputLayout_endIconCheckable = 18;
        public static final int TextInputLayout_endIconContentDescription = 19;
        public static final int TextInputLayout_endIconDrawable = 20;
        public static final int TextInputLayout_endIconMode = 21;
        public static final int TextInputLayout_endIconTint = 22;
        public static final int TextInputLayout_endIconTintMode = 23;
        public static final int TextInputLayout_errorEnabled = 24;
        public static final int TextInputLayout_errorIconDrawable = 25;
        public static final int TextInputLayout_errorIconTint = 26;
        public static final int TextInputLayout_errorIconTintMode = 27;
        public static final int TextInputLayout_errorTextAppearance = 28;
        public static final int TextInputLayout_errorTextColor = 29;
        public static final int TextInputLayout_helperText = 30;
        public static final int TextInputLayout_helperTextEnabled = 31;
        public static final int TextInputLayout_helperTextTextAppearance = 32;
        public static final int TextInputLayout_helperTextTextColor = 33;
        public static final int TextInputLayout_hintAnimationEnabled = 34;
        public static final int TextInputLayout_hintEnabled = 35;
        public static final int TextInputLayout_hintTextAppearance = 36;
        public static final int TextInputLayout_hintTextColor = 37;
        public static final int TextInputLayout_passwordToggleContentDescription = 38;
        public static final int TextInputLayout_passwordToggleDrawable = 39;
        public static final int TextInputLayout_passwordToggleEnabled = 40;
        public static final int TextInputLayout_passwordToggleTint = 41;
        public static final int TextInputLayout_passwordToggleTintMode = 42;
        public static final int TextInputLayout_shapeAppearance = 43;
        public static final int TextInputLayout_shapeAppearanceOverlay = 44;
        public static final int TextInputLayout_startIconCheckable = 45;
        public static final int TextInputLayout_startIconContentDescription = 46;
        public static final int TextInputLayout_startIconDrawable = 47;
        public static final int TextInputLayout_startIconTint = 48;
        public static final int TextInputLayout_startIconTintMode = 49;
        public static final int[] ThemeEnforcement = new int[]{16842804, attr.enforceMaterialTheme, attr.enforceTextAppearance};
        public static final int ThemeEnforcement_android_textAppearance = 0;
        public static final int ThemeEnforcement_enforceMaterialTheme = 1;
        public static final int ThemeEnforcement_enforceTextAppearance = 2;
        public static final int[] Toolbar = new int[]{16842927, 16843072, attr.buttonGravity, attr.collapseContentDescription, attr.collapseIcon, attr.contentInsetEnd, attr.contentInsetEndWithActions, attr.contentInsetLeft, attr.contentInsetRight, attr.contentInsetStart, attr.contentInsetStartWithNavigation, attr.logo, attr.logoDescription, attr.maxButtonHeight, attr.menu, attr.navigationContentDescription, attr.navigationIcon, attr.popupTheme, attr.subtitle, attr.subtitleTextAppearance, attr.subtitleTextColor, attr.title, attr.titleMargin, attr.titleMarginBottom, attr.titleMarginEnd, attr.titleMarginStart, attr.titleMarginTop, attr.titleMargins, attr.titleTextAppearance, attr.titleTextColor};
        public static final int Toolbar_android_gravity = 0;
        public static final int Toolbar_android_minHeight = 1;
        public static final int Toolbar_buttonGravity = 2;
        public static final int Toolbar_collapseContentDescription = 3;
        public static final int Toolbar_collapseIcon = 4;
        public static final int Toolbar_contentInsetEnd = 5;
        public static final int Toolbar_contentInsetEndWithActions = 6;
        public static final int Toolbar_contentInsetLeft = 7;
        public static final int Toolbar_contentInsetRight = 8;
        public static final int Toolbar_contentInsetStart = 9;
        public static final int Toolbar_contentInsetStartWithNavigation = 10;
        public static final int Toolbar_logo = 11;
        public static final int Toolbar_logoDescription = 12;
        public static final int Toolbar_maxButtonHeight = 13;
        public static final int Toolbar_menu = 14;
        public static final int Toolbar_navigationContentDescription = 15;
        public static final int Toolbar_navigationIcon = 16;
        public static final int Toolbar_popupTheme = 17;
        public static final int Toolbar_subtitle = 18;
        public static final int Toolbar_subtitleTextAppearance = 19;
        public static final int Toolbar_subtitleTextColor = 20;
        public static final int Toolbar_title = 21;
        public static final int Toolbar_titleMargin = 22;
        public static final int Toolbar_titleMarginBottom = 23;
        public static final int Toolbar_titleMarginEnd = 24;
        public static final int Toolbar_titleMarginStart = 25;
        public static final int Toolbar_titleMarginTop = 26;
        public static final int Toolbar_titleMargins = 27;
        public static final int Toolbar_titleTextAppearance = 28;
        public static final int Toolbar_titleTextColor = 29;
        public static final int[] View = new int[]{16842752, 16842970, attr.paddingEnd, attr.paddingStart, attr.theme};
        public static final int[] ViewBackgroundHelper = new int[]{16842964, attr.backgroundTint, attr.backgroundTintMode};
        public static final int ViewBackgroundHelper_android_background = 0;
        public static final int ViewBackgroundHelper_backgroundTint = 1;
        public static final int ViewBackgroundHelper_backgroundTintMode = 2;
        public static final int[] ViewPager2 = new int[]{16842948};
        public static final int ViewPager2_android_orientation = 0;
        public static final int[] ViewStubCompat = new int[]{16842960, 16842994, 16842995};
        public static final int ViewStubCompat_android_id = 0;
        public static final int ViewStubCompat_android_inflatedId = 2;
        public static final int ViewStubCompat_android_layout = 1;
        public static final int View_android_focusable = 1;
        public static final int View_android_theme = 0;
        public static final int View_paddingEnd = 2;
        public static final int View_paddingStart = 3;
        public static final int View_theme = 4;

        private styleable() {
        }
    }

    public static final class xml {
        public static final int standalone_badge = 2131886080;
        public static final int standalone_badge_gravity_bottom_end = 2131886081;
        public static final int standalone_badge_gravity_bottom_start = 2131886082;
        public static final int standalone_badge_gravity_top_start = 2131886083;

        private xml() {
        }
    }

    private R() {
    }
}
