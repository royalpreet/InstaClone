package com.example.instaclone.Share;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.fragment.app.Fragment;
import com.example.instagramclone.AccountSettings.AccountSettingsActivity;
import com.example.instagramclone.NextActivity;
import com.example.instagramclone.R;
import java.util.Objects;

public class PhotoFragment extends Fragment {
    private static final int CAMERA_REQUEST_CODE = 1;
    private static final String TAG = "PhotoFragment";
    private Button launchCamera;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: started");
        View view = inflater.inflate(R.layout.fragment_photo, container, false);
        Button button = (Button) view.findViewById(R.id.launchCamera);
        this.launchCamera = button;
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Log.d(PhotoFragment.TAG, "onClick: Launching camera");
                if (((ShareActivity) Objects.requireNonNull(PhotoFragment.this.getActivity())).getCurrentTabNumber() == 1) {
                    PhotoFragment.this.startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), 1);
                }
            }
        });
        return view;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            Log.d(TAG, "onActivityResult: navigation to share screen");
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            if (isRootTask()) {
                Intent intent = new Intent(getActivity(), NextActivity.class);
                intent.putExtra("selectedBitmap", bitmap);
                startActivity(intent);
                return;
            }
            Intent intent2 = new Intent(getActivity(), AccountSettingsActivity.class);
            intent2.putExtra("bitmap", bitmap);
            intent2.putExtra("return_to_fragment", 1);
            startActivity(intent2);
            getActivity().finish();
        }
    }

    public boolean isRootTask() {
        if (((ShareActivity) getActivity()).getTask() == 0) {
            return true;
        }
        return false;
    }
}
